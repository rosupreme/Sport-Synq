import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { Trophy } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import Pill from "@/components/Pill";

export function FundraiserSectionHeader({
  activeFundraisers,
  completedFundraisers,
}) {
  const { colors } = useTheme();

  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 20, // match pill spacing used on other pages
      }}
    >
      {/* Active Fundraisers Pill */}
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <Pill
          label={`Active Fundraisers (${activeFundraisers})`}
          style={{ marginRight: 12 }}
        />
      </View>

      {completedFundraisers > 0 && (
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Trophy size={16} color={colors.success} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.success,
              marginLeft: 4,
            }}
          >
            {completedFundraisers} Completed
          </Text>
        </View>
      )}
    </View>
  );
}
