import React from "react";
import { View, Text } from "react-native";
import { useTheme } from "@/components/ThemeProvider";

export function StatsCard({ title, value, subtitle, color, icon: Icon }) {
  const { colors, isDark } = useTheme();

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 12,
        padding: 16,
        flex: 1,
        marginHorizontal: 4,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <View
        style={{
          width: 40,
          height: 40,
          backgroundColor: isDark ? `${color}40` : `${color}20`,
          borderRadius: 20,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 12,
        }}
      >
        <Icon size={20} color={color} />
      </View>
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 20,
          color: colors.mainText,
          marginBottom: 4,
        }}
      >
        {value}
      </Text>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 13,
          color: colors.mainText,
          marginBottom: 2,
        }}
      >
        {title}
      </Text>
      <Text
        style={{
          fontFamily: "Inter_400Regular",
          fontSize: 11,
          color: colors.secondaryText,
        }}
      >
        {subtitle}
      </Text>
    </View>
  );
}
