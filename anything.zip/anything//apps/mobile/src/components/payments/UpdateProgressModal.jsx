import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Modal,
  TextInput,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { X, Save } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

export function UpdateProgressModal({ visible, fundraiser, onClose, onSave }) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const [updateAmount, setUpdateAmount] = useState("");
  const [updateNote, setUpdateNote] = useState("");
  const [updating, setUpdating] = useState(false);

  const handleSave = async () => {
    if (!updateAmount || parseInt(updateAmount) <= 0) {
      alert("Please enter a valid amount");
      return;
    }

    setUpdating(true);
    const result = await onSave(fundraiser?.id, updateAmount, updateNote);
    setUpdating(false);

    if (result.success) {
      setUpdateAmount("");
      setUpdateNote("");
      alert("Progress updated successfully!");
      onClose();
    } else {
      alert(result.error || "Failed to update progress");
    }
  };

  const handleClose = () => {
    setUpdateAmount("");
    setUpdateNote("");
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="none"
      transparent={true}
      presentationStyle="overFullScreen" // ensure proper overlay on iOS
      statusBarTranslucent={true}
      hardwareAccelerated={true}
      onRequestClose={handleClose}
      supportedOrientations={[
        "portrait",
        "portrait-upside-down",
        "landscape",
        "landscape-left",
        "landscape-right",
      ]}
    >
      <KeyboardAvoidingView
        style={{
          flex: 1,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          justifyContent: "flex-end",
        }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <View
          style={{
            backgroundColor: colors.background,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            maxHeight: "80%",
            width: "100%", // ensure full width
            minHeight: 240, // ensure content is visible (prevents 0-height on iOS)
            // Ensure it's visible even if keyboard pushes content
            shadowColor: "#000",
            shadowOpacity: 0.1,
            shadowOffset: { width: 0, height: -2 },
            shadowRadius: 8,
            elevation: 4,
          }}
        >
          {/* Remove flex:1 from ScrollView to avoid zero-height on iOS when parent has no explicit height */}
          <ScrollView
            contentContainerStyle={{
              padding: 20,
              paddingBottom: insets.bottom + 20,
              flexGrow: 0, // do not stretch; size to content
            }}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 20,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 20,
                  color: colors.mainText,
                }}
              >
                Update Progress
              </Text>
              <TouchableOpacity
                onPress={handleClose}
                style={{
                  width: 36,
                  height: 36,
                  backgroundColor: colors.lavender,
                  borderRadius: 18,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <X size={20} color={colors.secondaryText} />
              </TouchableOpacity>
            </View>

            {fundraiser && (
              <View style={{ marginBottom: 20 }}>
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 16,
                    color: colors.mainText,
                    marginBottom: 8,
                  }}
                >
                  {fundraiser.title}
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 14,
                    color: colors.secondaryText,
                  }}
                >
                  Current: ${fundraiser.raised_amount} of $
                  {fundraiser.goal_amount}
                </Text>
              </View>
            )}

            <View style={{ marginBottom: 16 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Add Amount Raised
              </Text>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 12,
                  padding: 16,
                  fontSize: 16,
                  color: colors.mainText,
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
                placeholder="Enter amount (e.g. 150)"
                placeholderTextColor={colors.secondaryText}
                value={updateAmount}
                onChangeText={setUpdateAmount}
                keyboardType={Platform.OS === "ios" ? "number-pad" : "numeric"}
              />
            </View>

            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Note (Optional)
              </Text>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 12,
                  padding: 16,
                  fontSize: 16,
                  color: colors.mainText,
                  borderWidth: 1,
                  borderColor: colors.border,
                  height: 80,
                }}
                placeholder="e.g. Bake sale proceeds, Car wash event"
                placeholderTextColor={colors.secondaryText}
                value={updateNote}
                onChangeText={setUpdateNote}
                multiline={true}
                textAlignVertical="top"
              />
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 16,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                opacity: updating ? 0.7 : 1,
              }}
              onPress={handleSave}
              disabled={!updateAmount || updating || !fundraiser}
            >
              {updating ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <>
                  <Save size={20} color="white" />
                  <Text
                    style={{
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 16,
                      color: "white",
                      marginLeft: 8,
                    }}
                  >
                    Update Progress
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
