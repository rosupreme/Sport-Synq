import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { Users, Clock, Edit3, Trash2 } from "lucide-react-native";
import Svg, { Circle } from "react-native-svg";
import { useTheme } from "@/components/ThemeProvider";
import { getDaysRemaining } from "@/utils/fundraiserHelpers";

export function FundraiserCard({
  fundraiser,
  onUpdate,
  onDelete,
  canManage = false,
}) {
  const { colors } = useTheme();
  const progress = (fundraiser.raised_amount / fundraiser.goal_amount) * 100;
  const daysRemaining = getDaysRemaining(fundraiser.end_date);
  const isCompleted = fundraiser.status === "completed" || progress >= 100;
  const contributors = parseInt(fundraiser.contributors) || 0;

  return (
    <TouchableOpacity
      style={{
        backgroundColor: colors.surface,
        borderRadius: 20,
        padding: 24,
        marginBottom: 16,
        borderWidth: 1,
        borderColor: colors.border,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <View style={{ flex: 1, paddingRight: 20 }}>
        {/* Title */}
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 24,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          {fundraiser.title}
        </Text>

        {/* Subtitle */}
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 16,
            color: colors.secondaryText,
            marginBottom: 20,
          }}
        >
          {fundraiser.description || "Team Fundraiser"}
        </Text>

        {/* Amount */}
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 36,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          ${fundraiser.raised_amount.toLocaleString()}
        </Text>

        {/* Goal */}
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 16,
            color: colors.secondaryText,
            marginBottom: 20,
          }}
        >
          of ${fundraiser.goal_amount.toLocaleString()} goal
        </Text>

        {/* Bottom Info */}
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginRight: 24,
            }}
          >
            <Users
              size={16}
              color={colors.secondaryText}
              style={{ marginRight: 8 }}
            />
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {contributors} contributors
            </Text>
          </View>

          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Clock
              size={16}
              color={colors.secondaryText}
              style={{ marginRight: 8 }}
            />
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {isCompleted
                ? "Completed"
                : `${Math.max(0, daysRemaining)} days left`}
            </Text>
          </View>
        </View>
      </View>

      {/* Circular Progress */}
      <View style={{ alignItems: "center" }}>
        <View
          style={{
            width: 80,
            height: 80,
            justifyContent: "center",
            alignItems: "center",
            position: "relative",
          }}
        >
          {/* SVG Progress Circle */}
          <Svg width="80" height="80" viewBox="0 0 80 80">
            {/* Background Circle */}
            <Circle
              cx="40"
              cy="40"
              r="32"
              stroke={colors.border}
              strokeWidth="8"
              fill="none"
            />

            {/* Progress Circle */}
            {progress > 0 && (
              <Circle
                cx="40"
                cy="40"
                r="32"
                stroke={isCompleted ? colors.success : colors.primary}
                strokeWidth="8"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 32}`}
                strokeDashoffset={`${2 * Math.PI * 32 * (1 - progress / 100)}`}
                strokeLinecap="round"
                transform="rotate(-90 40 40)"
              />
            )}
          </Svg>

          {/* Percentage Text */}
          <Text
            style={{
              position: "absolute",
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
            }}
          >
            {Math.round(progress)}%
          </Text>
        </View>
      </View>

      {/* Action Buttons - positioned absolutely in top right */}
      {canManage && (
        <View
          style={{
            position: "absolute",
            top: 16,
            right: 16,
            flexDirection: "row",
          }}
        >
          <TouchableOpacity
            style={{
              width: 32,
              height: 32,
              backgroundColor: colors.primary + "20",
              borderRadius: 16,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 8,
            }}
            onPress={() => onUpdate(fundraiser)}
          >
            <Edit3 size={14} color={colors.primary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              width: 32,
              height: 32,
              backgroundColor: colors.alert + "20",
              borderRadius: 16,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => onDelete(fundraiser)}
          >
            <Trash2 size={14} color={colors.alert} />
          </TouchableOpacity>
        </View>
      )}
    </TouchableOpacity>
  );
}
