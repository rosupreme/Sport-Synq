import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { Plus } from "lucide-react-native";
import { useRouter } from "expo-router";
import { useTheme } from "@/components/ThemeProvider";

export function FundraiserHeader({ selectedTeam, canManage = false }) {
  const router = useRouter();
  const { colors, typography } = useTheme();

  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 24,
      }}
    >
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: typography.title,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          Fundraising
        </Text>
        {/* Removed team name under header per request */}
      </View>

      <View style={{ flexDirection: "row", marginLeft: 16 }}>
        {/* Only coaches can add fundraisers */}
        {canManage && (
          <TouchableOpacity
            style={{
              width: 44,
              height: 44,
              backgroundColor: colors.primary,
              borderRadius: 22,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => router.push("/add-fundraiser")}
          >
            <Plus size={24} color={colors.onPrimary} />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}
