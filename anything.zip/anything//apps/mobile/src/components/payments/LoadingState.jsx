import React from "react";
import { View, Text, ActivityIndicator } from "react-native";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useTheme } from "@/components/ThemeProvider";

export function LoadingState() {
  const { colors } = useTheme();

  return (
    <ScreenWrapper>
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 16,
            color: colors.secondaryText,
            marginTop: 16,
          }}
        >
          Loading fundraisers...
        </Text>
      </View>
    </ScreenWrapper>
  );
}
