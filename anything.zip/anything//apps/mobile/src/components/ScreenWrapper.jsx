import React from "react";
import { View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "./ThemeProvider";

export default function ScreenWrapper({ children, style, ...props }) {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[{ flex: 1, backgroundColor: colors.background }, style]}
      {...props}
    >
      <StatusBar style={isDark ? "light" : "dark"} />
      {children}
    </View>
  );
}
