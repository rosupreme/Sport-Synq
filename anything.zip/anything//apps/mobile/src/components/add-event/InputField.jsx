import React from "react";
import { View, Text, TextInput } from "react-native";
import { useTheme } from "@/components/ThemeProvider";

export default function InputField({
  label,
  placeholder,
  value,
  onChangeText,
  icon: Icon,
  multiline = false,
  ...props
}) {
  const { colors } = useTheme();

  return (
    <View style={{ marginBottom: 20 }}>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 14,
          color: colors.mainText,
          marginBottom: 8,
        }}
      >
        {label}
      </Text>
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          flexDirection: "row",
          alignItems: multiline ? "flex-start" : "center",
          paddingHorizontal: 16,
          paddingVertical: multiline ? 16 : 14,
        }}
      >
        {Icon && (
          <Icon
            size={20}
            color={colors.secondaryText}
            style={{ marginRight: 12, marginTop: multiline ? 2 : 0 }}
          />
        )}
        <TextInput
          placeholder={placeholder}
          placeholderTextColor={colors.secondaryText}
          value={value}
          onChangeText={onChangeText}
          multiline={multiline}
          numberOfLines={multiline ? 4 : 1}
          style={{
            flex: 1,
            fontFamily: "Inter_400Regular",
            fontSize: 15,
            color: colors.mainText,
            minHeight: multiline ? 80 : 40,
            maxHeight: multiline ? 120 : 40,
            textAlignVertical: multiline ? "top" : "auto",
            paddingVertical: 0,
          }}
          returnKeyType={multiline ? "default" : "done"}
          blurOnSubmit={!multiline}
          autoCorrect={true}
          spellCheck={true}
          autoCapitalize="sentences"
          textContentType="none"
          autoComplete="off"
          {...props}
        />
      </View>
    </View>
  );
}
