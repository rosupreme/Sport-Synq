import React from "react";
import { View, Text, Modal, TouchableOpacity } from "react-native";
import { Calendar as RNCalendar } from "react-native-calendars";
import { useTheme } from "@/components/ThemeProvider";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function DatePickerModal({
  visible,
  onClose,
  onDayPress,
  selectedDate,
}) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingBottom: insets.bottom + 20,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: colors.border,
            }}
          >
            <TouchableOpacity onPress={onClose}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.secondaryText,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 17,
                color: colors.mainText,
              }}
            >
              Select Date
            </Text>
            <View style={{ width: 60 }} />
          </View>

          <RNCalendar
            onDayPress={onDayPress}
            markedDates={{
              [selectedDate]: {
                selected: true,
                selectedColor: colors.primary,
              },
            }}
            minDate={new Date().toISOString().split("T")[0]}
            theme={{
              backgroundColor: colors.surface,
              calendarBackground: colors.surface,
              textSectionTitleColor: colors.secondaryText,
              selectedDayBackgroundColor: colors.primary,
              selectedDayTextColor: "#ffffff",
              todayTextColor: colors.primary,
              dayTextColor: colors.mainText,
              textDisabledColor: colors.secondaryText,
              dotColor: colors.primary,
              selectedDotColor: "#ffffff",
              arrowColor: colors.primary,
              disabledArrowColor: colors.secondaryText,
              monthTextColor: colors.mainText,
              indicatorColor: colors.primary,
              textDayFontFamily: "Inter_400Regular",
              textMonthFontFamily: "Inter_600SemiBold",
              textDayHeaderFontFamily: "Inter_500Medium",
              textDayFontSize: 16,
              textMonthFontSize: 18,
              textDayHeaderFontSize: 13,
            }}
            enableSwipeMonths={true}
          />
        </View>
      </View>
    </Modal>
  );
}
