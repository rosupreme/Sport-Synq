import React, { useState, useRef, useEffect } from "react";
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from "react-native";
import { useTheme } from "@/components/ThemeProvider";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const { width: screenWidth } = Dimensions.get("window");

// Wheel Picker Component (without individual selection indicator)
const WheelPicker = ({ data, selectedIndex, onSelect, itemHeight = 40 }) => {
  const scrollViewRef = useRef(null);

  useEffect(() => {
    // Scroll to selected item on mount
    if (scrollViewRef.current && selectedIndex >= 0) {
      scrollViewRef.current.scrollTo({
        y: selectedIndex * itemHeight,
        animated: false,
      });
    }
  }, [selectedIndex, itemHeight]);

  const handleScroll = (event) => {
    const y = event.nativeEvent.contentOffset.y;
    const index = Math.round(y / itemHeight);
    if (index >= 0 && index < data.length && index !== selectedIndex) {
      onSelect(index);
    }
  };

  return (
    <View style={{ height: itemHeight * 5 }}>
      <ScrollView
        ref={scrollViewRef}
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingVertical: itemHeight * 2, // Add padding to center the first and last items
        }}
        showsVerticalScrollIndicator={false}
        onMomentumScrollEnd={handleScroll}
        onScrollEndDrag={handleScroll}
        snapToInterval={itemHeight}
        snapToAlignment="start"
        decelerationRate="fast"
      >
        {data.map((item, index) => {
          const isSelected = index === selectedIndex;
          return (
            <TouchableOpacity
              key={index}
              style={{
                height: itemHeight,
                justifyContent: "center",
                alignItems: "center",
              }}
              onPress={() => {
                onSelect(index);
                scrollViewRef.current?.scrollTo({
                  y: index * itemHeight,
                  animated: true,
                });
              }}
            >
              <Text
                style={{
                  fontSize: 24,
                  fontFamily: isSelected
                    ? "Inter_600SemiBold"
                    : "Inter_400Regular",
                  color: isSelected ? "#000" : "#999",
                }}
              >
                {item}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
};

export default function TimePickerModal({
  visible,
  onClose,
  onDone,
  selectedTime,
  onTimeChange,
}) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();

  // Generate data arrays
  const hours = Array.from({ length: 12 }, (_, i) => (i + 1).toString());
  const minutes = Array.from({ length: 60 }, (_, i) =>
    i.toString().padStart(2, "0"),
  );
  const periods = ["AM", "PM"];

  // Get current indices
  const hourIndex = Math.max(0, selectedTime.hour - 1);
  const minuteIndex = selectedTime.minute;
  const periodIndex = selectedTime.period === "PM" ? 1 : 0;

  const handleHourSelect = (index) => {
    onTimeChange({
      ...selectedTime,
      hour: index + 1,
    });
  };

  const handleMinuteSelect = (index) => {
    onTimeChange({
      ...selectedTime,
      minute: index,
    });
  };

  const handlePeriodSelect = (index) => {
    onTimeChange({
      ...selectedTime,
      period: periods[index],
    });
  };

  const getCurrentTimeString = () => {
    const hourStr = selectedTime.hour.toString();
    const minuteStr = selectedTime.minute.toString().padStart(2, "0");
    return `${hourStr}:${minuteStr} ${selectedTime.period}`;
  };

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        <View
          style={{
            backgroundColor: "white",
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingBottom: insets.bottom + 20,
          }}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: "#e0e0e0",
            }}
          >
            <TouchableOpacity onPress={onClose}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: "#666",
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>

            <View style={{ alignItems: "center" }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 17,
                  color: "#000",
                }}
              >
                Select Time
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.primary,
                  marginTop: 2,
                }}
              >
                {getCurrentTimeString()}
              </Text>
            </View>

            <TouchableOpacity onPress={onDone}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                  color: colors.primary,
                }}
              >
                Done
              </Text>
            </TouchableOpacity>
          </View>

          {/* Time Picker Container with Single Selection Bar */}
          <View
            style={{
              paddingHorizontal: 20,
              paddingVertical: 20,
              height: 240,
              position: "relative",
            }}
          >
            {/* Single continuous selection bar spanning all three columns */}
            <View
              style={{
                position: "absolute",
                top: 20 + 40 * 2, // 20px padding + 2 items height to center on middle item
                left: 20,
                right: 20,
                height: 40,
                backgroundColor: "rgba(0,0,0,0.05)",
                borderRadius: 8,
                borderTopWidth: 1,
                borderBottomWidth: 1,
                borderColor: "rgba(0,0,0,0.1)",
                zIndex: 1,
              }}
            />

            {/* Time Picker Wheels */}
            <View
              style={{
                flexDirection: "row",
                height: 200,
              }}
            >
              {/* Hours */}
              <View style={{ flex: 1 }}>
                <WheelPicker
                  data={hours}
                  selectedIndex={hourIndex}
                  onSelect={handleHourSelect}
                />
              </View>

              {/* Minutes */}
              <View style={{ flex: 1 }}>
                <WheelPicker
                  data={minutes}
                  selectedIndex={minuteIndex}
                  onSelect={handleMinuteSelect}
                />
              </View>

              {/* AM/PM */}
              <View style={{ flex: 1 }}>
                <WheelPicker
                  data={periods}
                  selectedIndex={periodIndex}
                  onSelect={handlePeriodSelect}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
}
