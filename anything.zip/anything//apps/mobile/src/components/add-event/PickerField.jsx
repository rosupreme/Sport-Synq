import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { ChevronDown } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

export default function PickerField({
  label,
  placeholder,
  value,
  onPress,
  icon: Icon,
}) {
  const { colors } = useTheme();

  return (
    <View style={{ marginBottom: 20 }}>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 14,
          color: colors.mainText,
          marginBottom: 8,
        }}
      >
        {label}
      </Text>
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 14,
        }}
        onPress={onPress}
      >
        {Icon && (
          <Icon
            size={20}
            color={colors.secondaryText}
            style={{ marginRight: 12 }}
          />
        )}
        <Text
          style={{
            flex: 1,
            fontFamily: "Inter_400Regular",
            fontSize: 15,
            color: value ? colors.mainText : colors.secondaryText,
          }}
        >
          {value || placeholder}
        </Text>
        <ChevronDown size={20} color={colors.secondaryText} />
      </TouchableOpacity>
    </View>
  );
}
