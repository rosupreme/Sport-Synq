import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useTheme } from "@/components/ThemeProvider";

export default function TeamSelector({
  teams,
  loading,
  selectedTeamId,
  onSelectTeam,
}) {
  const { colors } = useTheme();

  if (loading) {
    return (
      <View style={{ marginBottom: 20 }}>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 14,
            color: colors.mainText,
            marginBottom: 8,
          }}
        >
          Team
        </Text>
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 12,
            borderWidth: 1,
            borderColor: colors.border,
            paddingHorizontal: 16,
            paddingVertical: 14,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 15,
              color: colors.secondaryText,
            }}
          >
            Loading teams...
          </Text>
        </View>
      </View>
    );
  }

  if (teams.length === 0) {
    return (
      <View style={{ marginBottom: 20 }}>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 14,
            color: colors.mainText,
            marginBottom: 8,
          }}
        >
          Team
        </Text>
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 12,
            borderWidth: 1,
            borderColor: colors.border,
            paddingHorizontal: 16,
            paddingVertical: 14,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 15,
              color: colors.error,
            }}
          >
            No teams found. Please create a team first.
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={{ marginBottom: 20 }}>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 14,
          color: colors.mainText,
          marginBottom: 8,
        }}
      >
        Team
      </Text>
      <View style={{ gap: 8 }}>
        {teams.map((team) => {
          const isSelected = selectedTeamId === team.id;
          return (
            <TouchableOpacity
              key={team.id}
              style={{
                backgroundColor: isSelected
                  ? colors.primary + "20"
                  : colors.surface,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 14,
                borderWidth: 1,
                borderColor: isSelected ? colors.primary : colors.border,
                flexDirection: "row",
                alignItems: "center",
              }}
              onPress={() => onSelectTeam(team.id)}
            >
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 15,
                    color: isSelected ? colors.primary : colors.mainText,
                  }}
                >
                  {team.name}
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 12,
                    color: colors.secondaryText,
                    marginTop: 2,
                  }}
                >
                  {team.sport} • {team.season}
                </Text>
              </View>
              {isSelected && (
                <View
                  style={{
                    width: 20,
                    height: 20,
                    borderRadius: 10,
                    backgroundColor: colors.primary,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text
                    style={{
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 12,
                      color: "white",
                    }}
                  >
                    ✓
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}
