import React from "react";
import { View, Text, TouchableOpacity, Switch } from "react-native";
import { Repeat, Calendar } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

const RECURRENCE_OPTIONS = [
  { id: "daily", label: "Daily", description: "Every day" },
  { id: "weekly", label: "Weekly", description: "Every week on this day" },
  { id: "monthly", label: "Monthly", description: "Every month on this date" },
];

const OCCURRENCE_OPTIONS = [
  { id: 5, label: "5 times" },
  { id: 10, label: "10 times" },
  { id: 15, label: "15 times" },
  { id: 20, label: "20 times" },
];

export default function RecurringEventSelector({
  isRecurring,
  onRecurringToggle,
  recurrenceType,
  onRecurrenceTypeChange,
  occurrences,
  onOccurrencesChange,
}) {
  const { colors } = useTheme();

  return (
    <View style={{ marginBottom: 20 }}>
      {/* Recurring Toggle */}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: isRecurring ? 16 : 0,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", flex: 1 }}>
          <Repeat
            size={20}
            color={isRecurring ? colors.primary : colors.secondaryText}
            style={{ marginRight: 8 }}
          />
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.mainText,
                marginBottom: 2,
              }}
            >
              Recurring Event
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 12,
                color: colors.secondaryText,
              }}
            >
              Create multiple events automatically
            </Text>
          </View>
        </View>
        <Switch
          value={isRecurring}
          onValueChange={onRecurringToggle}
          trackColor={{
            false: colors.border,
            true: colors.primary + "40",
          }}
          thumbColor={isRecurring ? colors.primary : colors.secondaryText}
        />
      </View>

      {/* Recurrence Options - shown when recurring is enabled */}
      {isRecurring && (
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 12,
            padding: 16,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          {/* Recurrence Type */}
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
              marginBottom: 12,
            }}
          >
            Repeat
          </Text>
          <View style={{ gap: 8, marginBottom: 16 }}>
            {RECURRENCE_OPTIONS.map((option) => {
              const isSelected = recurrenceType === option.id;
              return (
                <TouchableOpacity
                  key={option.id}
                  style={{
                    backgroundColor: isSelected
                      ? colors.primary + "10"
                      : "transparent",
                    borderRadius: 8,
                    paddingVertical: 12,
                    paddingHorizontal: 12,
                    borderWidth: 1,
                    borderColor: isSelected ? colors.primary : colors.border,
                  }}
                  onPress={() => onRecurrenceTypeChange(option.id)}
                >
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 14,
                      color: isSelected ? colors.primary : colors.mainText,
                      marginBottom: 2,
                    }}
                  >
                    {option.label}
                  </Text>
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 12,
                      color: colors.secondaryText,
                    }}
                  >
                    {option.description}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Number of Occurrences */}
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
              marginBottom: 12,
            }}
          >
            Number of Events
          </Text>
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              gap: 8,
            }}
          >
            {OCCURRENCE_OPTIONS.map((option) => {
              const isSelected = occurrences === option.id;
              return (
                <TouchableOpacity
                  key={option.id}
                  style={{
                    backgroundColor: isSelected
                      ? colors.primary
                      : colors.background,
                    borderRadius: 8,
                    paddingVertical: 8,
                    paddingHorizontal: 16,
                    borderWidth: 1,
                    borderColor: isSelected ? colors.primary : colors.border,
                    minWidth: 80,
                    alignItems: "center",
                  }}
                  onPress={() => onOccurrencesChange(option.id)}
                >
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 14,
                      color: isSelected ? "white" : colors.mainText,
                    }}
                  >
                    {option.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Preview Info */}
          {recurrenceType && occurrences && (
            <View
              style={{
                marginTop: 16,
                padding: 12,
                backgroundColor: colors.primary + "05",
                borderRadius: 8,
                borderWidth: 1,
                borderColor: colors.primary + "20",
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                  textAlign: "center",
                }}
              >
                This will create {occurrences} events{" "}
                {recurrenceType === "daily"
                  ? "daily"
                  : recurrenceType === "weekly"
                    ? "weekly"
                    : "monthly"}{" "}
                starting from your selected date
              </Text>
            </View>
          )}
        </View>
      )}
    </View>
  );
}
