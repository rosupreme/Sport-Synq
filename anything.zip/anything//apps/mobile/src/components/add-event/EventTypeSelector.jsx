import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useTheme } from "@/components/ThemeProvider";
import { getEventTypes } from "@/constants/events";

export default function EventTypeSelector({ selectedType, onTypeChange }) {
  const { colors } = useTheme();
  const eventTypes = getEventTypes(colors);

  return (
    <View style={{ marginBottom: 20 }}>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 14,
          color: colors.mainText,
          marginBottom: 8,
        }}
      >
        Event Type
      </Text>
      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          gap: 8,
        }}
      >
        {eventTypes.map((type) => {
          const IconComponent = type.icon;
          const isSelected = selectedType === type.id;

          return (
            <TouchableOpacity
              key={type.id}
              style={{
                backgroundColor: isSelected
                  ? type.color + "20"
                  : colors.surface,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 12,
                borderWidth: 1,
                borderColor: isSelected ? type.color : colors.border,
                flexDirection: "row",
                alignItems: "center",
                minWidth: "45%",
              }}
              onPress={() => onTypeChange(type.id)}
            >
              <IconComponent
                size={18}
                color={isSelected ? type.color : colors.secondaryText}
                style={{ marginRight: 8 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: isSelected ? type.color : colors.mainText,
                }}
              >
                {type.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}
