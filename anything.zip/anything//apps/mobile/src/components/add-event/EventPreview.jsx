import React from "react";
import { View, Text } from "react-native";
import { Calendar, MapPin } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { getEventTypes } from "@/constants/events";

export default function EventPreview({ eventData }) {
  const { colors } = useTheme();
  const eventTypes = getEventTypes(colors);

  const selectedType = eventTypes.find((t) => t.id === eventData.type);
  const IconComponent = selectedType?.icon || Calendar;
  const typeColor = selectedType?.color || colors.primary;
  const typeLabel = selectedType?.label || "Practice";

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: colors.border,
        marginTop: 20,
      }}
    >
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 14,
          color: colors.secondaryText,
          marginBottom: 12,
        }}
      >
        Event Preview
      </Text>

      <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
        <View
          style={{
            width: 48,
            height: 48,
            backgroundColor: colors.primary + "20",
            borderRadius: 24,
            alignItems: "center",
            justifyContent: "center",
            marginRight: 12,
          }}
        >
          <IconComponent size={24} color={colors.primary} />
        </View>

        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 4,
            }}
            numberOfLines={1}
          >
            {eventData.title || "Event Title"}
          </Text>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 2,
            }}
          >
            <Calendar size={14} color={colors.secondaryText} />
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 13,
                color: colors.secondaryText,
                marginLeft: 6,
              }}
            >
              {eventData.date || "Date"} • {eventData.time || "Time"}
            </Text>
          </View>

          {eventData.location && (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 2,
              }}
            >
              <MapPin size={14} color={colors.secondaryText} />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 13,
                  color: colors.secondaryText,
                  marginLeft: 6,
                }}
                numberOfLines={1}
              >
                {eventData.location}
              </Text>
            </View>
          )}

          <View
            style={{
              backgroundColor: typeColor + "20",
              borderRadius: 12,
              paddingHorizontal: 8,
              paddingVertical: 4,
              alignSelf: "flex-start",
              marginTop: 8,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 11,
                color: typeColor,
                textTransform: "uppercase",
                letterSpacing: 0.5,
              }}
            >
              {typeLabel}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}
