import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { ArrowLeft } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";

export function HelpSupportHeader({ onBack }) {
  const { colors } = useTheme();
  const { t } = useLanguage();

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 32,
      }}
    >
      <TouchableOpacity
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: colors.surface,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1,
          borderColor: colors.border,
          marginRight: 16,
        }}
        onPress={onBack}
      >
        <ArrowLeft size={20} color={colors.mainText} />
      </TouchableOpacity>

      <Text
        style={{
          fontFamily: "Inter_700Bold",
          fontSize: 28,
          color: colors.mainText,
        }}
      >
        {t("helpSupport")}
      </Text>
    </View>
  );
}
