import React from "react";
import { View, Text } from "react-native";
import { Mail, Globe } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { ContactCard } from "./ContactCard";
import { handleEmail, handleWebsite } from "@/utils/helpSupport/contactHelpers";

export function ContactSection() {
  const { colors } = useTheme();

  return (
    <>
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 18,
          color: colors.mainText,
          marginBottom: 16,
        }}
      >
        Contact Us
      </Text>

      <ContactCard
        icon={Mail}
        title="Email Support"
        subtitle="sportsynq@gmail.com"
        onPress={handleEmail}
        color={colors.primary}
      />

      <ContactCard
        icon={Globe}
        title="Visit Our Website"
        subtitle="sport-synq.com"
        onPress={handleWebsite}
        color={colors.success}
      />
    </>
  );
}
