import React from "react";
import { View, Text } from "react-native";
import { useTheme } from "@/components/ThemeProvider";

const tips = [
  {
    title: "Invite team members",
    description: "Share your team's invite code to add players and coaches",
  },
  {
    title: "Track attendance",
    description: "Use events to manage practice and game attendance",
  },
  {
    title: "Player evaluations",
    description: "Coaches can create detailed performance evaluations",
  },
];

export function QuickTips() {
  const { colors } = useTheme();

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 20,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      {tips.map((tip, index) => (
        <View
          key={index}
          style={{
            marginBottom: index < tips.length - 1 ? 20 : 0,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
            <View
              style={{
                width: 6,
                height: 6,
                borderRadius: 3,
                backgroundColor: colors.primary,
                marginTop: 7,
                marginRight: 12,
              }}
            />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 15,
                  color: colors.mainText,
                  marginBottom: 4,
                }}
              >
                {tip.title}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.secondaryText,
                  lineHeight: 20,
                }}
              >
                {tip.description}
              </Text>
            </View>
          </View>
        </View>
      ))}
    </View>
  );
}
