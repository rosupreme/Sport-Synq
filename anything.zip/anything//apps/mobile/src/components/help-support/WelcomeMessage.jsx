import React from "react";
import { View, Text } from "react-native";
import { useTheme } from "@/components/ThemeProvider";

export function WelcomeMessage() {
  const { colors } = useTheme();

  return (
    <View
      style={{
        backgroundColor: colors.primary + "10",
        borderRadius: 16,
        padding: 20,
        marginBottom: 32,
        borderWidth: 1,
        borderColor: colors.primary + "20",
      }}
    >
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 18,
          color: colors.mainText,
          marginBottom: 8,
        }}
      >
        We're here to help!
      </Text>
      <Text
        style={{
          fontFamily: "Inter_400Regular",
          fontSize: 15,
          color: colors.secondaryText,
          lineHeight: 22,
        }}
      >
        Have a question or need assistance? Reach out to our support team and
        we'll get back to you as soon as possible.
      </Text>
    </View>
  );
}
