import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { MessageSquare, ChevronRight } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

export function FeedbackNavigationCard({ onPress }) {
  const { colors } = useTheme();

  return (
    <View style={{ marginTop: 32 }}>
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 18,
          color: colors.mainText,
          marginBottom: 16,
        }}
      >
        Community Feedback
      </Text>

      <TouchableOpacity
        onPress={onPress}
        style={{
          backgroundColor: colors.card,
          borderRadius: 12,
          padding: 16,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.05,
          shadowRadius: 2,
          elevation: 2,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", flex: 1 }}>
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: 24,
              backgroundColor: colors.primary + "15",
              alignItems: "center",
              justifyContent: "center",
              marginRight: 12,
            }}
          >
            <MessageSquare size={24} color={colors.primary} />
          </View>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 4,
              }}
            >
              Share Your Ideas
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              View and vote on feature requests
            </Text>
          </View>
        </View>

        <ChevronRight size={20} color={colors.secondaryText} />
      </TouchableOpacity>
    </View>
  );
}
