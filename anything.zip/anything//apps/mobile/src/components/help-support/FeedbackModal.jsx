import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  ScrollView,
  TextInput,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { X, Send } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

export function FeedbackModal({
  visible,
  onClose,
  newFeedback,
  setNewFeedback,
  submitting,
  onSubmit,
}) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 32,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_700Bold",
              fontSize: 24,
              color: colors.mainText,
            }}
          >
            Submit Feedback
          </Text>
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: colors.surface,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
            onPress={onClose}
          >
            <X size={20} color={colors.mainText} />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false}>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            Type
          </Text>
          <View
            style={{
              flexDirection: "row",
              marginBottom: 20,
              gap: 8,
            }}
          >
            {[
              { value: "feature", label: "Feature" },
              { value: "bug", label: "Bug" },
              { value: "improvement", label: "Improvement" },
            ].map((type) => (
              <TouchableOpacity
                key={type.value}
                style={{
                  flex: 1,
                  backgroundColor:
                    newFeedback.feedback_type === type.value
                      ? colors.primary
                      : colors.surface,
                  borderRadius: 12,
                  paddingVertical: 12,
                  alignItems: "center",
                  borderWidth: 1,
                  borderColor:
                    newFeedback.feedback_type === type.value
                      ? colors.primary
                      : colors.border,
                }}
                onPress={() =>
                  setNewFeedback((prev) => ({
                    ...prev,
                    feedback_type: type.value,
                  }))
                }
              >
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 14,
                    color:
                      newFeedback.feedback_type === type.value
                        ? colors.onPrimary
                        : colors.mainText,
                  }}
                >
                  {type.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            Title
          </Text>
          <TextInput
            style={{
              backgroundColor: colors.surface,
              borderRadius: 12,
              padding: 16,
              fontSize: 16,
              color: colors.mainText,
              borderWidth: 1,
              borderColor: colors.border,
              marginBottom: 20,
            }}
            placeholder="Enter a brief title"
            placeholderTextColor={colors.secondaryText}
            value={newFeedback.title}
            onChangeText={(text) =>
              setNewFeedback((prev) => ({ ...prev, title: text }))
            }
          />

          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            Description (Optional)
          </Text>
          <TextInput
            style={{
              backgroundColor: colors.surface,
              borderRadius: 12,
              padding: 16,
              fontSize: 16,
              color: colors.mainText,
              borderWidth: 1,
              borderColor: colors.border,
              height: 120,
              marginBottom: 20,
            }}
            placeholder="Add more details..."
            placeholderTextColor={colors.secondaryText}
            value={newFeedback.description}
            onChangeText={(text) =>
              setNewFeedback((prev) => ({ ...prev, description: text }))
            }
            multiline
            textAlignVertical="top"
          />

          <TouchableOpacity
            style={{
              backgroundColor: colors.primary,
              borderRadius: 12,
              paddingVertical: 16,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
              opacity: submitting ? 0.7 : 1,
            }}
            onPress={onSubmit}
            disabled={submitting}
          >
            <Send size={20} color={colors.onPrimary} />
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.onPrimary,
                marginLeft: 8,
              }}
            >
              {submitting ? "Submitting..." : "Submit Feedback"}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </Modal>
  );
}
