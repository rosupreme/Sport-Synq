import React from "react";
import { View, Text } from "react-native";
import { Book, MessageCircle, FileText, Shield } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import { HelpCategory } from "./HelpCategory";
import { handleComingSoon } from "@/utils/helpSupport/contactHelpers";

export function HelpTopicsSection() {
  const { colors } = useTheme();
  const { t } = useLanguage();

  return (
    <>
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 18,
          color: colors.mainText,
          marginTop: 32,
          marginBottom: 16,
        }}
      >
        Help Topics
      </Text>

      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          paddingHorizontal: 16,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <HelpCategory
          icon={Book}
          title="Getting Started"
          subtitle="Learn the basics of Sport SynQ"
          onPress={() => handleComingSoon("Getting Started Guide", t)}
        />
        <HelpCategory
          icon={MessageCircle}
          title="FAQs"
          subtitle="Frequently asked questions"
          onPress={() => handleComingSoon("FAQs", t)}
        />
        <HelpCategory
          icon={FileText}
          title="Documentation"
          subtitle="Detailed guides and tutorials"
          onPress={() => handleComingSoon("Documentation", t)}
        />
        <HelpCategory
          icon={Shield}
          title="Privacy & Security"
          subtitle="Learn how we protect your data"
          onPress={() => handleComingSoon("Privacy & Security", t)}
          isLast
        />
      </View>
    </>
  );
}
