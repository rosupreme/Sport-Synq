import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { ExternalLink } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

export function ContactCard({ icon: Icon, title, subtitle, onPress, color }) {
  const { colors } = useTheme();

  return (
    <TouchableOpacity
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 20,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: colors.border,
        flexDirection: "row",
        alignItems: "center",
      }}
      onPress={onPress}
    >
      <View
        style={{
          width: 48,
          height: 48,
          borderRadius: 24,
          backgroundColor: color + "15",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 16,
        }}
      >
        <Icon size={24} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 16,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          {title}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
          }}
        >
          {subtitle}
        </Text>
      </View>
      <ExternalLink size={20} color={colors.secondaryText} />
    </TouchableOpacity>
  );
}
