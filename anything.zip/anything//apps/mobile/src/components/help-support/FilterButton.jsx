import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useTheme } from "@/components/ThemeProvider";

export function FilterButton({
  label,
  value,
  count,
  selectedFilter,
  onSelect,
}) {
  const { colors } = useTheme();
  const isActive = selectedFilter === value;

  return (
    <TouchableOpacity
      style={{
        backgroundColor: isActive ? colors.primary : colors.surface,
        borderRadius: 20,
        paddingHorizontal: 16,
        paddingVertical: 8,
        marginRight: 8,
        borderWidth: 1,
        borderColor: isActive ? colors.primary : colors.border,
        flexDirection: "row",
        alignItems: "center",
      }}
      onPress={() => onSelect(value)}
    >
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 14,
          color: isActive ? colors.onPrimary : colors.mainText,
        }}
      >
        {label}
      </Text>
      {count !== undefined && (
        <View
          style={{
            backgroundColor: isActive ? colors.onPrimary + "30" : colors.border,
            borderRadius: 10,
            paddingHorizontal: 6,
            paddingVertical: 2,
            marginLeft: 6,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 11,
              color: isActive ? colors.onPrimary : colors.secondaryText,
            }}
          >
            {count}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
}
