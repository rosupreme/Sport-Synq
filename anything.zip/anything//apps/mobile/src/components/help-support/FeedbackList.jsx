import React from "react";
import { View, Text, ActivityIndicator } from "react-native";
import { MessageCircle } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { FeedbackCard } from "./FeedbackCard";

export function FeedbackList({
  loading,
  filteredFeedback,
  selectedFilter,
  onVote,
}) {
  const { colors } = useTheme();

  if (loading) {
    return (
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 40,
          alignItems: "center",
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <ActivityIndicator size="large" color={colors.primary} />
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
            marginTop: 12,
          }}
        >
          Loading feedback...
        </Text>
      </View>
    );
  }

  if (filteredFeedback.length === 0) {
    return (
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 32,
          alignItems: "center",
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <MessageCircle size={40} color={colors.secondaryText} />
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 16,
            color: colors.mainText,
            marginTop: 12,
          }}
        >
          {selectedFilter === "all"
            ? "No feedback yet"
            : `No ${selectedFilter}s yet`}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
            marginTop: 4,
            textAlign: "center",
          }}
        >
          {selectedFilter === "all"
            ? "Be the first to suggest a feature or report an issue!"
            : `No ${selectedFilter}s have been submitted yet.`}
        </Text>
      </View>
    );
  }

  return (
    <>
      {filteredFeedback.map((item) => (
        <FeedbackCard key={item.id} item={item} onVote={onVote} />
      ))}
    </>
  );
}
