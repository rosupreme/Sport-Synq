import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { ThumbsUp } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { getInitials, getAvatarColor } from "@/utils/helpSupport/avatarHelpers";

export function FeedbackCard({ item, onVote }) {
  const { colors } = useTheme();
  const avatarColor = getAvatarColor(item.author_name);
  const initials = getInitials(item.author_name);

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
        {/* Vote Section */}
        <TouchableOpacity
          style={{
            alignItems: "center",
            marginRight: 12,
            minWidth: 48,
          }}
          onPress={() => onVote(item.id)}
        >
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: item.user_has_voted
                ? colors.primary + "20"
                : colors.border + "40",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 4,
            }}
          >
            <ThumbsUp
              size={18}
              color={
                item.user_has_voted ? colors.primary : colors.secondaryText
              }
              fill={item.user_has_voted ? colors.primary : "transparent"}
            />
          </View>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 13,
              color: item.user_has_voted
                ? colors.primary
                : colors.secondaryText,
            }}
          >
            {item.votes}
          </Text>
        </TouchableOpacity>

        {/* Content Section */}
        <View style={{ flex: 1 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            {/* User Avatar */}
            <View
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: avatarColor,
                alignItems: "center",
                justifyContent: "center",
                marginRight: 10,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 12,
                  color: "#FFFFFF",
                }}
              >
                {initials}
              </Text>
            </View>

            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.mainText,
                }}
              >
                {item.author_name}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                }}
              >
                {new Date(item.created_at).toLocaleDateString()}
              </Text>
            </View>

            {/* Category Badge */}
            <View
              style={{
                backgroundColor:
                  item.feedback_type === "feature"
                    ? colors.primary + "15"
                    : item.feedback_type === "bug"
                      ? colors.alert + "15"
                      : colors.warning + "15",
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 12,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 11,
                  color:
                    item.feedback_type === "feature"
                      ? colors.primary
                      : item.feedback_type === "bug"
                        ? colors.alert
                        : colors.warning,
                }}
              >
                {item.feedback_type.charAt(0).toUpperCase() +
                  item.feedback_type.slice(1)}
              </Text>
            </View>
          </View>

          {/* Title */}
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 6,
              lineHeight: 22,
            }}
          >
            {item.title}
          </Text>

          {/* Description */}
          {item.description && (
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
                lineHeight: 20,
                marginBottom: 8,
              }}
              numberOfLines={3}
            >
              {item.description}
            </Text>
          )}

          {/* Status Badge */}
          {item.status !== "open" && (
            <View
              style={{
                backgroundColor: colors.success + "15",
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 12,
                alignSelf: "flex-start",
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 11,
                  color: colors.success,
                }}
              >
                {item.status.toUpperCase().replace("_", " ")}
              </Text>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}
