import React from "react";
import { View, Text, TouchableOpacity, ScrollView } from "react-native";
import { Plus } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { FilterButton } from "./FilterButton";
import { FeedbackList } from "./FeedbackList";

export function FeedbackSection({
  feedbackList,
  loadingFeedback,
  selectedFilter,
  setSelectedFilter,
  filteredFeedback,
  onVote,
  onAddFeedback,
}) {
  const { colors } = useTheme();

  return (
    <>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          marginTop: 32,
          marginBottom: 16,
        }}
      >
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 18,
            color: colors.mainText,
          }}
        >
          Community Feedback
        </Text>
        <TouchableOpacity
          style={{
            backgroundColor: colors.primary,
            borderRadius: 20,
            paddingHorizontal: 12,
            paddingVertical: 6,
            flexDirection: "row",
            alignItems: "center",
          }}
          onPress={onAddFeedback}
        >
          <Plus size={16} color={colors.onPrimary} />
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 14,
              color: colors.onPrimary,
              marginLeft: 4,
            }}
          >
            Add
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ marginBottom: 16 }}
        contentContainerStyle={{ paddingRight: 16 }}
      >
        <FilterButton
          label="All"
          value="all"
          count={feedbackList.length}
          selectedFilter={selectedFilter}
          onSelect={setSelectedFilter}
        />
        <FilterButton
          label="Features"
          value="feature"
          count={
            feedbackList.filter((f) => f.feedback_type === "feature").length
          }
          selectedFilter={selectedFilter}
          onSelect={setSelectedFilter}
        />
        <FilterButton
          label="Bugs"
          value="bug"
          count={feedbackList.filter((f) => f.feedback_type === "bug").length}
          selectedFilter={selectedFilter}
          onSelect={setSelectedFilter}
        />
        <FilterButton
          label="Improvements"
          value="improvement"
          count={
            feedbackList.filter((f) => f.feedback_type === "improvement").length
          }
          selectedFilter={selectedFilter}
          onSelect={setSelectedFilter}
        />
      </ScrollView>

      <FeedbackList
        loading={loadingFeedback}
        filteredFeedback={filteredFeedback}
        selectedFilter={selectedFilter}
        onVote={onVote}
      />
    </>
  );
}
