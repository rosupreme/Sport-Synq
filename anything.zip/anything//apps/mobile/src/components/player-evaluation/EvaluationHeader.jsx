import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { ArrowLeft, Trash2 } from "lucide-react-native";

export function EvaluationHeader({
  insets,
  colors,
  isNewEvaluation,
  player,
  isLoading,
  onBack,
  onDelete,
  onSaveDraft,
  onSubmit,
}) {
  return (
    <View
      style={{
        paddingTop: insets.top + 20,
        paddingHorizontal: 16,
        paddingBottom: 16,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 12,
        }}
      >
        <TouchableOpacity
          style={{
            width: 40,
            height: 40,
            backgroundColor: colors.lavender,
            borderRadius: 20,
            alignItems: "center",
            justifyContent: "center",
          }}
          onPress={onBack}
        >
          <ArrowLeft size={20} color={colors.primary} />
        </TouchableOpacity>

        <View style={{ flex: 1, alignItems: "center" }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
            }}
          >
            {isNewEvaluation ? "New Evaluation" : "Edit"}
          </Text>
        </View>

        <View style={{ flexDirection: "row", gap: 8 }}>
          {!isNewEvaluation && (
            <TouchableOpacity
              style={{
                backgroundColor: colors.alert + "20",
                borderRadius: 20,
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderWidth: 1,
                borderColor: colors.alert + "40",
              }}
              onPress={onDelete}
              disabled={isLoading}
            >
              <Trash2 size={16} color={colors.alert} />
            </TouchableOpacity>
          )}

          <TouchableOpacity
            style={{
              backgroundColor: colors.surface,
              borderRadius: 20,
              paddingHorizontal: 12,
              paddingVertical: 8,
              borderWidth: 1,
              borderColor: colors.border,
            }}
            onPress={onSaveDraft}
            disabled={isLoading}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.mainText,
              }}
            >
              Save Draft
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              backgroundColor: colors.primary,
              borderRadius: 20,
              paddingHorizontal: 12,
              paddingVertical: 8,
            }}
            onPress={onSubmit}
            disabled={isLoading}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: "white",
              }}
            >
              Submit
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Player Info */}
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          padding: 12,
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <View
          style={{
            width: 40,
            height: 40,
            backgroundColor: colors.primary + "20",
            borderRadius: 20,
            alignItems: "center",
            justifyContent: "center",
            marginRight: 12,
          }}
        >
          <Text style={{ fontSize: 16 }}>👤</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
            }}
          >
            {player.name}
          </Text>
          {player.position && (
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {player.position}
            </Text>
          )}
        </View>
      </View>
    </View>
  );
}
