import React from "react";
import { View, Text } from "react-native";
import { SkillRating } from "./SkillRating";

export function SkillsRatingSection({
  colors,
  skillCategories,
  evaluation,
  updateEvaluation,
  getScoreColor,
  getScoreLabel,
}) {
  return (
    <>
      {skillCategories.map((category) => (
        <View
          key={category.title}
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            {category.title}
          </Text>

          {category.skills.map((skill) => (
            <SkillRating
              key={skill.key}
              skill={skill}
              value={evaluation[skill.key]}
              onValueChange={(value) => updateEvaluation(skill.key, value)}
              colors={colors}
              getScoreColor={getScoreColor}
              getScoreLabel={getScoreLabel}
            />
          ))}
        </View>
      ))}
    </>
  );
}
