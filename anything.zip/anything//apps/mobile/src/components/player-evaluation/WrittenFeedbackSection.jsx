import React from "react";
import { View, Text } from "react-native";
import { Star, Target, TrendingUp, FileText } from "lucide-react-native";
import { TextAreaField } from "./TextAreaField";

export function WrittenFeedbackSection({
  colors,
  strengths,
  setStrengths,
  areasForImprovement,
  setAreasForImprovement,
  goalsNextPeriod,
  setGoalsNextPeriod,
  coachNotes,
  setCoachNotes,
}) {
  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 16,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 16,
          color: colors.mainText,
          marginBottom: 16,
        }}
      >
        Written Feedback
      </Text>

      <TextAreaField
        label="Strengths"
        placeholder="What does this player do well? Highlight their key strengths..."
        value={strengths}
        onChangeText={setStrengths}
        icon={Star}
        colors={colors}
      />

      <TextAreaField
        label="Areas for Improvement"
        placeholder="What areas should this player focus on developing..."
        value={areasForImprovement}
        onChangeText={setAreasForImprovement}
        icon={Target}
        colors={colors}
      />

      <TextAreaField
        label="Goals for Next Period"
        placeholder="What specific goals should this player work towards..."
        value={goalsNextPeriod}
        onChangeText={setGoalsNextPeriod}
        icon={TrendingUp}
        colors={colors}
      />

      <TextAreaField
        label="Coach Notes"
        placeholder="Additional notes, observations, or recommendations..."
        value={coachNotes}
        onChangeText={setCoachNotes}
        icon={FileText}
        colors={colors}
      />
    </View>
  );
}
