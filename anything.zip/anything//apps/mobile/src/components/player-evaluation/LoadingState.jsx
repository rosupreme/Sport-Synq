import React from "react";
import { View, Text, ActivityIndicator } from "react-native";
import ScreenWrapper from "@/components/ScreenWrapper";

export function LoadingState({ insets, colors }) {
  return (
    <ScreenWrapper>
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top + 20,
        }}
      >
        <ActivityIndicator size="large" color={colors.primary} />
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 16,
            color: colors.secondaryText,
            marginTop: 16,
          }}
        >
          Loading player details...
        </Text>
      </View>
    </ScreenWrapper>
  );
}
