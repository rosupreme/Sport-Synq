import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { User } from "lucide-react-native";
import ScreenWrapper from "@/components/ScreenWrapper";

export function PlayerNotFoundState({ insets, colors, onGoBack }) {
  return (
    <ScreenWrapper>
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
        }}
      >
        <User
          size={64}
          color={colors.secondaryText}
          style={{ marginBottom: 16 }}
        />
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 18,
            color: colors.mainText,
            marginBottom: 8,
            textAlign: "center",
          }}
        >
          Player Not Found
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 16,
            color: colors.secondaryText,
            textAlign: "center",
            marginBottom: 24,
          }}
        >
          The player you're trying to evaluate doesn't exist or has been
          removed.
        </Text>
        <TouchableOpacity
          style={{
            backgroundColor: colors.primary,
            borderRadius: 12,
            paddingHorizontal: 24,
            paddingVertical: 12,
          }}
          onPress={onGoBack}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: "white",
            }}
          >
            Go Back
          </Text>
        </TouchableOpacity>
      </View>
    </ScreenWrapper>
  );
}
