import React from "react";
import { View, Text, TouchableOpacity } from "react-native";

export function SkillRating({
  skill,
  value,
  onValueChange,
  colors,
  getScoreColor,
  getScoreLabel,
}) {
  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 12,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Text style={{ fontSize: 20, marginRight: 8 }}>{skill.icon}</Text>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 15,
              color: colors.mainText,
            }}
          >
            {skill.label}
          </Text>
        </View>
        <View style={{ alignItems: "flex-end" }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: getScoreColor(value),
            }}
          >
            {value}/10
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 12,
              color: getScoreColor(value),
            }}
          >
            {getScoreLabel(value)}
          </Text>
        </View>
      </View>

      {/* Rating Slider */}
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((score) => (
          <TouchableOpacity
            key={score}
            style={{
              flex: 1,
              height: 6,
              backgroundColor:
                score <= value ? getScoreColor(value) : colors.border,
              marginHorizontal: 1,
              borderRadius: 3,
            }}
            onPress={() => onValueChange(score)}
          />
        ))}
      </View>

      {/* Number selector */}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginTop: 8,
        }}
      >
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((score) => (
          <TouchableOpacity
            key={score}
            style={{
              width: 28,
              height: 28,
              borderRadius: 14,
              backgroundColor:
                score === value ? getScoreColor(value) : "transparent",
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor:
                score === value ? getScoreColor(value) : colors.border,
            }}
            onPress={() => onValueChange(score)}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 12,
                color: score === value ? "white" : colors.secondaryText,
              }}
            >
              {score}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}
