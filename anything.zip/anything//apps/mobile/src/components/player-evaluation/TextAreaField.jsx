import React from "react";
import { View, Text, TextInput } from "react-native";

export const TextAreaField = React.memo(
  ({ label, placeholder, value, onChangeText, icon: Icon, colors }) => (
    <View style={{ marginBottom: 20 }}>
      <View
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}
      >
        {Icon && (
          <Icon size={16} color={colors.primary} style={{ marginRight: 8 }} />
        )}
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 14,
            color: colors.mainText,
          }}
        >
          {label}
        </Text>
      </View>
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          flexDirection: "row",
          alignItems: "flex-start",
          paddingHorizontal: 16,
          paddingVertical: 16,
        }}
      >
        <TextInput
          placeholder={placeholder}
          placeholderTextColor={colors.secondaryText}
          value={value}
          onChangeText={onChangeText}
          multiline={true}
          numberOfLines={4}
          style={{
            flex: 1,
            fontFamily: "Inter_400Regular",
            fontSize: 15,
            color: colors.mainText,
            minHeight: 80,
            maxHeight: 120,
            textAlignVertical: "top",
            paddingVertical: 0,
          }}
          returnKeyType="default"
          blurOnSubmit={false}
          autoCorrect={true}
          spellCheck={true}
          autoCapitalize="sentences"
        />
      </View>
    </View>
  ),
);
