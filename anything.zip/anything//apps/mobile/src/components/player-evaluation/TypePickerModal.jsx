import React from "react";
import { View, Text, TouchableOpacity, Modal } from "react-native";

export function TypePickerModal({
  visible,
  onClose,
  colors,
  insets,
  evaluationTypes,
  selectedType,
  onSelectType,
}) {
  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingBottom: insets.bottom + 20,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: colors.border,
            }}
          >
            <TouchableOpacity onPress={onClose}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.secondaryText,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 17,
                color: colors.mainText,
              }}
            >
              Evaluation Type
            </Text>
            <View style={{ width: 60 }} />
          </View>

          <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
            {evaluationTypes.map((type) => (
              <TouchableOpacity
                key={type.id}
                style={{
                  backgroundColor: colors.background,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor:
                    selectedType === type.id ? colors.primary : colors.border,
                }}
                onPress={() => {
                  onSelectType(type.id);
                  onClose();
                }}
              >
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 16,
                    color:
                      selectedType === type.id
                        ? colors.primary
                        : colors.mainText,
                    marginBottom: 4,
                  }}
                >
                  {type.label}
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 14,
                    color: colors.secondaryText,
                  }}
                >
                  {type.description}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>
    </Modal>
  );
}
