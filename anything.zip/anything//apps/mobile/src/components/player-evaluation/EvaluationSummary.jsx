import React from "react";
import { View, Text } from "react-native";

export function EvaluationSummary({ colors, evaluation }) {
  const technicalAverage =
    (evaluation.ballControl +
      evaluation.passing +
      evaluation.shooting +
      evaluation.defending) /
    4;

  const mentalPhysicalAverage =
    (evaluation.fitnessLevel +
      evaluation.teamwork +
      evaluation.attitude +
      evaluation.leadership) /
    4;

  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 16,
          color: colors.mainText,
          marginBottom: 16,
        }}
      >
        Evaluation Summary
      </Text>

      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginBottom: 12,
        }}
      >
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
          }}
        >
          Overall Technical Average
        </Text>
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 14,
            color: colors.primary,
          }}
        >
          {technicalAverage.toFixed(1)}/10
        </Text>
      </View>

      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
          }}
        >
          Overall Mental/Physical Average
        </Text>
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 14,
            color: colors.primary,
          }}
        >
          {mentalPhysicalAverage.toFixed(1)}/10
        </Text>
      </View>
    </View>
  );
}
