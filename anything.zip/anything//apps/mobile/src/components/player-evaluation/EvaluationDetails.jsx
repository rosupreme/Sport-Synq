import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { FileText, ChevronDown } from "lucide-react-native";

export function EvaluationDetails({
  colors,
  evaluation,
  evaluationTypes,
  onShowTypePicker,
}) {
  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 16,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 16,
          color: colors.mainText,
          marginBottom: 16,
        }}
      >
        Evaluation Details
      </Text>

      <TouchableOpacity
        style={{
          backgroundColor: colors.background,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 14,
          marginBottom: 12,
        }}
        onPress={onShowTypePicker}
      >
        <FileText
          size={20}
          color={colors.secondaryText}
          style={{ marginRight: 12 }}
        />
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 12,
              color: colors.secondaryText,
              marginBottom: 2,
            }}
          >
            Evaluation Type
          </Text>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
            }}
          >
            {
              evaluationTypes.find((t) => t.id === evaluation.evaluationType)
                ?.label
            }
          </Text>
        </View>
        <ChevronDown size={20} color={colors.secondaryText} />
      </TouchableOpacity>

      <View
        style={{
          backgroundColor: colors.background,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 14,
        }}
      >
        <Text style={{ fontSize: 20, marginRight: 12 }}>📅</Text>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 12,
              color: colors.secondaryText,
              marginBottom: 2,
            }}
          >
            Season
          </Text>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
            }}
          >
            {evaluation.season}
          </Text>
        </View>
      </View>
    </View>
  );
}
