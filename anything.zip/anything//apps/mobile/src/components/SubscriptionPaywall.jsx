import React, { useState, useCallback, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  Animated,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import Carousel from "react-native-reanimated-carousel";
import {
  User,
  Users,
  UsersRound,
  Check,
  ArrowRight,
  X,
  Calendar,
  BarChart3,
  MessageSquare,
  Shield,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from "@expo-google-fonts/inter";
import ScreenWrapper from "./ScreenWrapper";

const PLANS = [
  {
    key: "standard",
    name: "Standard",
    subtitle: "Perfect for individual coaches",
    teamCount: "1 Team",
    price: "$9.99",
    icon: User,
    badge: null,
    features: [
      { icon: Users, text: "Manage up to 25 players" },
      { icon: Calendar, text: "Unlimited events & schedules" },
      { icon: BarChart3, text: "Player performance tracking" },
      { icon: MessageSquare, text: "Team messaging" },
    ],
  },
  {
    key: "plus",
    name: "Plus",
    subtitle: "Great for multi-sport coaches",
    teamCount: "Up to 3 Teams",
    price: "$19.99",
    icon: Users,
    badge: "MOST POPULAR",
    features: [
      { icon: Users, text: "Manage up to 75 players total" },
      { icon: Calendar, text: "Unlimited events & schedules" },
      { icon: BarChart3, text: "Advanced analytics" },
      { icon: Shield, text: "Priority support" },
    ],
  },
  {
    key: "pro",
    name: "Pro",
    subtitle: "For clubs & organizations",
    teamCount: "Up to 10 Teams",
    price: "$39.99",
    icon: UsersRound,
    badge: "BEST VALUE",
    features: [
      { icon: Users, text: "Manage up to 250 players" },
      { icon: Calendar, text: "Multi-team scheduling" },
      { icon: BarChart3, text: "Full analytics suite" },
      { icon: Shield, text: "Dedicated support" },
    ],
  },
];

// Teal accent color
const TEAL = "#33BAA3";
// Blue primary
const BLUE_PRIMARY = "#1F75FA";
const BLUE_DARK = "#0D59E6";

function PlanCard({ plan, isSelected, cardWidth, cardHeight }) {
  const IconComponent = plan.icon;

  return (
    <View
      style={{
        width: cardWidth,
        height: cardHeight,
        paddingHorizontal: 8,
      }}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(255,255,255,0.92)",
          borderRadius: 24,
          borderWidth: isSelected ? 3 : 1,
          borderColor: isSelected ? BLUE_PRIMARY : "rgba(0,0,0,0.08)",
          paddingHorizontal: 24,
          paddingVertical: 24,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 12 },
          shadowOpacity: 0.15,
          shadowRadius: 20,
          elevation: 8,
        }}
      >
        {/* Badge */}
        {plan.badge ? (
          <View
            style={{
              position: "absolute",
              top: -14,
              alignSelf: "center",
              left: 0,
              right: 0,
              alignItems: "center",
            }}
          >
            <View
              style={{
                backgroundColor: plan.key === "plus" ? TEAL : BLUE_PRIMARY,
                paddingHorizontal: 16,
                paddingVertical: 8,
                borderRadius: 999,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_700Bold",
                  fontSize: 12,
                  color: "white",
                  letterSpacing: 0.5,
                }}
              >
                {plan.badge}
              </Text>
            </View>
          </View>
        ) : null}

        {/* Icon & Plan Name */}
        <View style={{ alignItems: "center", marginTop: plan.badge ? 8 : 0 }}>
          <View
            style={{
              width: 72,
              height: 72,
              borderRadius: 36,
              backgroundColor: "rgba(31, 117, 250, 0.1)",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 16,
            }}
          >
            <IconComponent size={32} color={BLUE_PRIMARY} strokeWidth={2} />
          </View>

          <Text
            style={{
              fontFamily: "Inter_700Bold",
              fontSize: 28,
              color: "#1a1a1a",
              marginBottom: 4,
            }}
          >
            {plan.name}
          </Text>

          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 15,
              color: "#666",
              textAlign: "center",
              marginBottom: 8,
            }}
          >
            {plan.subtitle}
          </Text>

          {/* Team count badge */}
          <View
            style={{
              backgroundColor: "rgba(51, 186, 163, 0.15)",
              paddingHorizontal: 14,
              paddingVertical: 6,
              borderRadius: 999,
              marginBottom: 16,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 14,
                color: TEAL,
              }}
            >
              {plan.teamCount}
            </Text>
          </View>
        </View>

        {/* Price */}
        <View
          style={{
            alignItems: "center",
            marginBottom: 20,
            paddingVertical: 16,
            borderTopWidth: 1,
            borderBottomWidth: 1,
            borderColor: "rgba(0,0,0,0.06)",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "baseline" }}>
            <Text
              style={{
                fontFamily: "Inter_700Bold",
                fontSize: 42,
                color: BLUE_PRIMARY,
              }}
            >
              {plan.price}
            </Text>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: "#666",
                marginLeft: 6,
              }}
            >
              /month
            </Text>
          </View>
        </View>

        {/* Features */}
        <View style={{ flex: 1 }}>
          {plan.features.map((feature, index) => {
            const FeatureIcon = feature.icon;
            return (
              <View
                key={index}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 14,
                }}
              >
                <View
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: "rgba(51, 186, 163, 0.12)",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <Check size={16} color={TEAL} strokeWidth={3} />
                </View>
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 15,
                    color: "#444",
                    flex: 1,
                  }}
                >
                  {feature.text}
                </Text>
              </View>
            );
          })}
        </View>
      </View>
    </View>
  );
}

function PaginationDots({ activeIndex, total }) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 20,
        gap: 8,
      }}
    >
      {Array.from({ length: total }).map((_, index) => (
        <View
          key={index}
          style={{
            width: activeIndex === index ? 24 : 8,
            height: 8,
            borderRadius: 4,
            backgroundColor:
              activeIndex === index ? BLUE_PRIMARY : "rgba(0,0,0,0.15)",
          }}
        />
      ))}
    </View>
  );
}

export default function SubscriptionPaywall({ onDismiss }) {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { width, height } = useWindowDimensions();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  const [activeIndex, setActiveIndex] = useState(1); // Start on Plus (middle card)
  const selectedPlan = PLANS[activeIndex]?.key || "plus";

  const handleStartTrial = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push("/subscriptions");
  }, [router]);

  const handleClose = useCallback(() => {
    if (typeof onDismiss === "function") {
      onDismiss();
      return;
    }
    router.back();
  }, [onDismiss, router]);

  const onSnapToItem = useCallback((index) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setActiveIndex(index);
  }, []);

  if (!fontsLoaded) {
    return null;
  }

  const cardWidth = width * 0.85;
  const cardHeight = height * 0.58;

  return (
    <ScreenWrapper>
      <LinearGradient
        colors={["#F0F4FF", "#E6EFFF"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 12,
            paddingHorizontal: 20,
          }}
        >
          {/* Close button */}
          <View style={{ alignItems: "flex-end" }}>
            <TouchableOpacity
              onPress={handleClose}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: "rgba(0,0,0,0.06)",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <X size={20} color="#666" />
            </TouchableOpacity>
          </View>

          {/* Title */}
          <View style={{ alignItems: "center", marginTop: 8 }}>
            <Text
              style={{
                fontFamily: "Inter_700Bold",
                fontSize: 26,
                color: "#1a1a1a",
                textAlign: "center",
                marginBottom: 8,
              }}
            >
              Choose Your Plan
            </Text>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: "#666",
                textAlign: "center",
              }}
            >
              Start with a 7-day free trial
            </Text>
          </View>
        </View>

        {/* Carousel */}
        <View style={{ flex: 1, marginTop: 24 }}>
          <Carousel
            data={PLANS}
            renderItem={({ item, index }) => (
              <PlanCard
                plan={item}
                isSelected={activeIndex === index}
                cardWidth={cardWidth}
                cardHeight={cardHeight}
              />
            )}
            width={cardWidth}
            height={cardHeight}
            style={{
              width: width,
              justifyContent: "center",
            }}
            defaultIndex={1}
            onSnapToItem={onSnapToItem}
            mode="parallax"
            modeConfig={{
              parallaxScrollingScale: 0.9,
              parallaxScrollingOffset: 50,
            }}
            panGestureHandlerProps={{
              activeOffsetX: [-10, 10],
            }}
          />

          {/* Pagination dots */}
          <PaginationDots activeIndex={activeIndex} total={PLANS.length} />
        </View>

        {/* Bottom CTA */}
        <View
          style={{
            paddingHorizontal: 24,
            paddingBottom: insets.bottom + 16,
            paddingTop: 16,
          }}
        >
          <TouchableOpacity onPress={handleStartTrial} activeOpacity={0.9}>
            <LinearGradient
              colors={[BLUE_PRIMARY, BLUE_DARK]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 18,
                borderRadius: 16,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 10 },
                shadowOpacity: 0.2,
                shadowRadius: 16,
                elevation: 8,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 18,
                  color: "white",
                  marginRight: 10,
                }}
              >
                Start Free Trial — {PLANS[activeIndex]?.name}
              </Text>
              <ArrowRight size={18} color="white" strokeWidth={2.5} />
            </LinearGradient>
          </TouchableOpacity>

          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 13,
              color: "#666",
              textAlign: "center",
              marginTop: 12,
            }}
          >
            Cancel anytime. No charge until trial ends.
          </Text>
        </View>
      </LinearGradient>
    </ScreenWrapper>
  );
}
