import React from "react";
import { View, Text } from "react-native";
import { useTheme } from "./ThemeProvider";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
} from "@expo-google-fonts/inter";

export default function EmptyState({ emoji, title, description, style }) {
  const { colors } = useTheme();
  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View
      style={[
        {
          alignItems: "center",
          justifyContent: "center",
          paddingVertical: 60,
          paddingHorizontal: 32,
        },
        style,
      ]}
    >
      <View
        style={{
          width: 80,
          height: 80,
          backgroundColor: colors.lavender,
          borderRadius: 40,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 16,
        }}
      >
        <Text style={{ fontSize: 32 }}>{emoji}</Text>
      </View>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 18,
          color: colors.mainText,
          textAlign: "center",
          marginBottom: 8,
        }}
      >
        {title}
      </Text>
      <Text
        style={{
          fontFamily: "Inter_400Regular",
          fontSize: 15,
          color: colors.secondaryText,
          textAlign: "center",
          lineHeight: 22,
        }}
      >
        {description}
      </Text>
    </View>
  );
}
