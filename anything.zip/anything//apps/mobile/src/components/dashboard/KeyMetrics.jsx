import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { Calendar, DollarSign } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

export function KeyMetrics({ fundraisers }) {
  const router = useRouter();
  const { colors } = useTheme();

  // Calculate fundraising stats
  const totalRaised = fundraisers.reduce((sum, f) => sum + f.raised_amount, 0);
  const activeFundraisers = fundraisers.filter(
    (f) => f.status === "active",
  ).length;
  const hasActiveFundraisers = activeFundraisers > 0;

  // TODO: Replace with actual RSVP data from events
  const pendingRSVPs = 3; // Placeholder - will be calculated from events data

  return (
    <View style={{ flexDirection: "row", marginBottom: 24, gap: 12 }}>
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 20,
          flex: 1,
          borderWidth: 1,
          borderColor: colors.border,
        }}
        onPress={() => router.push("/schedule")}
      >
        <View
          style={{
            width: 40,
            height: 40,
            backgroundColor: colors.primary + "20",
            borderRadius: 20,
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 12,
          }}
        >
          <Calendar size={20} color={colors.primary} />
        </View>
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 24,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          {pendingRSVPs}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 14,
            color: colors.mainText,
            marginBottom: 2,
          }}
        >
          Pending RSVPs
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 12,
            color: colors.secondaryText,
          }}
        >
          Tap to view schedule
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 20,
          flex: 1,
          borderWidth: 1,
          borderColor: colors.border,
        }}
        onPress={() => router.push("/payments")}
      >
        <View
          style={{
            width: 40,
            height: 40,
            backgroundColor: colors.success + "20",
            borderRadius: 20,
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 12,
          }}
        >
          <DollarSign size={20} color={colors.success} />
        </View>
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 24,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          $
          {totalRaised >= 1000
            ? `${(totalRaised / 1000).toFixed(1)}k`
            : totalRaised}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 14,
            color: colors.mainText,
            marginBottom: 2,
          }}
        >
          Fundraising
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 12,
            color: colors.secondaryText,
          }}
        >
          {hasActiveFundraisers
            ? `${activeFundraisers} active goals`
            : "Start your first goal"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}
