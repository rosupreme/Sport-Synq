import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { Check } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { useUpcomingEvents } from "@/hooks/useUpcomingEvents";
import {
  formatEventTime,
  formatEventDateShort,
  getEventColor,
} from "@/utils/eventFormatters";

export function UpcomingEventsSection() {
  const router = useRouter();
  const { colors } = useTheme();
  const upcomingEvents = useUpcomingEvents();

  if (upcomingEvents.length === 0) {
    return null;
  }

  return (
    <View style={{ marginBottom: 24 }}>
      {/* Header */}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 16,
        }}
      >
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 20,
            color: colors.mainText,
          }}
        >
          Upcoming Events
        </Text>
        <TouchableOpacity
          onPress={() => router.push("/schedule")}
          style={{
            paddingVertical: 6,
            paddingHorizontal: 12,
            backgroundColor: colors.primary + "15",
            borderRadius: 16,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.primary,
            }}
          >
            View All
          </Text>
        </TouchableOpacity>
      </View>

      {/* Events List */}
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          paddingVertical: 8,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        {upcomingEvents.map((event, index) => {
          const { dayOfWeek, dayOfMonth } = formatEventDateShort(
            event.event_date,
          );
          const eventColor = getEventColor(event.event_type, colors);

          return (
            <TouchableOpacity
              key={event.id}
              style={{
                flexDirection: "row",
                paddingVertical: 16,
                paddingHorizontal: 16,
                borderBottomWidth: index < upcomingEvents.length - 1 ? 1 : 0,
                borderBottomColor: colors.border,
              }}
              onPress={() => router.push(`/event-details?id=${event.id}`)}
            >
              {/* Left side - Date and colored line */}
              <View
                style={{
                  alignItems: "center",
                  marginRight: 16,
                  minWidth: 50,
                }}
              >
                <View
                  style={{
                    width: 4,
                    height: "100%",
                    backgroundColor: eventColor,
                    position: "absolute",
                    left: 0,
                    borderRadius: 2,
                  }}
                />

                <View style={{ marginLeft: 12, alignItems: "center" }}>
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 12,
                      color: colors.secondaryText,
                      marginBottom: 2,
                    }}
                  >
                    {dayOfWeek}
                  </Text>
                  <Text
                    style={{
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 18,
                      color: colors.mainText,
                    }}
                  >
                    {dayOfMonth}
                  </Text>
                </View>
              </View>

              {/* Main content */}
              <View style={{ flex: 1 }}>
                {/* Event title and time */}
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    marginBottom: 4,
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontFamily: "Inter_600SemiBold",
                        fontSize: 16,
                        color: colors.mainText,
                        marginBottom: 2,
                      }}
                    >
                      {event.title}
                    </Text>

                    {event.location && (
                      <Text
                        style={{
                          fontFamily: "Inter_400Regular",
                          fontSize: 14,
                          color: colors.secondaryText,
                          marginBottom: 8,
                        }}
                      >
                        {event.location}
                      </Text>
                    )}
                  </View>

                  <View style={{ alignItems: "flex-end" }}>
                    <Text
                      style={{
                        fontFamily: "Inter_500Medium",
                        fontSize: 14,
                        color: colors.mainText,
                      }}
                    >
                      {formatEventTime(event.event_date, event.event_time)}
                    </Text>

                    {/* Weather placeholder - you can integrate real weather API */}
                    {event.event_type?.toLowerCase() === "game" && (
                      <View
                        style={{
                          flexDirection: "row",
                          alignItems: "center",
                          marginTop: 4,
                        }}
                      >
                        <Text style={{ fontSize: 12, marginRight: 4 }}>☀️</Text>
                        <Text
                          style={{
                            fontFamily: "Inter_400Regular",
                            fontSize: 12,
                            color: colors.secondaryText,
                          }}
                        >
                          74°F
                        </Text>
                      </View>
                    )}
                  </View>
                </View>

                {/* RSVP counts */}
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginTop: 8,
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginRight: 16,
                    }}
                  >
                    <View
                      style={{
                        width: 24,
                        height: 24,
                        borderRadius: 12,
                        backgroundColor: colors.success,
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 6,
                      }}
                    >
                      <Check size={14} color={colors.onSuccess} />
                    </View>
                    <Text
                      style={{
                        fontFamily: "Inter_500Medium",
                        fontSize: 14,
                        color: colors.mainText,
                      }}
                    >
                      {Math.floor(Math.random() * 8) + 1}
                    </Text>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginRight: 16,
                    }}
                  >
                    <View
                      style={{
                        width: 24,
                        height: 24,
                        borderRadius: 12,
                        backgroundColor: colors.error,
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 6,
                      }}
                    >
                      <Text
                        style={{
                          color: colors.onError,
                          fontSize: 12,
                          fontWeight: "bold",
                        }}
                      >
                        ×
                      </Text>
                    </View>
                    <Text
                      style={{
                        fontFamily: "Inter_500Medium",
                        fontSize: 14,
                        color: colors.mainText,
                      }}
                    >
                      {Math.floor(Math.random() * 3)}
                    </Text>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                    }}
                  >
                    <View
                      style={{
                        width: 24,
                        height: 24,
                        borderRadius: 12,
                        backgroundColor: colors.secondaryText,
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 6,
                      }}
                    >
                      <Text
                        style={{
                          color: colors.onSurface,
                          fontSize: 12,
                          fontWeight: "bold",
                        }}
                      >
                        ?
                      </Text>
                    </View>
                    <Text
                      style={{
                        fontFamily: "Inter_500Medium",
                        fontSize: 14,
                        color: colors.mainText,
                      }}
                    >
                      {Math.floor(Math.random() * 3) + 1}
                    </Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}
