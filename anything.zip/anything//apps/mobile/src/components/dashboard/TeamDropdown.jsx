import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Modal,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Check, Plus, UserPlus } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import { fetchJson } from "@/utils/api";

export function TeamDropdown({
  visible,
  onClose,
  teams,
  selectedTeam,
  onTeamSelect,
  showCreateTeam = true,
  showJoinTeam = false,
}) {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();

  const handleCreateTeam = async () => {
    try {
      // Check team limit before allowing creation
      const data = await fetchJson("/api/teams/check-limit", {
        method: "POST",
      });

      // Check if user needs a subscription
      if (data.requiresSubscription) {
        Alert.alert(
          "Subscription Required",
          "You need an active subscription to create a team.",
          [
            {
              text: "Cancel",
              style: "cancel",
            },
            {
              text: "View Plans",
              onPress: () => {
                onClose();
                router.push("/subscriptions");
              },
            },
          ],
        );
        return;
      }

      // If user can create a team, proceed
      if (data.canCreateTeam) {
        onClose();
        router.push("/onboarding/coach/team-setup");
        return;
      }

      // User has reached their limit - determine upgrade suggestion
      const { currentTeamCount, teamLimit, tier } = data;

      let upgradeMessage = "";

      if (tier === "standard") {
        upgradeMessage = `You've reached your team limit (${currentTeamCount}/${teamLimit} teams).\n\nUpgrade to Plus to manage up to 3 teams.`;
      } else if (tier === "plus") {
        upgradeMessage = `You've reached your team limit (${currentTeamCount}/${teamLimit} teams).\n\nUpgrade to Pro to manage up to 10 teams.`;
      } else if (tier === "pro") {
        upgradeMessage = `You've reached the maximum team limit (${currentTeamCount}/${teamLimit} teams).\n\nContact us if you need to manage more teams.`;
      } else {
        upgradeMessage = `You've reached your team limit (${currentTeamCount}/${teamLimit} teams).\n\nUpgrade your plan to manage more teams.`;
      }

      // Build buttons array based on tier
      const buttons = [
        {
          text: "Cancel",
          style: "cancel",
        },
      ];

      // Add upgrade button for non-pro tiers
      if (tier !== "pro") {
        buttons.push({
          text: "Upgrade",
          onPress: () => {
            onClose();
            router.push("/subscriptions");
          },
        });
      }

      // Show alert with upgrade option
      Alert.alert("Team Limit Reached", upgradeMessage, buttons);
    } catch (error) {
      console.error("Error checking team limit:", error);

      // Handle specific error statuses
      if (error.status === 401) {
        Alert.alert(
          "Authentication Required",
          "Please sign in to create a team.",
          [{ text: "OK" }],
        );
        return;
      }

      Alert.alert(
        "Error",
        error.message ||
          "Unable to connect to the server. Please check your connection and try again.",
        [{ text: "OK" }],
      );
    }
  };

  const handleJoinTeam = () => {
    onClose();
    router.push("/join-another-team");
  };

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="fade"
      onRequestClose={onClose}
    >
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          justifyContent: "flex-start",
          paddingTop: insets.top + 80,
          paddingHorizontal: 16,
        }}
        activeOpacity={1}
        onPress={onClose}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 12,
            paddingVertical: 8,
            maxHeight: 400,
            shadowColor: "#000",
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,
            elevation: 5,
          }}
        >
          <ScrollView showsVerticalScrollIndicator={false}>
            {teams.map((team) => (
              <TouchableOpacity
                key={team.id}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                }}
                onPress={() => onTeamSelect(team)}
              >
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 16,
                      color: colors.mainText,
                      marginBottom: 2,
                    }}
                  >
                    {team.name}
                  </Text>
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 12,
                      color: colors.secondaryText,
                    }}
                  >
                    {team.sport} • {team.member_count || 0} members
                  </Text>
                </View>
                {selectedTeam?.id === team.id && (
                  <Check size={20} color={colors.primary} />
                )}
              </TouchableOpacity>
            ))}

            {/* Show divider if either button will be shown */}
            {(showCreateTeam || showJoinTeam) && (
              <View
                style={{
                  height: 1,
                  backgroundColor: colors.border,
                  marginVertical: 8,
                  marginHorizontal: 16,
                }}
              />
            )}

            {/* Join Another Team Action (for players) */}
            {showJoinTeam && (
              <TouchableOpacity
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  backgroundColor: colors.success + "10",
                  marginHorizontal: 8,
                  marginBottom: showCreateTeam ? 8 : 4,
                  borderRadius: 8,
                }}
                onPress={handleJoinTeam}
              >
                <View
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: colors.success,
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <UserPlus size={18} color="white" />
                </View>
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 16,
                    color: colors.success,
                  }}
                >
                  {t("joinAnotherTeam")}
                </Text>
              </TouchableOpacity>
            )}

            {/* Create New Team Action (for coaches) */}
            {showCreateTeam && (
              <TouchableOpacity
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  backgroundColor: colors.primary + "10",
                  marginHorizontal: 8,
                  marginBottom: 4,
                  borderRadius: 8,
                }}
                onPress={handleCreateTeam}
              >
                <View
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: colors.primary,
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <Plus size={18} color={colors.onPrimary} />
                </View>
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 16,
                    color: colors.primary,
                  }}
                >
                  {t("createNewTeam")}
                </Text>
              </TouchableOpacity>
            )}
          </ScrollView>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}
