import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { Calendar, Clock, MapPin, Plus } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";
import { formatEventDate } from "@/utils/eventFormatters";

export function NextEventCard({ nextEvent, loading }) {
  const router = useRouter();
  const { colors } = useTheme();

  if (loading) {
    return (
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 20,
          padding: 24,
          marginBottom: 24,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <View style={{ alignItems: "center", paddingVertical: 20 }}>
          <Clock
            size={32}
            color={colors.secondaryText}
            style={{ marginBottom: 8 }}
          />
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
            }}
          >
            Loading events...
          </Text>
        </View>
      </View>
    );
  }

  if (!nextEvent) {
    return (
      <TouchableOpacity
        style={{
          backgroundColor: colors.primary,
          borderRadius: 20,
          padding: 24,
          marginBottom: 24,
        }}
        onPress={() => router.push("/add-event")}
      >
        <View style={{ alignItems: "center", paddingVertical: 20 }}>
          <Plus
            size={32}
            color={colors.onPrimary}
            style={{ marginBottom: 8 }}
          />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 18,
              color: colors.onPrimary,
              marginBottom: 4,
            }}
          >
            No Upcoming Events
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.onPrimary + "CC", // 80% opacity
            }}
          >
            Tap to schedule your first event
          </Text>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      style={{
        backgroundColor: colors.primary,
        borderRadius: 20,
        padding: 24,
        marginBottom: 24,
      }}
      onPress={() => router.push(`/event-details?id=${nextEvent.id}`)}
    >
      <View style={{ alignItems: "center", paddingVertical: 20 }}>
        <Calendar
          size={32}
          color={colors.onPrimary}
          style={{ marginBottom: 8 }}
        />
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 18,
            color: colors.onPrimary,
            marginBottom: 4,
            textAlign: "center",
          }}
        >
          {nextEvent.title || "Untitled Event"}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.onPrimary + "CC", // 80% opacity
            marginBottom: 4,
          }}
        >
          {nextEvent.event_date && nextEvent.event_time
            ? formatEventDate(nextEvent.event_date, nextEvent.event_time)
            : "Date TBD"}
        </Text>
        {nextEvent.location && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginTop: 4,
            }}
          >
            <MapPin
              size={14}
              color={colors.onPrimary + "CC"} // 80% opacity
              style={{ marginRight: 4 }}
            />
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 12,
                color: colors.onPrimary + "CC", // 80% opacity
              }}
            >
              {nextEvent.location}
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}
