import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { ChevronDown, Plus, User } from "lucide-react-native";
import { useTheme } from "@/components/ThemeProvider";

export function DashboardHeader({
  loadingTeams,
  selectedTeam,
  onTeamDropdownPress,
}) {
  const router = useRouter();
  const { colors } = useTheme();

  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "flex-start",
        marginBottom: 24,
      }}
    >
      <View style={{ flex: 1 }}>
        {loadingTeams ? (
          <View>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 28,
                color: colors.mainText,
                marginBottom: 4,
              }}
            >
              Loading...
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.secondaryText,
              }}
            >
              Getting your teams
            </Text>
          </View>
        ) : selectedTeam ? (
          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 4,
            }}
            onPress={onTeamDropdownPress}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 28,
                color: colors.mainText,
                marginRight: 8,
              }}
            >
              {selectedTeam.name}
            </Text>
            <ChevronDown size={24} color={colors.mainText} />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 4,
            }}
            onPress={() => router.push("/add-team")}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 28,
                color: colors.mainText,
                marginRight: 8,
              }}
            >
              Create Team
            </Text>
            <Plus size={24} color={colors.mainText} />
          </TouchableOpacity>
        )}

        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 16,
            color: colors.secondaryText,
          }}
        >
          {selectedTeam
            ? `${selectedTeam.sport} • ${selectedTeam.member_count || 0} members`
            : "Get started by creating your first team"}
        </Text>
      </View>

      {/* Profile Icon */}
      <TouchableOpacity
        style={{
          width: 44,
          height: 44,
          backgroundColor: colors.surface,
          borderRadius: 22,
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1,
          borderColor: colors.border,
        }}
        onPress={() => router.push("/profile")}
      >
        <User size={20} color={colors.mainText} />
      </TouchableOpacity>
    </View>
  );
}
