import React, { createContext, useContext } from "react";
import { useLanguageState } from "@/hooks/useLanguageState";
import {
  getTranslation,
  getLanguageOptions,
  getLanguageName,
} from "@/utils/language/languageHelpers";

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};

export const LanguageProvider = ({ children }) => {
  const { currentLanguage, changeLanguage, isLoading } = useLanguageState();

  const t = (key) => {
    return getTranslation(currentLanguage, key);
  };

  const getLanguageOptionsWithTranslations = () => {
    return getLanguageOptions(t);
  };

  const getCurrentLanguageName = () => {
    return getLanguageName(currentLanguage, t);
  };

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        changeLanguage,
        t,
        getLanguageOptions: getLanguageOptionsWithTranslations,
        getCurrentLanguageName,
        isLoading,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};
