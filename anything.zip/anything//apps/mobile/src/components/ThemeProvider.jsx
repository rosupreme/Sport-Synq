import React, { createContext, useContext, useState, useEffect } from "react";
import { useColorScheme } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Theme utility function
const getThemeColors = (isDark) => ({
  primary: isDark ? "#4A90E2" : "#1473FF",
  secondary: isDark ? "#6B8CC7" : "#1A4EF8",
  success: isDark ? "#4ECDC4" : "#2DB9A2",
  purple: isDark ? "#8B7CF6" : "#6B4DFD",
  alert: isDark ? "#FF6B6B" : "#F25E5E",

  // Add missing error and warning colors
  error: isDark ? "#FF6B6B" : "#F25E5E",
  warning: isDark ? "#FFB800" : "#F59E0B",

  // Text colors
  mainText: isDark ? "#FFFFFF" : "#101216",
  secondaryText: isDark ? "#B8B8B8" : "#5E6572",
  tertiaryText: isDark ? "#888888" : "#B8BDC7",
  bodyText: isDark ? "#E0E0E0" : "#3A3F4C",
  tabInactive: isDark ? "#888888" : "#747880",

  // Surface colors
  background: isDark ? "#121212" : "#EEF3FF",
  surface: isDark ? "#1E1E1E" : "#FFFFFF",
  chipBg: isDark ? "#2A2A2A" : "#F7F8FE",
  lavender: isDark ? "#2A2A2A" : "#F4F5FF",

  // Accent colors
  charcoal: isDark ? "#E8E8E8" : "#50525A",
  gray: isDark ? "#B8B8B8" : "#5F6168",
  lightGray: isDark ? "#888888" : "#A6A8B0",
  slate: isDark ? "#9CA3AF" : "#676775",

  // Borders and dividers
  border: isDark ? "#333333" : "#E6E7F5",
  divider: isDark ? "#2A2A2A" : "#EFF0F7",
  outline: isDark ? "#404040" : "#C5CAE6",

  // Special colors
  eventBlue: isDark ? "#1A3B5C" : "#E9F0FF",

  // Additional colors for sports app
  text: isDark ? "#FFFFFF" : "#000000",
  textSecondary: isDark ? "#B8B8B8" : "#5F6168",
  textTertiary: isDark ? "#888888" : "#A6A8B0",

  // Convenience colors for text on colored backgrounds
  onPrimary: "#FFFFFF", // Text/icons on primary color background
  onSuccess: "#FFFFFF", // Text/icons on success color background
  onError: "#FFFFFF", // Text/icons on error color background
  onWarning: isDark ? "#000000" : "#FFFFFF", // Text/icons on warning color background
  onSurface: isDark ? "#FFFFFF" : "#101216", // Text/icons on surface background
});

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  const systemColorScheme = useColorScheme();
  const [themeMode, setThemeMode] = useState("system"); // 'light', 'dark', 'system'
  const [isReady, setIsReady] = useState(false);

  // Load saved theme preference on mount
  useEffect(() => {
    loadThemePreference();
  }, []);

  const loadThemePreference = async () => {
    try {
      const savedTheme = await AsyncStorage.getItem("themeMode");
      if (savedTheme) {
        setThemeMode(savedTheme);
      }
    } catch (error) {
      console.error("Error loading theme preference:", error);
    } finally {
      setIsReady(true);
    }
  };

  const saveThemePreference = async (mode) => {
    try {
      await AsyncStorage.setItem("themeMode", mode);
    } catch (error) {
      console.error("Error saving theme preference:", error);
    }
  };

  const toggleTheme = () => {
    const modes = ["light", "dark", "system"];
    const currentIndex = modes.indexOf(themeMode);
    const nextMode = modes[(currentIndex + 1) % modes.length];
    setThemeMode(nextMode);
    saveThemePreference(nextMode);
  };

  const setTheme = (mode) => {
    setThemeMode(mode);
    saveThemePreference(mode);
  };

  // Determine if dark mode should be active
  const isDark =
    themeMode === "dark" ||
    (themeMode === "system" && systemColorScheme === "dark");
  const colors = getThemeColors(isDark);

  // Typography scale — single source of truth for sizes across the app
  const typography = {
    title: 28, // Page and screen titles (aligned across all tabs)
    sectionTitle: 18, // Section headers inside pages
    button: 16, // Button text
    pill: 14, // Pills and small badges
    body: 16, // Default body
    small: 12, // Small captions
  };

  // Don't render until theme is loaded
  if (!isReady) {
    return null;
  }

  return (
    <ThemeContext.Provider
      value={{
        colors,
        isDark,
        themeMode,
        toggleTheme,
        setTheme,
        systemColorScheme,
        typography,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}
