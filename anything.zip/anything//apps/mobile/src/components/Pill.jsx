import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { useTheme } from "@/components/ThemeProvider";

// Reusable pill used across pages for consistent look
// Props:
// - label (string)
// - onPress (function?) optional; if provided, pill is pressable
// - style (object?) optional; extra container styles
// - textStyle (object?) optional; extra text styles
// - align ("start" | "center" | "end") optional; default "start"
// - backgroundColor, textColor optional overrides
export default function Pill({
  label,
  onPress,
  style,
  textStyle,
  align = "start",
  backgroundColor,
  textColor,
}) {
  const { colors, typography } = useTheme();
  const Container = onPress ? TouchableOpacity : View;

  const alignSelf =
    align === "center" ? "center" : align === "end" ? "flex-end" : "flex-start";

  return (
    <Container
      onPress={onPress}
      activeOpacity={onPress ? 0.8 : 1}
      style={[
        {
          // Use chipBg by default so it works in both light and dark modes
          backgroundColor: backgroundColor || colors.chipBg,
          paddingHorizontal: 16,
          paddingVertical: 10,
          borderRadius: 20,
          alignSelf,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.08,
          shadowRadius: 4,
        },
        style,
      ]}
    >
      <Text
        style={[
          {
            fontFamily: "Inter_600SemiBold",
            fontSize: typography.pill,
            // Default text color is primary for clear contrast on chipBg
            color: textColor || colors.primary,
            textAlign: "center",
          },
          textStyle,
        ]}
      >
        {label}
      </Text>
    </Container>
  );
}
