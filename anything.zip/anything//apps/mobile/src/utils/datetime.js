export const formatDate = (dateString) => {
  if (!dateString) return "";

  // Parse the date string manually to avoid timezone issues
  const [year, month, day] = dateString.split("-").map(Number);

  // Create date object with local time (avoiding UTC interpretation)
  const date = new Date(year, month - 1, day); // month is 0-indexed

  return date.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
};

export const formatTime = (timeObj) => {
  if (!timeObj.hour && !timeObj.minute) return "";
  const hour =
    timeObj.hour === 0
      ? 12
      : timeObj.hour > 12
        ? timeObj.hour - 12
        : timeObj.hour;
  const minute = timeObj.minute.toString().padStart(2, "0");
  return `${hour}:${minute} ${timeObj.period}`;
};

export const convertDateToDbFormat = (displayDate) => {
  if (!displayDate) return null;
  try {
    // The date is already formatted, we need to parse it back to a Date object
    const date = new Date(displayDate);
    return date.toISOString().split("T")[0]; // YYYY-MM-DD format
  } catch (error) {
    console.error("Error converting date:", error);
    return null;
  }
};

export const convertTimeToDbFormat = (displayTime) => {
  if (!displayTime) return null;
  try {
    const [time, period] = displayTime.split(" ");
    const [hours, minutes] = time.split(":");
    let hour24 = parseInt(hours);

    if (period === "PM" && hour24 !== 12) {
      hour24 += 12;
    } else if (period === "AM" && hour24 === 12) {
      hour24 = 0;
    }

    return `${hour24.toString().padStart(2, "0")}:${minutes.padStart(
      2,
      "0",
    )}:00`;
  } catch (error) {
    console.error("Error converting time:", error);
    return null;
  }
};
