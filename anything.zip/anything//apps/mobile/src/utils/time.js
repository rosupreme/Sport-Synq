export const formatTime = (time) => {
  const date = typeof time === "number" ? new Date(time) : time;
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
};

export const formatMessageTime = (time) => {
  const date = typeof time === "number" ? new Date(time) : time;
  const now = new Date();
  const diffInHours = (now - date) / (1000 * 60 * 60);

  if (diffInHours < 1) {
    return "now";
  } else if (diffInHours < 24) {
    return formatTime(date);
  } else {
    return date.toLocaleDateString();
  }
};

export const formatLastMessageTime = (time) => {
  const date = typeof time === "number" ? new Date(time) : time;
  const now = new Date();
  const diffInMinutes = (now - date) / (1000 * 60);

  if (diffInMinutes < 1) {
    return "now";
  } else if (diffInMinutes < 60) {
    return `${Math.floor(diffInMinutes)}m`;
  } else if (diffInMinutes < 24 * 60) {
    return `${Math.floor(diffInMinutes / 60)}h`;
  } else {
    return `${Math.floor(diffInMinutes / (24 * 60))}d`;
  }
};
