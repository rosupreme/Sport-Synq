export const getDaysRemaining = (endDate) => {
  const today = new Date();
  // Parse dates as local to avoid off-by-one due to UTC parsing of YYYY-MM-DD
  const parseLocalDate = (d) => {
    if (!d) return null;
    if (typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d)) {
      const [y, m, day] = d.split("-").map((n) => parseInt(n, 10));
      return new Date(y, m - 1, day);
    }
    // Fallback to native parsing for full ISO strings
    return new Date(d);
  };

  const end = parseLocalDate(endDate);
  const diffTime = end - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

export const calculateFundraiserStats = (fundraisers) => {
  const totalRaised = fundraisers.reduce((sum, f) => sum + f.raised_amount, 0);
  const activeFundraisers = fundraisers.filter(
    (f) => f.status === "active",
  ).length;
  const totalContributors = fundraisers.reduce(
    (sum, f) => sum + (parseInt(f.contributors) || 0),
    0,
  );
  const completedFundraisers = fundraisers.filter(
    (f) => f.status === "completed" || f.raised_amount / f.goal_amount >= 1,
  ).length;

  return {
    totalRaised,
    activeFundraisers,
    totalContributors,
    completedFundraisers,
  };
};
