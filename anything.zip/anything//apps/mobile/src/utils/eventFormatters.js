export const formatEventDate = (dateString, timeString) => {
  try {
    // Use the same parsing logic as the schedule page
    const eventDate = dateString.split("T")[0]; // Convert from ISO to YYYY-MM-DD
    const eventDateTime = new Date(`${eventDate}T${timeString}`);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (eventDateTime.toDateString() === today.toDateString()) {
      return `Today at ${eventDateTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    } else if (eventDateTime.toDateString() === tomorrow.toDateString()) {
      return `Tomorrow at ${eventDateTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    } else {
      return eventDateTime.toLocaleDateString([], {
        weekday: "short",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    }
  } catch (error) {
    console.error("Error formatting date:", error);
    return "Invalid date";
  }
};

export const formatEventTime = (dateString, timeString) => {
  try {
    const eventDate = dateString.split("T")[0];
    const eventDateTime = new Date(`${eventDate}T${timeString}`);

    // Format time range (assuming 1-2 hour events for now)
    const startTime = eventDateTime.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });

    const endDateTime = new Date(eventDateTime.getTime() + 2 * 60 * 60 * 1000); // Add 2 hours
    const endTime = endDateTime.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });

    return `${startTime} - ${endTime}`;
  } catch (error) {
    return "Time TBD";
  }
};

export const formatEventDateShort = (dateString) => {
  try {
    const eventDate = dateString.split("T")[0];
    const eventDateTime = new Date(`${eventDate}T12:00:00`);

    const dayOfWeek = eventDateTime
      .toLocaleDateString([], { weekday: "short" })
      .toUpperCase();
    const dayOfMonth = eventDateTime.getDate();

    return { dayOfWeek, dayOfMonth };
  } catch (error) {
    return { dayOfWeek: "TBD", dayOfMonth: "" };
  }
};

export const getEventColor = (eventType, colors) => {
  switch (eventType?.toLowerCase()) {
    case "game":
      return colors.primary;
    case "practice":
      return "#FF8C00"; // Orange
    case "meeting":
      return "#6B7280"; // Gray
    default:
      return "#8B5CF6"; // Purple
  }
};
