// Small helper to build absolute API URLs and safely parse JSON responses
// This avoids the common "Unexpected token '<'" error when a relative path
// accidentally hits an HTML page (like an index) instead of your API.

import { Platform } from "react-native";
import { authKey, useAuthStore } from "./auth/store";
import storage from "@/utils/storage";

/**
 * Build the correct URL for API paths.
 *
 * On **native** (iOS / Android) we always need an absolute URL because there
 * is no "same-origin" concept.  We use EXPO_PUBLIC_PROXY_BASE_URL which
 * points at the web/backend server.
 *
 * On **web** (including the mobile web preview) we use **relative paths**.
 * The platform's built-in fetch interceptor (`fetchWithHeaders`) automatically
 * rewrites relative `/api/*` and `/integrations/*` paths to the correct
 * backend server.  Using absolute URLs bypasses this interceptor and
 * causes CORS errors.
 */

const NATIVE_BASE =
  process.env.EXPO_PUBLIC_PROXY_BASE_URL ||
  process.env.EXPO_PUBLIC_BASE_URL ||
  "http://localhost:4000";

export function buildApiUrl(path) {
  if (!path) return NATIVE_BASE;
  // Already absolute – leave it alone
  if (/^https?:\/\//i.test(path)) return path;

  if (Platform.OS === "web") {
    // Always use relative paths on web – the platform's fetch interceptor
    // will route them to the correct backend server automatically.
    return path.startsWith("/") ? path : `/${path}`;
  }

  // Native – always absolute
  const base = NATIVE_BASE.replace(/\/+$/, "");
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${base}${normalizedPath}`;
}

// ---------------------------------------------------------------------------
// Auth headers
// ---------------------------------------------------------------------------
async function getAuthHeaders() {
  // 1) In-memory auth (fastest, always up-to-date right after sign-in)
  try {
    const memAuth = useAuthStore.getState().auth;
    const memToken = memAuth?.sessionToken || memAuth?.jwt;
    if (memToken) {
      return {
        Authorization: `Bearer ${memToken}`,
        "X-Session-Token": memToken,
      };
    }
  } catch (e) {
    console.error("[API] Error reading auth store:", e);
  }

  // 2) Persisted storage fallback
  try {
    const authData = await storage.getItemAsync(authKey);
    if (authData) {
      const parsed = JSON.parse(authData);
      const token = parsed?.sessionToken || parsed?.jwt;
      if (token) {
        return {
          Authorization: `Bearer ${token}`,
          "X-Session-Token": token,
        };
      }
    }
  } catch (e) {
    console.error("[API] Error reading auth from storage:", e);
  }

  return {};
}

// ---------------------------------------------------------------------------
// fetchJson – the single fetch wrapper used by the whole mobile app
// ---------------------------------------------------------------------------
export async function fetchJson(path, options = {}) {
  const url = buildApiUrl(path);

  // Add auth headers if available
  const authHeaders = await getAuthHeaders();
  const headers = {
    "Content-Type": "application/json",
    ...authHeaders,
    ...options.headers,
  };

  console.log("[API] Fetching:", url, "keys:", Object.keys(headers));

  let res;
  try {
    res = await fetch(url, {
      ...options,
      headers,
    });
  } catch (fetchError) {
    console.error("[API] Network error fetching:", url, fetchError);
    const err = new Error(
      `Network error: Unable to connect to ${url}. Please check your internet connection and ensure the server is running.`,
    );
    err.originalError = fetchError;
    err.url = url;
    throw err;
  }

  const text = await res.text();

  // If server returned HTML, surface a friendly error
  const isHtml =
    text.trim().startsWith("<!DOCTYPE") || text.trim().startsWith("<html");
  if (isHtml) {
    const preview = text.slice(0, 200);
    const err = new Error(
      `Server returned HTML instead of JSON for ${url}. This usually means the host is wrong or the route doesn't exist.`,
    );
    err.status = res.status;
    err.preview = preview;
    throw err;
  }

  // Try to parse JSON
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (e) {
    const err = new Error(`Invalid JSON from ${url}: ${e.message}`);
    err.status = res.status;
    err.preview = text.slice(0, 200);
    throw err;
  }

  if (!res.ok) {
    const err = new Error(
      data?.message || data?.error || `Request failed (${res.status})`,
    );
    err.status = res.status;
    err.data = data;
    throw err;
  }

  return data;
}

// Helper for authenticated fetch calls (same as fetchJson, kept for compat)
export async function fetchWithAuth(path, options = {}) {
  return fetchJson(path, options);
}
