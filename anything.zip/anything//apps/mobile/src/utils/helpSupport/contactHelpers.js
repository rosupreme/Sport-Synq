import { Linking, Alert } from "react-native";

export const handleEmail = async () => {
  const email = "sportsynq@gmail.com";
  const subject = "Support Request";
  const url = `mailto:${email}?subject=${encodeURIComponent(subject)}`;

  try {
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    } else {
      Alert.alert("Contact Us", `Please email us at:\n${email}`, [
        {
          text: "Copy Email",
          onPress: () => {
            Alert.alert("Email", email);
          },
        },
        { text: "OK" },
      ]);
    }
  } catch (error) {
    console.error("Error opening email:", error);
    Alert.alert("Contact Us", `Email: ${email}`);
  }
};

export const handleWebsite = async () => {
  const url = "https://sport-synq.com";
  try {
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    } else {
      Alert.alert("Website", url);
    }
  } catch (error) {
    console.error("Error opening website:", error);
    Alert.alert("Website", url);
  }
};

export const handleComingSoon = (feature, t) => {
  Alert.alert(t("comingSoon"), `${feature} ${t("comingSoonMessage")}`, [
    { text: t("ok"), style: "default" },
  ]);
};
