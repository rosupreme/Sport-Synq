export const getInitials = (name) => {
  if (!name) return "??";
  const parts = name.trim().split(" ");
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
};

export const getAvatarColor = (name) => {
  const colors_palette = [
    "#FF6B6B",
    "#4ECDC4",
    "#45B7D1",
    "#FFA07A",
    "#98D8C8",
    "#6C5CE7",
    "#A29BFE",
    "#FD79A8",
  ];
  if (!name) return colors_palette[0];
  const charCode = name.charCodeAt(0);
  return colors_palette[charCode % colors_palette.length];
};
