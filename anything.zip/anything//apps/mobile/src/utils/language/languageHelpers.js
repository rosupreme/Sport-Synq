import { translations } from "@/constants/translations";

export const getTranslation = (languageCode, key) => {
  return translations[languageCode]?.[key] || translations.en[key] || key;
};

export const getLanguageOptions = (t) => [
  { code: "en", name: t("english"), nativeName: "English" },
  { code: "fr", name: t("french"), nativeName: "Français" },
  { code: "es", name: t("spanish"), nativeName: "Español" },
];

export const getLanguageName = (languageCode, t) => {
  const options = getLanguageOptions(t);
  const option = options.find((lang) => lang.code === languageCode);
  return option ? option.nativeName : "English";
};

export const isValidLanguage = (languageCode) => {
  return translations.hasOwnProperty(languageCode);
};
