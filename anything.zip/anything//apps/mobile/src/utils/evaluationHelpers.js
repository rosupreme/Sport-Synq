export const getScoreColor = (score, colors) => {
  if (score >= 7) return colors.success;
  if (score >= 5) return "#F59E0B";
  return colors.alert;
};

export const getScoreLabel = (score) => {
  if (score >= 9) return "Excellent";
  if (score >= 7) return "Good";
  if (score >= 5) return "Average";
  if (score >= 3) return "Needs Work";
  return "Poor";
};

export const evaluationTypes = [
  {
    id: "mid_season",
    label: "Mid-Season",
    description: "Halfway through season",
  },
  {
    id: "end_season",
    label: "End of Season",
    description: "Final evaluation",
  },
  { id: "monthly", label: "Monthly", description: "Monthly check-in" },
];

export const skillCategories = [
  {
    title: "Technical Skills",
    skills: [
      { key: "ballControl", label: "Fundamentals", icon: "🎯" },
      { key: "passing", label: "Game Intelligence", icon: "🧠" },
      { key: "shooting", label: "Execution", icon: "⚡" },
      { key: "defending", label: "Adaptability", icon: "📈" },
    ],
  },
  {
    title: "Physical & Mental",
    skills: [
      { key: "fitnessLevel", label: "Fitness Level", icon: "💪" },
      { key: "teamwork", label: "Teamwork", icon: "🤝" },
      { key: "attitude", label: "Attitude", icon: "😊" },
      { key: "leadership", label: "Leadership", icon: "👑" },
    ],
  },
];
