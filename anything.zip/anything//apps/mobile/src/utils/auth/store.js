import { create } from "zustand";
import storage from "@/utils/storage";

export const authKey = `${process.env.EXPO_PUBLIC_PROJECT_GROUP_ID || "default-app"}-jwt`;

/**
 * This store manages the authentication state of the application.
 */
export const useAuthStore = create((set) => ({
  isReady: false,
  auth: null,
  setAuth: (auth) => {
    if (auth) {
      // Fire-and-forget is fine here; we also mark the store ready so we don't
      // immediately overwrite auth by reading storage before it finishes writing.
      storage.setItemAsync(authKey, JSON.stringify(auth));
    } else {
      storage.deleteItemAsync(authKey);
    }

    // IMPORTANT: mark isReady true whenever we explicitly set auth.
    // This avoids a race where useAuth.initiate() reads storage before the
    // write completes and wipes the in-memory auth.
    set({ auth, isReady: true });
  },
}));
