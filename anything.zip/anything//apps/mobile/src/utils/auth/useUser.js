import { useCallback, useState, useEffect } from "react";
import { useAuth } from "./useAuth";
import { fetchWithAuth } from "../api";

export const useUser = () => {
  const { auth, isReady } = useAuth();
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Support both auth shapes: { sessionToken } and { jwt }
  const token = auth?.sessionToken || auth?.jwt;

  const fetchUser = useCallback(async () => {
    if (!token) {
      setUserData(null);
      setLoading(false);
      return null;
    }

    try {
      setLoading(true);
      const response = await fetchWithAuth("/api/user/profile", {
        method: "GET",
      });

      if (response.user) {
        setUserData(response.user);
        return response.user;
      } else {
        setUserData(null);
        return null;
      }
    } catch (error) {
      console.error("Error fetching user:", error);
      setUserData(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, [token]);

  // Fetch user data when auth is ready and we have a session
  useEffect(() => {
    if (isReady) {
      fetchUser();
    }
  }, [isReady, fetchUser]);

  // Return auth store user as fallback if we don't have fresh data yet
  const user = userData || auth?.user || null;

  return {
    user,
    data: user,
    loading: !isReady || loading,
    refetch: fetchUser,
  };
};

export default useUser;
