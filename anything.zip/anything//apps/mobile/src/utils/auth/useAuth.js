import { router } from "expo-router";
import { useCallback, useEffect } from "react";
import { useAuthStore, authKey } from "./store";
import storage from "@/utils/storage";

/**
 * This hook provides authentication functionality.
 * It may be easier to use the `useRequireAuth` hook
 * instead as it will also handle redirecting to authentication.
 */
export const useAuth = () => {
  const { isReady, auth, setAuth } = useAuthStore();

  const initiate = useCallback(() => {
    // IMPORTANT: if we already have auth in memory (e.g. right after a native
    // signup/signin), don't overwrite it by reading storage (which may not
    // have finished writing yet).
    const existingAuth = useAuthStore.getState().auth;
    if (existingAuth) {
      useAuthStore.setState({ isReady: true });
      return;
    }

    storage
      .getItemAsync(authKey)
      .then((authString) => {
        let finalAuth = null;
        if (authString) {
          try {
            finalAuth = JSON.parse(authString);
          } catch (parseError) {
            console.error("Error parsing stored auth:", parseError);
            finalAuth = null;
          }
        }

        useAuthStore.setState({
          auth: finalAuth,
          isReady: true,
        });
      })
      .catch((error) => {
        console.error("Error getting auth from storage:", error);
        useAuthStore.setState({
          auth: null,
          isReady: true,
        });
      });
  }, []);

  // Auto-initiate on first render
  useEffect(() => {
    if (!isReady) {
      initiate();
    }
  }, [initiate, isReady]);

  const signIn = useCallback(() => {
    router.push("/auth/signin");
  }, []);

  const signUp = useCallback(() => {
    router.push("/auth/signup");
  }, []);

  const signOut = useCallback(async () => {
    try {
      // Clear auth from storage
      await storage.deleteItemAsync(authKey);
      // Clear auth from state
      setAuth(null);
      // Navigate to auth screen
      router.replace("/auth/signin");
    } catch (error) {
      console.error("Error signing out:", error);
      // Even if there's an error, clear the local state
      setAuth(null);
      router.replace("/auth/signin");
    }
  }, [setAuth]);

  return {
    isReady,
    isAuthenticated: isReady ? !!auth : null,
    signIn,
    signOut,
    signUp,
    auth,
    setAuth,
    initiate,
  };
};

/**
 * This hook will automatically redirect to sign in if the user is not authenticated.
 */
export const useRequireAuth = (options) => {
  const { isAuthenticated, isReady } = useAuth();

  useEffect(() => {
    if (!isAuthenticated && isReady) {
      if (options?.mode === "signup") {
        router.push("/auth/signup");
      } else {
        router.push("/auth/signin");
      }
    }
  }, [isAuthenticated, options?.mode, isReady]);
};

export default useAuth;
