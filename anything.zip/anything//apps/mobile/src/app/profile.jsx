import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  Alert,
  Switch,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  Camera,
  Edit3,
  Save,
  X,
  Settings,
  Bell,
  HelpCircle,
  Info,
  LogOut,
  ChevronRight,
  Moon,
  Sun,
  Lock,
  Globe,
  Smartphone,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import * as ImagePicker from "expo-image-picker";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import useUser from "@/utils/auth/useUser";
import useUpload from "@/utils/useUpload";
import { useAuth } from "@/utils/auth/useAuth";
import { useAuthStore } from "@/utils/auth/store";
import useNotificationSettings from "@/hooks/useNotificationSettings";
import { fetchWithAuth } from "@/utils/api";

// Move component definitions OUTSIDE to prevent recreation on every render
const ProfileField = ({
  icon: Icon,
  label,
  value,
  placeholder,
  onChangeText,
  multiline = false,
  editable = true,
  keyboardType,
  inputMode,
  isPhoneField = false,
  isEditing,
  colors,
}) => (
  <View style={{ marginBottom: 16 }}>
    <Text
      style={{
        fontFamily: "Inter_500Medium",
        fontSize: 14,
        color: colors.mainText,
        marginBottom: 8,
      }}
    >
      {label}
    </Text>
    {isEditing && editable ? (
      <TextInput
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          padding: 16,
          fontSize: 16,
          color: colors.mainText,
          borderWidth: 1,
          borderColor: colors.border,
          height: multiline ? 80 : undefined,
        }}
        placeholder={placeholder}
        placeholderTextColor={colors.secondaryText}
        value={value || ""}
        onChangeText={onChangeText}
        multiline={multiline}
        textAlignVertical={multiline ? "top" : "center"}
        keyboardType={keyboardType}
        inputMode={inputMode}
        autoCorrect={false}
        autoCapitalize={isPhoneField ? "none" : "words"}
        maxLength={isPhoneField ? 20 : 200}
        returnKeyType={multiline ? "default" : "done"}
        editable={true}
        selectTextOnFocus={true}
      />
    ) : (
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          padding: 16,
          borderWidth: 1,
          borderColor: colors.border,
          minHeight: multiline ? 80 : undefined,
        }}
      >
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 16,
            color: value ? colors.mainText : colors.secondaryText,
          }}
        >
          {value || placeholder}
        </Text>
      </View>
    )}
  </View>
);

const SettingsSection = ({ title, children, colors }) => (
  <View style={{ marginBottom: 32 }}>
    <Text
      style={{
        fontFamily: "Inter_600SemiBold",
        fontSize: 18,
        color: colors.mainText,
        marginBottom: 16,
      }}
    >
      {title}
    </Text>
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      {children}
    </View>
  </View>
);

const SettingsItem = ({
  icon: Icon,
  title,
  subtitle,
  onPress,
  rightElement,
  showChevron = true,
  isLast = false,
  colors,
}) => (
  <TouchableOpacity
    style={{
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 16,
      paddingVertical: 16,
      borderBottomWidth: isLast ? 0 : 1,
      borderBottomColor: colors.border,
    }}
    onPress={onPress}
    disabled={!onPress}
  >
    <View
      style={{
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: colors.primary + "15",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 12,
      }}
    >
      <Icon size={20} color={colors.primary} />
    </View>
    <View style={{ flex: 1 }}>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 16,
          color: colors.mainText,
          marginBottom: subtitle ? 2 : 0,
        }}
      >
        {title}
      </Text>
      {subtitle && (
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
          }}
        >
          {subtitle}
        </Text>
      )}
    </View>
    {rightElement ||
      (showChevron && <ChevronRight size={20} color={colors.secondaryText} />)}
  </TouchableOpacity>
);

const SwitchItem = ({
  icon: Icon,
  title,
  subtitle,
  value,
  onValueChange,
  disabled,
  isLast = false,
  colors,
}) => (
  <View
    style={{
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 16,
      paddingVertical: 16,
      borderBottomWidth: isLast ? 0 : 1,
      borderBottomColor: colors.border,
    }}
  >
    <View
      style={{
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: colors.primary + "15",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 12,
      }}
    >
      <Icon size={20} color={colors.primary} />
    </View>
    <View style={{ flex: 1 }}>
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 16,
          color: colors.mainText,
          marginBottom: subtitle ? 2 : 0,
        }}
      >
        {title}
      </Text>
      {subtitle && (
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
          }}
        >
          {subtitle}
        </Text>
      )}
    </View>
    <Switch
      value={value}
      onValueChange={onValueChange}
      disabled={disabled}
      trackColor={{
        false: colors.border,
        true: colors.primary + "40",
      }}
      thumbColor={value ? colors.primary : colors.secondaryText}
    />
  </View>
);

export default function Profile() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark, setTheme } = useTheme();
  const { t, getCurrentLanguageName } = useLanguage();
  const { signOut } = useAuth();
  const { data: user, refetch, loading: userLoading } = useUser();
  const { auth, setAuth } = useAuthStore();
  const [upload, { loading: uploadLoading }] = useUpload();

  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const {
    settings: notifSettings,
    isLoading: notifLoading,
    togglePush,
    toggleEmail,
    toggleGame,
    updating: notifUpdating,
  } = useNotificationSettings();

  // Form state - ensure values are never null/undefined
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    image: null,
  });

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  // Update form data when user data changes
  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        image: user.image || null,
      });
    }
  }, [user]);

  // Early return AFTER all hooks are called
  if (!fontsLoaded || userLoading) {
    return null;
  }

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];

        // Upload the image
        const { url, error } = await upload({ reactNativeAsset: asset });

        if (error) {
          setError(t("error"));
          return;
        }

        setFormData((prev) => ({ ...prev, image: url }));
      }
    } catch (error) {
      console.error("Error picking image:", error);
      setError(t("error"));
    }
  };

  const handleSave = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetchWithAuth("/api/user/profile", {
        method: "POST",
        body: JSON.stringify(formData),
      });

      if (!response.success) {
        throw new Error("Failed to update profile");
      }

      // Update the auth store with the new user data
      if (auth && response.user) {
        setAuth({
          ...auth,
          user: response.user,
        });
      }

      await refetch();
      setIsEditing(false);
      Alert.alert(t("success"), t("profileUpdated"));
    } catch (error) {
      console.error("Error updating profile:", error);
      setError(t("error"));
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    // Reset form data to current user data
    setFormData({
      name: user?.name || "",
      email: user?.email || "",
      phone: user?.phone || "",
      image: user?.image || null,
    });
    setIsEditing(false);
    setError(null);
  };

  const handleEditToggle = () => {
    setIsEditing((prev) => !prev);
  };

  const handleLogout = async () => {
    Alert.alert(t("signOut"), t("signOutConfirm"), [
      {
        text: t("cancel"),
        style: "cancel",
      },
      {
        text: t("signOut"),
        style: "destructive",
        onPress: async () => {
          await signOut();
        },
      },
    ]);
  };

  const handleComingSoon = (feature) => {
    Alert.alert(t("comingSoon"), `${feature} ${t("comingSoonMessage")}`, [
      { text: t("ok"), style: "default" },
    ]);
  };

  const handleDarkModeToggle = (newValue) => {
    if (newValue) {
      setTheme("dark");
    } else {
      setTheme("light");
    }
  };

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 20,
            paddingHorizontal: 16,
          }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 32,
            }}
          >
            <TouchableOpacity
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: colors.surface,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={() => router.back()}
            >
              <ArrowLeft size={20} color={colors.mainText} />
            </TouchableOpacity>

            <View style={{ flex: 1, alignItems: "center" }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 20,
                  color: colors.mainText,
                }}
              >
                {t("profile")}
              </Text>
            </View>

            <TouchableOpacity
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: isEditing
                  ? colors.alert + "15"
                  : colors.primary + "15",
                alignItems: "center",
                justifyContent: "center",
              }}
              onPress={isEditing ? handleCancel : () => setIsEditing(true)}
            >
              {isEditing ? (
                <X size={20} color={colors.alert} />
              ) : (
                <Edit3 size={20} color={colors.primary} />
              )}
            </TouchableOpacity>
          </View>

          {/* Profile Picture */}
          <View style={{ alignItems: "center", marginBottom: 32 }}>
            <View style={{ position: "relative" }}>
              <View
                style={{
                  width: 120,
                  height: 120,
                  borderRadius: 60,
                  backgroundColor: colors.surface,
                  borderWidth: 4,
                  borderColor: colors.border,
                  alignItems: "center",
                  justifyContent: "center",
                  overflow: "hidden",
                }}
              >
                {formData.image ? (
                  <Image
                    source={{ uri: formData.image }}
                    style={{
                      width: "100%",
                      height: "100%",
                      borderRadius: 56,
                    }}
                  />
                ) : (
                  <User size={48} color={colors.secondaryText} />
                )}
              </View>

              {isEditing && (
                <TouchableOpacity
                  style={{
                    position: "absolute",
                    bottom: 0,
                    right: 0,
                    width: 36,
                    height: 36,
                    borderRadius: 18,
                    backgroundColor: colors.primary,
                    alignItems: "center",
                    justifyContent: "center",
                    borderWidth: 3,
                    borderColor: colors.background,
                  }}
                  onPress={pickImage}
                  disabled={uploadLoading}
                >
                  <Camera size={16} color={colors.onPrimary} />
                </TouchableOpacity>
              )}
            </View>

            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 24,
                color: colors.mainText,
                marginTop: 16,
                marginBottom: 4,
              }}
            >
              {formData.name || t("fullName")}
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.secondaryText,
              }}
            >
              {formData.email}
            </Text>
          </View>

          {/* Error Message */}
          {error && (
            <View
              style={{
                backgroundColor: colors.alert + "10",
                borderRadius: 12,
                padding: 16,
                marginBottom: 24,
                borderWidth: 1,
                borderColor: colors.alert + "20",
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.alert,
                  textAlign: "center",
                }}
              >
                {error}
              </Text>
            </View>
          )}

          {/* Profile Fields */}
          <ProfileField
            icon={User}
            label={t("fullName")}
            value={formData.name}
            placeholder={t("enterName")}
            onChangeText={(text) =>
              setFormData((prev) => ({ ...prev, name: text }))
            }
            inputMode="text"
            isEditing={isEditing}
            colors={colors}
          />

          <ProfileField
            icon={Mail}
            label={t("emailAddress")}
            value={formData.email}
            placeholder={t("enterEmail")}
            onChangeText={(text) =>
              setFormData((prev) => ({ ...prev, email: text }))
            }
            editable={false}
            inputMode="email"
            isEditing={isEditing}
            colors={colors}
          />

          <ProfileField
            icon={Phone}
            label={t("phoneNumber")}
            value={formData.phone}
            placeholder={t("phoneNumber")}
            onChangeText={(text) =>
              setFormData((prev) => ({ ...prev, phone: text }))
            }
            keyboardType="phone-pad"
            isPhoneField={true}
            isEditing={isEditing}
            colors={colors}
          />

          {/* Save Button */}
          {isEditing && (
            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                borderRadius: 12,
                paddingVertical: 16,
                alignItems: "center",
                marginTop: 16,
                opacity: loading ? 0.7 : 1,
              }}
              onPress={handleSave}
              disabled={loading}
            >
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Save size={20} color={colors.onPrimary} />
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 16,
                    color: colors.onPrimary,
                    marginLeft: 8,
                  }}
                >
                  {loading ? t("loading") : t("saveChanges")}
                </Text>
              </View>
            </TouchableOpacity>
          )}

          {/* Settings Sections - only show when not editing */}
          {!isEditing && (
            <>
              {/* Account Security Section */}
              <SettingsSection title={t("accountSecurity")} colors={colors}>
                <SettingsItem
                  icon={Lock}
                  title={t("accountSecurity")}
                  subtitle={t("passwordTwoFactor")}
                  onPress={() => router.push("/privacy-security")}
                  isLast
                  colors={colors}
                />
              </SettingsSection>

              {/* Billing & Subscriptions Section */}
              <SettingsSection title={t("subscriptions")} colors={colors}>
                <SettingsItem
                  icon={Settings}
                  title={t("manageSubscription")}
                  subtitle={t("manageSubscription")}
                  onPress={() => router.push("/subscriptions")}
                  isLast
                  colors={colors}
                />
              </SettingsSection>

              {/* Notifications Section */}
              <SettingsSection title={t("notifications")} colors={colors}>
                <SwitchItem
                  icon={Smartphone}
                  title={t("pushNotifications")}
                  subtitle={t("receiveNotificationsDevice")}
                  value={!!notifSettings.pushEnabled}
                  onValueChange={togglePush}
                  disabled={notifLoading || notifUpdating}
                  isLast
                  colors={colors}
                />
              </SettingsSection>

              {/* Appearance Section */}
              <SettingsSection title={t("appearance")} colors={colors}>
                <SwitchItem
                  icon={isDark ? Moon : Sun}
                  title={t("darkMode")}
                  subtitle={
                    isDark ? t("currentlyDarkTheme") : t("currentlyLightTheme")
                  }
                  value={isDark}
                  onValueChange={handleDarkModeToggle}
                  isLast
                  colors={colors}
                />
              </SettingsSection>

              {/* General Section */}
              <SettingsSection title={t("general")} colors={colors}>
                <SettingsItem
                  icon={Globe}
                  title={t("language")}
                  subtitle={getCurrentLanguageName()}
                  onPress={() => router.push("/language-selection")}
                  colors={colors}
                />
                <SettingsItem
                  icon={HelpCircle}
                  title={t("helpSupport")}
                  subtitle={t("faqsContactSupport")}
                  onPress={() => router.push("/help-support")}
                  colors={colors}
                />
                <SettingsItem
                  icon={Info}
                  title={t("about")}
                  subtitle={t("version")}
                  onPress={() => router.push("/about")}
                  isLast
                  colors={colors}
                />
              </SettingsSection>

              {/* Sign Out Section */}
              <View style={{ marginTop: 8, marginBottom: 40 }}>
                <TouchableOpacity
                  style={{
                    backgroundColor: colors.alert + "10",
                    borderRadius: 16,
                    paddingVertical: 16,
                    paddingHorizontal: 16,
                    borderWidth: 1,
                    borderColor: colors.alert + "20",
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  onPress={handleLogout}
                >
                  <LogOut size={20} color={colors.alert} />
                  <Text
                    style={{
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 16,
                      color: colors.alert,
                      marginLeft: 8,
                    }}
                  >
                    {t("signOut")}
                  </Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
