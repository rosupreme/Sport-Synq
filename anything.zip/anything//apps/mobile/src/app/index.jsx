import { Redirect } from "expo-router";
import { useEffect } from "react";
import { useAuth } from "@/utils/auth/useAuth";
import { View, ActivityIndicator, Text } from "react-native";
import { useColorScheme } from "react-native";

export default function Index() {
  const { isAuthenticated, isReady, initiate } = useAuth();
  const scheme = useColorScheme();

  useEffect(() => {
    initiate();
  }, [initiate]);

  // Show loading state while auth initializes
  if (!isReady) {
    const bg = scheme === "dark" ? "#121212" : "#FFFFFF";
    const spinner = scheme === "dark" ? "#FFFFFF" : "#111827";
    const text = scheme === "dark" ? "#B8B8B8" : "#6B7280";
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: bg,
        }}
      >
        <ActivityIndicator size="large" color={spinner} />
        <Text style={{ marginTop: 12, color: text }}>Loading…</Text>
      </View>
    );
  }

  // If not authenticated, go to sign in
  if (!isAuthenticated) {
    return <Redirect href="/auth/signin" />;
  }

  // If authenticated, go to the app (removed subscription check)
  return <Redirect href="/(tabs)/dashboard" />;
}
