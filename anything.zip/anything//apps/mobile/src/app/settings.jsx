import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Switch,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  ArrowLeft,
  Bell,
  Shield,
  Palette,
  HelpCircle,
  Info,
  LogOut,
  ChevronRight,
  Moon,
  Sun,
  Mail,
  Lock,
  Globe,
  Smartphone,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useAuth } from "@/utils/auth/useAuth";
import useUser from "@/utils/auth/useUser";

export default function Settings() {
  const insets = useSafeAreaInsets();
  const { colors, isDark, toggleTheme } = useTheme();
  const { t, getCurrentLanguageName } = useLanguage();
  const { signOut } = useAuth();
  const { data: user } = useUser();
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(false);
  const [gameReminders, setGameReminders] = useState(true);
  const router = useRouter();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleLogout = async () => {
    Alert.alert(t("signOut"), t("signOutConfirm"), [
      {
        text: t("cancel"),
        style: "cancel",
      },
      {
        text: t("signOut"),
        style: "destructive",
        onPress: async () => {
          await signOut();
        },
      },
    ]);
  };

  const handleComingSoon = (feature) => {
    Alert.alert(t("comingSoon"), `${feature} ${t("comingSoonMessage")}`, [
      { text: t("ok"), style: "default" },
    ]);
  };

  const SettingsSection = ({ title, children }) => (
    <View style={{ marginBottom: 32 }}>
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 18,
          color: colors.mainText,
          marginBottom: 16,
          paddingHorizontal: 16,
        }}
      >
        {title}
      </Text>
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          marginHorizontal: 16,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        {children}
      </View>
    </View>
  );

  const SettingsItem = ({
    icon: Icon,
    title,
    subtitle,
    onPress,
    rightElement,
    showChevron = true,
    isLast = false,
  }) => (
    <TouchableOpacity
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderBottomWidth: isLast ? 0 : 1,
        borderBottomColor: colors.border,
      }}
      onPress={onPress}
      disabled={!onPress}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: colors.primary + "15",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 12,
        }}
      >
        <Icon size={20} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 16,
            color: colors.mainText,
            marginBottom: subtitle ? 2 : 0,
          }}
        >
          {title}
        </Text>
        {subtitle && (
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
            }}
          >
            {subtitle}
          </Text>
        )}
      </View>
      {rightElement ||
        (showChevron && (
          <ChevronRight size={20} color={colors.secondaryText} />
        ))}
    </TouchableOpacity>
  );

  const SwitchItem = ({
    icon: Icon,
    title,
    subtitle,
    value,
    onValueChange,
    isLast = false,
  }) => (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderBottomWidth: isLast ? 0 : 1,
        borderBottomColor: colors.border,
      }}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: colors.primary + "15",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 12,
        }}
      >
        <Icon size={20} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 16,
            color: colors.mainText,
            marginBottom: subtitle ? 2 : 0,
          }}
        >
          {title}
        </Text>
        {subtitle && (
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
            }}
          >
            {subtitle}
          </Text>
        )}
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{
          false: colors.border,
          true: colors.primary + "40",
        }}
        thumbColor={value ? colors.primary : colors.secondaryText}
      />
    </View>
  );

  return (
    <ScreenWrapper>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 40,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            marginBottom: 32,
          }}
        >
          <TouchableOpacity
            style={{
              width: 44,
              height: 44,
              backgroundColor: colors.surface,
              borderRadius: 22,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
              marginRight: 16,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color={colors.mainText} />
          </TouchableOpacity>

          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: colors.mainText,
            }}
          >
            {t("settings")}
          </Text>
        </View>

        {/* Privacy & Security Section */}
        <SettingsSection title={t("privacySecurity")}>
          <SettingsItem
            icon={Lock}
            title={t("privacySecurity")}
            subtitle={t("passwordTwoFactor")}
            onPress={() => router.push("/privacy-security")}
            isLast
          />
        </SettingsSection>

        {/* Notifications Section */}
        <SettingsSection title={t("notifications")}>
          <SwitchItem
            icon={Smartphone}
            title={t("pushNotifications")}
            subtitle={t("receiveNotificationsDevice")}
            value={pushNotifications}
            onValueChange={setPushNotifications}
          />
          <SwitchItem
            icon={Mail}
            title={t("emailNotifications")}
            subtitle={t("receiveUpdatesEmail")}
            value={emailNotifications}
            onValueChange={setEmailNotifications}
          />
          <SwitchItem
            icon={Bell}
            title={t("gameReminders")}
            subtitle={t("notifiedBeforeGames")}
            value={gameReminders}
            onValueChange={setGameReminders}
            isLast
          />
        </SettingsSection>

        {/* Appearance Section */}
        <SettingsSection title={t("appearance")}>
          <SwitchItem
            icon={isDark ? Moon : Sun}
            title={t("darkMode")}
            subtitle={
              isDark ? t("currentlyDarkTheme") : t("currentlyLightTheme")
            }
            value={isDark}
            onValueChange={toggleTheme}
            isLast
          />
        </SettingsSection>

        {/* General Section */}
        <SettingsSection title={t("general")}>
          <SettingsItem
            icon={Globe}
            title={t("language")}
            subtitle={getCurrentLanguageName()}
            onPress={() => router.push("/language-selection")}
          />
          <SettingsItem
            icon={HelpCircle}
            title={t("helpSupport")}
            subtitle={t("faqsContactSupport")}
            onPress={() => handleComingSoon("Help & Support")}
          />
          <SettingsItem
            icon={Info}
            title={t("about")}
            subtitle={t("version")}
            onPress={() => handleComingSoon("About page")}
            isLast
          />
        </SettingsSection>

        {/* Sign Out Section */}
        <View style={{ marginHorizontal: 16, marginTop: 8 }}>
          <TouchableOpacity
            style={{
              backgroundColor: colors.alert + "10",
              borderRadius: 16,
              paddingVertical: 16,
              paddingHorizontal: 16,
              borderWidth: 1,
              borderColor: colors.alert + "20",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={handleLogout}
          >
            <LogOut size={20} color={colors.alert} />
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.alert,
                marginLeft: 8,
              }}
            >
              {t("signOut")}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
