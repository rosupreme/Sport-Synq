import React from "react";
import { ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { Calendar, Clock, MapPin, FileText } from "lucide-react-native";
import { useLanguage } from "@/components/LanguageProvider";

import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import AddEventHeader from "@/components/add-event/AddEventHeader";
import InputField from "@/components/add-event/InputField";
import PickerField from "@/components/add-event/PickerField";
import EventTypeSelector from "@/components/add-event/EventTypeSelector";
import RecurringEventSelector from "@/components/add-event/RecurringEventSelector";
import EventPreview from "@/components/add-event/EventPreview";
import DatePickerModal from "@/components/add-event/DatePickerModal";
import TimePickerModal from "@/components/add-event/TimePickerModal";
import { useAddEvent } from "@/hooks/useAddEvent";

export default function AddEvent() {
  const insets = useSafeAreaInsets();
  const { t } = useLanguage();
  const {
    isLoading,
    selectedTeam,
    loadingTeam,
    eventData,
    updateEventData,
    showDatePicker,
    setShowDatePicker,
    showTimePicker,
    setShowTimePicker,
    selectedDate,
    selectedTime,
    setSelectedTime,
    handleDateSelect,
    handleTimeSelect,
    handleSaveEvent,
    // Recurring event props
    isRecurring,
    setIsRecurring,
    recurrenceType,
    setRecurrenceType,
    occurrences,
    setOccurrences,
    isEditMode,
  } = useAddEvent();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <AddEventHeader
          onSave={handleSaveEvent}
          isLoading={isLoading}
          isEditMode={isEditMode}
        />

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingHorizontal: 16,
            paddingTop: 20,
            paddingBottom: insets.bottom + 20,
          }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <InputField
            label={t("eventTitle") || "Event Title"}
            placeholder={t("enterEventTitle") || "Enter event title"}
            value={eventData.title}
            onChangeText={(value) => updateEventData("title", value)}
            icon={FileText}
          />

          <EventTypeSelector
            selectedType={eventData.type}
            onTypeChange={(type) => updateEventData("type", type)}
          />

          {/* Only show recurring event selector when creating a new event */}
          {!isEditMode && (
            <RecurringEventSelector
              isRecurring={isRecurring}
              onRecurringToggle={setIsRecurring}
              recurrenceType={recurrenceType}
              onRecurrenceTypeChange={setRecurrenceType}
              occurrences={occurrences}
              onOccurrencesChange={setOccurrences}
            />
          )}

          <PickerField
            label={t("eventDate")}
            placeholder={t("selectEventDate") || "Select event date"}
            value={eventData.date}
            onPress={() => setShowDatePicker(true)}
            icon={Calendar}
          />

          <PickerField
            label={t("eventTime")}
            placeholder={t("selectEventTime") || "Select event time"}
            value={eventData.time}
            onPress={() => setShowTimePicker(true)}
            icon={Clock}
          />

          <InputField
            label={t("location")}
            placeholder={t("enterLocation") || "Enter event location"}
            value={eventData.location}
            onChangeText={(value) => updateEventData("location", value)}
            icon={MapPin}
          />

          <InputField
            label={`${t("description")} (${t("optional") || "Optional"})`}
            placeholder={
              t("addEventDetails") ||
              "Add event details, notes, or instructions..."
            }
            value={eventData.description}
            onChangeText={(value) => updateEventData("description", value)}
            icon={FileText}
            multiline={true}
          />

          <EventPreview eventData={eventData} />
        </ScrollView>

        <DatePickerModal
          visible={showDatePicker}
          onClose={() => setShowDatePicker(false)}
          onDayPress={handleDateSelect}
          selectedDate={selectedDate}
        />

        <TimePickerModal
          visible={showTimePicker}
          onClose={() => setShowTimePicker(false)}
          onDone={handleTimeSelect}
          selectedTime={selectedTime}
          onTimeChange={setSelectedTime}
        />
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
