import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import {
  ArrowLeft,
  Star,
  Target,
  TrendingUp,
  FileText,
  Calendar,
  User,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";

export default function EvaluationDetails() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { evaluationId } = useLocalSearchParams();
  const { colors, isDark } = useTheme();
  const [evaluation, setEvaluation] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  useEffect(() => {
    if (evaluationId) {
      fetchEvaluationDetails();
    }
  }, [evaluationId]);

  const fetchEvaluationDetails = async () => {
    try {
      setIsLoading(true);
      console.log("Fetching evaluation details for ID:", evaluationId);

      const response = await fetch(
        `/api/evaluations?evaluationId=${evaluationId}`,
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error("Response error:", errorText);
        throw new Error(`Failed to fetch evaluation: ${response.status}`);
      }

      const data = await response.json();
      console.log("Evaluation API response:", data);

      if (data.success && data.evaluations && data.evaluations.length > 0) {
        const evaluationData = data.evaluations[0];

        // Format the evaluation data to match component expectations
        const formattedEvaluation = {
          id: evaluationData.id.toString(),
          playerId: evaluationData.player_id.toString(),
          playerName: evaluationData.player_name,
          playerPosition: evaluationData.position || "Player",
          coachName: evaluationData.coach_name,
          evaluationType: evaluationData.evaluation_type,
          season: evaluationData.season,
          status: evaluationData.status,
          createdAt: evaluationData.created_at,
          ballControl: evaluationData.ball_control,
          passing: evaluationData.passing,
          shooting: evaluationData.shooting,
          defending: evaluationData.defending,
          fitnessLevel: evaluationData.fitness_level,
          teamwork: evaluationData.teamwork,
          attitude: evaluationData.attitude,
          leadership: evaluationData.leadership,
          strengths: evaluationData.strengths,
          areasForImprovement: evaluationData.areas_for_improvement,
          goalsNextPeriod: evaluationData.goals_next_period,
          coachNotes: evaluationData.coach_notes,
        };

        console.log("Formatted evaluation:", formattedEvaluation);
        setEvaluation(formattedEvaluation);
      } else {
        throw new Error("No evaluation data found");
      }
    } catch (error) {
      console.error("Error fetching evaluation details:", error);
      Alert.alert(
        "Error",
        `Failed to load evaluation details: ${error.message}`,
        [
          { text: "Go Back", onPress: () => router.back() },
          { text: "Retry", onPress: fetchEvaluationDetails },
        ],
      );
    } finally {
      setIsLoading(false);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  // Show loading state
  if (isLoading) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top + 20,
          }}
        >
          <ActivityIndicator size="large" color={colors.primary} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.secondaryText,
              marginTop: 16,
            }}
          >
            Loading evaluation details...
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  // Show error if evaluation not found
  if (!evaluation) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top + 20,
            paddingHorizontal: 16,
          }}
        >
          <FileText
            size={64}
            color={colors.secondaryText}
            style={{ marginBottom: 16 }}
          />
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
              marginBottom: 8,
              textAlign: "center",
            }}
          >
            Evaluation Not Found
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
              marginBottom: 24,
            }}
          >
            The evaluation you're looking for doesn't exist or has been removed.
          </Text>
          <TouchableOpacity
            style={{
              backgroundColor: colors.primary,
              borderRadius: 12,
              paddingHorizontal: 24,
              paddingVertical: 12,
            }}
            onPress={() => router.back()}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: "white",
              }}
            >
              Go Back
            </Text>
          </TouchableOpacity>
        </View>
      </ScreenWrapper>
    );
  }

  const getScoreColor = (score) => {
    if (score >= 7) return colors.success;
    if (score >= 5) return colors.warning;
    return colors.error;
  };

  const getScoreLabel = (score) => {
    if (score >= 9) return "Excellent";
    if (score >= 7) return "Good";
    if (score >= 5) return "Average";
    if (score >= 3) return "Needs Work";
    return "Poor";
  };

  const getEvaluationTypeLabel = (type) => {
    switch (type) {
      case "mid_season":
        return "Mid-Season";
      case "end_season":
        return "End of Season";
      case "monthly":
        return "Monthly";
      default:
        return type;
    }
  };

  const skillCategories = [
    {
      title: "Technical Skills",
      skills: [
        {
          key: "ballControl",
          label: "Fundamentals",
          icon: "🎯",
          value: evaluation.ballControl,
        },
        {
          key: "passing",
          label: "Game Intelligence",
          icon: "🧠",
          value: evaluation.passing,
        },
        {
          key: "shooting",
          label: "Execution",
          icon: "⚡",
          value: evaluation.shooting,
        },
        {
          key: "defending",
          label: "Adaptability",
          icon: "📈",
          value: evaluation.defending,
        },
      ],
    },
    {
      title: "Physical & Mental",
      skills: [
        {
          key: "fitnessLevel",
          label: "Fitness Level",
          icon: "💪",
          value: evaluation.fitnessLevel,
        },
        {
          key: "teamwork",
          label: "Teamwork",
          icon: "🤝",
          value: evaluation.teamwork,
        },
        {
          key: "attitude",
          label: "Attitude",
          icon: "😊",
          value: evaluation.attitude,
        },
        {
          key: "leadership",
          label: "Leadership",
          icon: "👑",
          value: evaluation.leadership,
        },
      ],
    },
  ];

  const SkillDisplay = ({ skill }) => (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 12,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Text style={{ fontSize: 20, marginRight: 8 }}>{skill.icon}</Text>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 15,
              color: colors.mainText,
            }}
          >
            {skill.label}
          </Text>
        </View>
        <View style={{ alignItems: "flex-end" }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: getScoreColor(skill.value),
            }}
          >
            {skill.value}/10
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 12,
              color: getScoreColor(skill.value),
            }}
          >
            {getScoreLabel(skill.value)}
          </Text>
        </View>
      </View>

      {/* Progress Bar */}
      <View
        style={{
          height: 8,
          backgroundColor: colors.border,
          borderRadius: 4,
          overflow: "hidden",
        }}
      >
        <View
          style={{
            height: "100%",
            width: `${(skill.value / 10) * 100}%`,
            backgroundColor: getScoreColor(skill.value),
            borderRadius: 4,
          }}
        />
      </View>
    </View>
  );

  const FeedbackSection = ({ title, content, icon: Icon }) => (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 16,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <View
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}
      >
        {Icon && (
          <Icon size={16} color={colors.primary} style={{ marginRight: 8 }} />
        )}
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 16,
            color: colors.mainText,
          }}
        >
          {title}
        </Text>
      </View>
      <Text
        style={{
          fontFamily: "Inter_400Regular",
          fontSize: 14,
          color: colors.mainText,
          lineHeight: 20,
        }}
      >
        {content || "No feedback provided"}
      </Text>
    </View>
  );

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const technicalAverage =
    (evaluation.ballControl +
      evaluation.passing +
      evaluation.shooting +
      evaluation.defending) /
    4;
  const mentalPhysicalAverage =
    (evaluation.fitnessLevel +
      evaluation.teamwork +
      evaluation.attitude +
      evaluation.leadership) /
    4;
  const overallAverage = (technicalAverage + mentalPhysicalAverage) / 2;

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1, alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
              }}
            >
              Evaluation Report
            </Text>
          </View>

          {/* Replace the Share/Edit buttons with a spacer to keep layout aligned */}
          <View style={{ width: 40 }} />
        </View>

        {/* Player & Evaluation Info */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 16,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                width: 48,
                height: 48,
                backgroundColor: colors.primary + "20",
                borderRadius: 24,
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <User size={24} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 18,
                  color: colors.mainText,
                  marginBottom: 2,
                }}
              >
                {evaluation.playerName}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.secondaryText,
                }}
              >
                {evaluation.playerPosition}
              </Text>
            </View>
            <View
              style={{
                backgroundColor:
                  evaluation.status === "submitted"
                    ? colors.success + "20"
                    : colors.warning + "20",
                borderRadius: 16,
                paddingHorizontal: 12,
                paddingVertical: 6,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 12,
                  color:
                    evaluation.status === "submitted"
                      ? colors.success
                      : colors.warning,
                  textTransform: "uppercase",
                  letterSpacing: 0.5,
                }}
              >
                {evaluation.status}
              </Text>
            </View>
          </View>

          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                  marginBottom: 2,
                }}
              >
                Evaluation Type
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.mainText,
                }}
              >
                {getEvaluationTypeLabel(evaluation.evaluationType)}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                  marginBottom: 2,
                }}
              >
                Season
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.mainText,
                }}
              >
                {evaluation.season}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                  marginBottom: 2,
                }}
              >
                Date
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.mainText,
                }}
              >
                {formatDate(evaluation.createdAt)}
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* Content */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Overall Summary */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            Overall Performance
          </Text>

          <View
            style={{
              backgroundColor: colors.background,
              borderRadius: 12,
              padding: 16,
              marginBottom: 16,
            }}
          >
            <View style={{ alignItems: "center", marginBottom: 12 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 32,
                  color: getScoreColor(overallAverage),
                }}
              >
                {overallAverage.toFixed(1)}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.secondaryText,
                  textTransform: "uppercase",
                  letterSpacing: 0.5,
                }}
              >
                Overall Score
              </Text>
            </View>

            <View
              style={{
                height: 8,
                backgroundColor: colors.border,
                borderRadius: 4,
                overflow: "hidden",
                marginBottom: 16,
              }}
            >
              <View
                style={{
                  height: "100%",
                  width: `${(overallAverage / 10) * 100}%`,
                  backgroundColor: getScoreColor(overallAverage),
                  borderRadius: 4,
                }}
              />
            </View>
          </View>

          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ alignItems: "center", flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 20,
                  color: getScoreColor(technicalAverage),
                }}
              >
                {technicalAverage.toFixed(1)}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                  textAlign: "center",
                }}
              >
                Technical Skills
              </Text>
            </View>
            <View style={{ alignItems: "center", flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 20,
                  color: getScoreColor(mentalPhysicalAverage),
                }}
              >
                {mentalPhysicalAverage.toFixed(1)}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                  textAlign: "center",
                }}
              >
                Mental & Physical
              </Text>
            </View>
          </View>
        </View>

        {/* Skills Breakdown */}
        {skillCategories.map((category) => (
          <View
            key={category.title}
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 16,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 16,
              }}
            >
              {category.title}
            </Text>

            {category.skills.map((skill) => (
              <SkillDisplay key={skill.key} skill={skill} />
            ))}
          </View>
        ))}

        {/* Written Feedback */}
        <FeedbackSection
          title="Strengths"
          content={evaluation.strengths}
          icon={Star}
        />

        <FeedbackSection
          title="Areas for Improvement"
          content={evaluation.areasForImprovement}
          icon={Target}
        />

        <FeedbackSection
          title="Goals for Next Period"
          content={evaluation.goalsNextPeriod}
          icon={TrendingUp}
        />

        <FeedbackSection
          title="Coach Notes"
          content={evaluation.coachNotes}
          icon={FileText}
        />

        {/* Coach Information */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 16,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 12,
            }}
          >
            Evaluated By
          </Text>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <View
              style={{
                width: 40,
                height: 40,
                backgroundColor: colors.primary + "20",
                borderRadius: 20,
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <Text style={{ fontSize: 16 }}>👨‍🏫</Text>
            </View>
            <View>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                }}
              >
                {evaluation.coachName}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.secondaryText,
                }}
              >
                Head Coach
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
