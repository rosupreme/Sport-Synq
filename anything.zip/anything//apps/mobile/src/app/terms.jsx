import React from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useTheme } from "@/components/ThemeProvider";

export default function Terms() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const H2 = ({ children }) => (
    <Text
      style={{
        fontFamily: "Inter_600SemiBold",
        fontSize: 16,
        color: colors.mainText,
        marginTop: 16,
        marginBottom: 8,
      }}
    >
      {children}
    </Text>
  );

  const P = ({ children }) => (
    <Text
      style={{
        fontFamily: "Inter_400Regular",
        fontSize: 14,
        lineHeight: 22,
        color: colors.bodyText,
        marginBottom: 10,
      }}
    >
      {children}
    </Text>
  );

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <TouchableOpacity
          style={{
            width: 40,
            height: 40,
            backgroundColor: colors.lavender,
            borderRadius: 20,
            alignItems: "center",
            justifyContent: "center",
            marginRight: 16,
          }}
          onPress={() => router.back()}
          accessibilityLabel="Go back"
        >
          <ArrowLeft size={20} color={colors.primary} />
        </TouchableOpacity>

        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: colors.mainText,
              marginBottom: 4,
            }}
          >
            Terms of Service
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
            }}
          >
            Last updated: January 16, 2026
          </Text>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: 16,
          paddingHorizontal: 16,
          paddingBottom: insets.bottom + 40,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            borderWidth: 1,
            borderColor: colors.border,
            padding: 16,
          }}
        >
          <P>
            These Terms of Service ("Terms") govern your use of the Sport-Synq
            mobile app (the "App"). By using the App, you agree to these Terms.
          </P>

          <H2>1) Accounts</H2>
          <P>
            You’re responsible for keeping your login details safe and for all
            activity under your account.
          </P>

          <H2>2) Team Content</H2>
          <P>
            The App lets you create and manage team data like schedules, player
            profiles, evaluations, attendance, fundraising info, and notes.
            Please only upload or share content you have the right to use.
          </P>

          <H2>3) Acceptable Use</H2>
          <P>
            Don’t misuse the App. That includes attempting to break security,
            scraping data, abusing other users, or uploading illegal or harmful
            content.
          </P>

          <H2>4) Payments & Subscriptions (if enabled)</H2>
          <P>
            Some features may be behind a subscription. If you buy a
            subscription, billing is handled through the app store and/or our
            payment providers.
          </P>

          <H2>5) Termination</H2>
          <P>
            You can stop using the App at any time. We may suspend or terminate
            access if we believe the App is being misused or used in a way that
            could harm other users.
          </P>

          <H2>6) Disclaimers</H2>
          <P>
            The App is provided “as is” and “as available”. We can’t guarantee
            it will always work without interruptions or errors.
          </P>

          <H2>7) Limitation of Liability</H2>
          <P>
            To the fullest extent permitted by law, we’re not liable for
            indirect damages, lost profits, or loss of data.
          </P>

          <H2>8) Changes</H2>
          <P>
            We may update these Terms from time to time. If we make major
            changes, we’ll try to make it clear in the App.
          </P>

          <H2>Contact</H2>
          <P>
            For questions, please use the Help & Support screen inside the App.
          </P>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
