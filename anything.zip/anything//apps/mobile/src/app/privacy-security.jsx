import React, { useState } from "react";
import { View, Text, TouchableOpacity, ScrollView, Alert } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft, Key, Trash2, ChevronRight } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import useUser from "@/utils/auth/useUser";

export default function PrivacySecurity() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const { data: user } = useUser();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleComingSoon = (feature) => {
    Alert.alert(t("comingSoon"), `${feature} ${t("comingSoonMessage")}`, [
      { text: t("ok"), style: "default" },
    ]);
  };

  const handleChangePassword = () => {
    router.push("/change-password");
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      t("deleteAccount"),
      "This will permanently delete your account and all associated data. This action cannot be undone.",
      [
        { text: t("cancel"), style: "cancel" },
        {
          text: t("deleteAccount"),
          style: "destructive",
          onPress: () => {
            Alert.alert(
              "Final Warning",
              "Are you absolutely sure? This will permanently delete your account, team data, and all evaluations.",
              [
                { text: t("cancel"), style: "cancel" },
                {
                  text: "Yes, Delete Forever",
                  style: "destructive",
                  onPress: () => handleComingSoon("Account deletion"),
                },
              ],
            );
          },
        },
      ],
    );
  };

  const SettingsSection = ({ title, children }) => (
    <View style={{ marginBottom: 32 }}>
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 18,
          color: colors.mainText,
          marginBottom: 16,
          paddingHorizontal: 16,
        }}
      >
        {title}
      </Text>
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          marginHorizontal: 16,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        {children}
      </View>
    </View>
  );

  const SettingsItem = ({
    icon: Icon,
    title,
    subtitle,
    onPress,
    rightElement,
    showChevron = true,
    isLast = false,
    isDangerous = false,
  }) => (
    <TouchableOpacity
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderBottomWidth: isLast ? 0 : 1,
        borderBottomColor: colors.border,
      }}
      onPress={onPress}
      disabled={!onPress}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: isDangerous
            ? colors.error + "15"
            : colors.primary + "15",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 12,
        }}
      >
        <Icon size={20} color={isDangerous ? colors.error : colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 16,
            color: isDangerous ? colors.error : colors.mainText,
            marginBottom: subtitle ? 2 : 0,
          }}
        >
          {title}
        </Text>
        {subtitle && (
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
            }}
          >
            {subtitle}
          </Text>
        )}
      </View>
      {rightElement ||
        (showChevron && (
          <ChevronRight size={20} color={colors.secondaryText} />
        ))}
    </TouchableOpacity>
  );

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 16,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 24,
                color: colors.mainText,
                marginBottom: 4,
              }}
            >
              {t("privacySecurityTitle")}
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {t("keepAccountSafe")}
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: 20,
          paddingBottom: insets.bottom + 40,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Single section with only Change Password and Delete Account */}
        <SettingsSection title={t("accountSecurity")}>
          <SettingsItem
            icon={Key}
            title={t("changePassword")}
            subtitle={t("updateLoginPassword")}
            onPress={handleChangePassword}
          />
          <SettingsItem
            icon={Trash2}
            title={t("deleteAccount")}
            subtitle={t("permanentlyDeleteAccount")}
            onPress={handleDeleteAccount}
            isDangerous={true}
            isLast
          />
        </SettingsSection>
        {/* Removed: Two-Factor Authentication, Active Sessions, Privacy Controls, Data Management, and Security Tips */}
      </ScrollView>
    </ScreenWrapper>
  );
}
