import React from "react";
import { View, Text, ScrollView, Alert } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import { HelpSupportHeader } from "@/components/help-support/HelpSupportHeader";
import { WelcomeMessage } from "@/components/help-support/WelcomeMessage";
import { ContactSection } from "@/components/help-support/ContactSection";
import { FeedbackNavigationCard } from "@/components/help-support/FeedbackNavigationCard";

export default function HelpSupport() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <ScreenWrapper>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
      >
        <HelpSupportHeader onBack={() => router.back()} />

        <WelcomeMessage />

        <ContactSection />

        <FeedbackNavigationCard onPress={() => router.push("/feedback")} />

        <View
          style={{
            alignItems: "center",
            paddingVertical: 20,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 13,
              color: colors.secondaryText,
            }}
          >
            Sport SynQ {t("version")}
          </Text>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
