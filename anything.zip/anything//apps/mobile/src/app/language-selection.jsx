import React from "react";
import { View, Text, TouchableOpacity, ScrollView, Alert } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft, Check, Globe } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";

export default function LanguageSelection() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { currentLanguage, changeLanguage, t, getLanguageOptions } =
    useLanguage();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleLanguageChange = async (languageCode) => {
    if (languageCode !== currentLanguage) {
      await changeLanguage(languageCode);
      Alert.alert(t("languageChanged"), t("languageChangedMessage"), [
        { text: t("ok"), style: "default" },
      ]);
    }
  };

  const LanguageOption = ({ language, isSelected, onPress }) => (
    <TouchableOpacity
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
        backgroundColor: isSelected ? colors.primary + "08" : "transparent",
      }}
      onPress={onPress}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: colors.primary + "15",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 12,
        }}
      >
        <Globe size={20} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 16,
            color: colors.mainText,
            marginBottom: 2,
          }}
        >
          {language.nativeName}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
          }}
        >
          {language.name}
        </Text>
      </View>
      {isSelected && (
        <View
          style={{
            width: 24,
            height: 24,
            borderRadius: 12,
            backgroundColor: colors.primary,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Check size={16} color="white" />
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 16,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 24,
                color: colors.mainText,
                marginBottom: 4,
              }}
            >
              {t("selectLanguage")}
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {t("choosePreferredLanguage")}
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: 20,
          paddingBottom: insets.bottom + 40,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Current Language Info */}
        <View style={{ marginBottom: 24, paddingHorizontal: 16 }}>
          <View
            style={{
              backgroundColor: colors.primary + "10",
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.primary + "20",
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Globe
              size={20}
              color={colors.primary}
              style={{ marginRight: 12 }}
            />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 14,
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                {t("currentLanguage")}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                }}
              >
                {getLanguageOptions().find(
                  (lang) => lang.code === currentLanguage,
                )?.nativeName || "English"}
              </Text>
            </View>
          </View>
        </View>

        {/* Language Options */}
        <View style={{ marginHorizontal: 16 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            {t("language")}
          </Text>
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: colors.border,
              overflow: "hidden",
            }}
          >
            {getLanguageOptions().map((language, index) => (
              <LanguageOption
                key={language.code}
                language={language}
                isSelected={language.code === currentLanguage}
                onPress={() => handleLanguageChange(language.code)}
                isLast={index === getLanguageOptions().length - 1}
              />
            ))}
          </View>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
