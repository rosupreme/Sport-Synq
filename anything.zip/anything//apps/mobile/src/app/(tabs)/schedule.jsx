import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Animated,
  RefreshControl,
  DeviceEventEmitter,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Calendar } from "react-native-calendars";
import { useRouter } from "expo-router";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback } from "react";
import {
  Plus,
  Clock,
  MapPin,
  Users,
  Calendar as CalendarIcon,
  List,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import EmptyState from "@/components/EmptyState";
import Pill from "@/components/Pill";
import { useDashboardData } from "@/hooks/useDashboardData";
import useUser from "@/utils/auth/useUser";
import { fetchWithAuth } from "@/utils/api";

export default function Schedule() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark, typography } = useTheme();
  const { t } = useLanguage();

  // Helper: parse a YYYY-MM-DD string into a local Date (avoids UTC shift)
  const toLocalDate = (ymd) => {
    if (!ymd || typeof ymd !== "string") return new Date();
    const [y, m, d] = ymd.split("-").map((v) => parseInt(v, 10));
    return new Date(y, (m || 1) - 1, d || 1);
  };

  // Get today's date string for comparison
  const getTodayString = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  // Get selected team from dashboard data (no dropdown here)
  const { selectedTeam } = useDashboardData();
  const { data: user } = useUser();
  const isCoach = React.useMemo(() => {
    const roleValue =
      selectedTeam?.user_role ||
      selectedTeam?.role ||
      selectedTeam?.current_user_role ||
      (selectedTeam?.is_owner ? "owner" : null);

    const roleStr =
      typeof roleValue === "string" ? roleValue.toLowerCase() : "";

    if (roleStr === "coach" || roleStr === "owner") return true;
    if (selectedTeam?.is_owner === true) return true;

    const ownerId = selectedTeam?.owner_id ?? selectedTeam?.ownerId;
    if (user?.id && ownerId && String(ownerId) === String(user.id)) return true;
    return false;
  }, [
    selectedTeam?.user_role,
    selectedTeam?.role,
    selectedTeam?.current_user_role,
    selectedTeam?.is_owner,
    selectedTeam?.owner_id,
    selectedTeam?.ownerId,
    user?.id,
  ]);

  // Set to current date
  const [selectedDate, setSelectedDate] = useState(() => {
    // Ensure we get the correct current date
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`; // Format: YYYY-MM-DD
  });

  const [viewMode, setViewMode] = useState("calendar"); // 'calendar' or 'list'
  const [scrollY] = useState(new Animated.Value(0));

  // Data states
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  const loadData = async () => {
    if (!selectedTeam) return;

    try {
      setLoading(true);
      setError(null);
      await fetchEvents();
    } catch (error) {
      console.error("Error loading data:", error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchEvents = async () => {
    try {
      console.log(
        "Fetching events from /api/events for team:",
        selectedTeam?.id,
      );

      // Build URL with teamId
      let url = "/api/events";
      if (selectedTeam?.id) {
        url += `?teamId=${selectedTeam.id}`;
      }

      // fetchWithAuth returns parsed JSON data directly
      const data = await fetchWithAuth(url);
      console.log("Events API response:", data);

      // Transform backend data to match expected format
      const transformedEvents = (data.events || []).map((event) => ({
        id: event.id,
        title: event.title,
        description: event.description,
        type: event.event_type,
        date: (event.event_date || "").split("T")[0], // Keep YYYY-MM-DD string
        time: formatTimeFromDb(event.event_time), // Convert from HH:MM:SS to readable format
        location: event.location,
        teamName: event.team_name,
        organizer: event.organizer_name,
        attendees: event.going_count || 0,
        total: event.total_invited || 0,
      }));

      console.log("Transformed events:", transformedEvents);
      setEvents(transformedEvents);
    } catch (error) {
      console.error("Error fetching events:", error);
      throw error;
    }
  };

  const formatTimeFromDb = (timeString) => {
    if (!timeString) return "";
    try {
      const [hours, minutes] = timeString.split(":");
      const hour24 = parseInt(hours);
      const period = hour24 >= 12 ? "PM" : "AM";
      const hour12 = hour24 === 0 ? 12 : hour24 > 12 ? hour24 - 12 : hour24;
      return `${hour12}:${minutes} ${period}`;
    } catch (error) {
      console.error("Error formatting time:", error);
      return timeString;
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  useEffect(() => {
    if (selectedTeam) {
      loadData();
    }
  }, [selectedTeam?.id]);

  // Listen for new events being created
  useEffect(() => {
    const subscription = DeviceEventEmitter.addListener(
      "eventCreated",
      (data) => {
        console.log("🔄 Event created, refreshing schedule...");
        loadData();
      },
    );

    return () => subscription.remove();
  }, []);

  // Refresh when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      if (selectedTeam) {
        loadData();
      }
    }, [selectedTeam?.id]),
  );

  // Early return AFTER all hooks are called
  if (!fontsLoaded) {
    return null;
  }

  // Filter events for list view - only show upcoming events
  const upcomingEvents = events
    .filter((event) => {
      return event.date >= getTodayString();
    })
    .sort((a, b) => {
      // Sort by date ascending (nearest first)
      return a.date.localeCompare(b.date);
    });

  // Group upcoming events by date
  const groupedEvents = upcomingEvents.reduce((groups, event) => {
    const date = event.date;
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(event);
    return groups;
  }, {});

  // Show all events without filtering
  const filteredEvents = events;

  const getEventTypeColor = (type) => {
    const t = (type || "").toLowerCase();
    if (t === "game") return colors.alert; // semantic danger
    if (t === "practice") return colors.primary;
    if (t === "meeting") return colors.success;
    return colors.purple; // fallback accent
  };

  const getEventTypePillColors = (type) => {
    const base = getEventTypeColor(type);
    return { background: base + "20", text: base };
  };

  // Create marked dates for calendar
  const markedDates = {};
  const todayString = getTodayString();

  filteredEvents.forEach((event) => {
    if (!markedDates[event.date]) {
      markedDates[event.date] = { marked: true, dots: [] };
    }

    const color = getEventTypeColor(event.type);

    // Add dot for this event type if not already present
    const existingDot = markedDates[event.date].dots.find(
      (dot) => dot.color === color,
    );
    if (!existingDot) {
      markedDates[event.date].dots.push({ color: color });
    }

    // Add custom styles for selected date
    if (selectedDate === event.date) {
      markedDates[event.date].customStyles = {
        container: {
          backgroundColor: colors.eventBlue,
          borderRadius: 20,
        },
        text: {
          color: colors.primary,
          fontFamily: "Inter_500Medium",
        },
      };
    }
  });

  // Add blue circle outline for today's date
  if (!markedDates[todayString]) {
    markedDates[todayString] = { marked: false, dots: [] };
  }

  // Add blue circle outline to today
  markedDates[todayString] = {
    ...markedDates[todayString],
    customStyles: {
      container: {
        borderWidth: 2,
        borderColor: colors.primary,
        borderRadius: 20,
        ...(selectedDate === todayString && {
          backgroundColor: colors.eventBlue,
        }),
      },
      text: {
        color: selectedDate === todayString ? colors.primary : colors.mainText,
        fontFamily: "Inter_500Medium",
      },
    },
  };

  const eventsForSelectedDate = filteredEvents.filter(
    (event) => event.date === selectedDate,
  );

  const getEventTypeIcon = (type) => {
    switch (type) {
      case "game":
        return "🏆";
      case "practice":
        return "📋";
      case "meeting":
        return "👥";
      default:
        return "📅";
    }
  };

  const EventCard = ({ event }) => {
    const pillColors = getEventTypePillColors(event.type);
    return (
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          marginBottom: 12,
          borderLeftWidth: 4,
          borderLeftColor: getEventTypeColor(event.type),
          overflow: "hidden",
        }}
        onPress={() =>
          router.push({
            pathname: "/event-details",
            params: { id: event.id },
          })
        }
        activeOpacity={0.7}
      >
        <View style={{ padding: 16 }}>
          {/* Header Row */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <View
              style={{ flexDirection: "row", alignItems: "center", flex: 1 }}
            >
              <CalendarIcon
                size={20}
                color={colors.secondaryText}
                style={{ marginRight: 8 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: typography.sectionTitle,
                  color: colors.mainText,
                  textTransform: "capitalize",
                }}
              >
                {event.title}
              </Text>
            </View>

            {/* Event Type Pill */}
            <View
              style={{
                backgroundColor: pillColors.background,
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 16,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: typography.pill,
                  color: pillColors.text,
                  textTransform: "capitalize",
                }}
              >
                {event.type}
              </Text>
            </View>
          </View>

          {/* Description */}
          {event.description && (
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: typography.body,
                color: colors.secondaryText,
                marginBottom: 16,
                marginLeft: 28, // Align with title after icon
              }}
            >
              {event.description}
            </Text>
          )}

          {/* Info Rows */}
          <View style={{ gap: 12 }}>
            {/* Location */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <MapPin size={20} color={colors.secondaryText} />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.body,
                  color: colors.secondaryText,
                  marginLeft: 8,
                }}
              >
                {event.location || "TBD"}
              </Text>
            </View>

            {/* Time */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Clock size={20} color={colors.secondaryText} />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.body,
                  color: colors.secondaryText,
                  marginLeft: 8,
                }}
              >
                {event.time}
              </Text>
            </View>

            {/* Attendance */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Users size={20} color={colors.secondaryText} />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.body,
                  color: colors.secondaryText,
                  marginLeft: 8,
                }}
              >
                {event.attendees}/{event.total} attending
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  // Compact Event Card for List View - simplified version
  const CompactEventCard = ({ event }) => {
    const pillColors = getEventTypePillColors(event.type);
    return (
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          marginBottom: 12,
          borderLeftWidth: 4,
          borderLeftColor: getEventTypeColor(event.type),
          overflow: "hidden",
        }}
        onPress={() =>
          router.push({
            pathname: "/event-details",
            params: { id: event.id },
          })
        }
        activeOpacity={0.7}
      >
        <View style={{ padding: 16 }}>
          {/* Header Row */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "flex-start",
              marginBottom: 12,
            }}
          >
            <View style={{ flex: 1, marginRight: 12 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: typography.sectionTitle,
                  color: colors.mainText,
                  marginBottom: 4,
                }}
              >
                {event.title}
              </Text>

              {/* Time on second line */}
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Clock size={16} color={colors.secondaryText} />
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: typography.small,
                    color: colors.secondaryText,
                    marginLeft: 6,
                  }}
                >
                  {event.time}
                </Text>
              </View>
            </View>

            {/* Event Type Pill */}
            <View
              style={{
                backgroundColor: pillColors.background,
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderRadius: 12,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: typography.pill,
                  color: pillColors.text,
                  textTransform: "capitalize",
                }}
              >
                {event.type}
              </Text>
            </View>
          </View>

          {/* Description - only show if exists and keep it brief */}
          {event.description && (
            <Text
              numberOfLines={2}
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: typography.small,
                color: colors.secondaryText,
                marginBottom: 12,
              }}
            >
              {event.description}
            </Text>
          )}

          {/* Bottom Row - Location and Attendance side by side */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            {/* Location */}
            {event.location && (
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  flex: 1,
                  marginRight: 12,
                }}
              >
                <MapPin size={16} color={colors.secondaryText} />
                <Text
                  numberOfLines={1}
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: typography.small,
                    color: colors.secondaryText,
                    marginLeft: 6,
                  }}
                >
                  {event.location}
                </Text>
              </View>
            )}

            {/* Attendance */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Users size={16} color={colors.secondaryText} />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.small,
                  color: colors.secondaryText,
                  marginLeft: 6,
                }}
              >
                {event.attendees}/{event.total}
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const selectedDateFormatted = (() => {
    const [year, month, day] = selectedDate.split("-");
    const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      day: "numeric",
      month: "long",
    });
  })();

  return (
    <ScreenWrapper>
      <Animated.ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false },
        )}
        scrollEventThrottle={16}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 24,
          }}
        >
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: typography.title,
                color: colors.mainText,
                marginBottom: 4,
              }}
            >
              {t("scheduleTitle")}
            </Text>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginLeft: 16,
            }}
          >
            <TouchableOpacity
              style={{
                width: 44,
                height: 44,
                backgroundColor:
                  viewMode === "calendar" ? colors.primary : colors.lavender,
                borderRadius: 22,
                alignItems: "center",
                justifyContent: "center",
                marginRight: 8,
              }}
              onPress={() => setViewMode("calendar")}
            >
              <CalendarIcon
                size={20}
                color={viewMode === "calendar" ? "white" : colors.secondaryText}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: 44,
                height: 44,
                backgroundColor:
                  viewMode === "list" ? colors.primary : colors.lavender,
                borderRadius: 22,
                alignItems: "center",
                justifyContent: "center",
                marginRight: 8,
              }}
              onPress={() => setViewMode("list")}
            >
              <List
                size={20}
                color={viewMode === "list" ? "white" : colors.secondaryText}
              />
            </TouchableOpacity>
            {/* Only coaches can add events */}
            {isCoach && (
              <TouchableOpacity
                style={{
                  width: 44,
                  height: 44,
                  backgroundColor: colors.primary,
                  borderRadius: 22,
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onPress={() => router.push("/add-event")}
              >
                <Plus size={24} color="white" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Calendar View */}
        {viewMode === "calendar" && (
          <>
            <Calendar
              style={{
                marginBottom: 20,
                backgroundColor: colors.surface,
                borderRadius: 12,
                paddingVertical: 10,
              }}
              current={selectedDate}
              onDayPress={(day) => setSelectedDate(day.dateString)}
              markedDates={markedDates}
              markingType="multi-dot"
              theme={{
                backgroundColor: colors.surface,
                calendarBackground: colors.surface,
                textSectionTitleColor: colors.mainText,
                selectedDayBackgroundColor: colors.primary,
                selectedDayTextColor: "white",
                todayTextColor: colors.primary,
                dayTextColor: colors.mainText,
                textDisabledColor: colors.lightGray,
                arrowColor: colors.primary,
                monthTextColor: colors.mainText,
                textDayFontFamily: "Inter_400Regular",
                textMonthFontFamily: "Inter_600SemiBold",
                textDayHeaderFontFamily: "Inter_500Medium",
                textDayFontSize: 16,
                textMonthFontSize: 18,
                textDayHeaderFontSize: 14,
              }}
              dayComponent={({ date, state }) => {
                const isToday = date.dateString === todayString;
                const isMarked = !!markedDates[date.dateString];
                const hasDots =
                  isMarked && markedDates[date.dateString].dots?.length > 0;
                const isSelected = date.dateString === selectedDate;
                const isDisabled = state === "disabled";

                return (
                  <TouchableOpacity
                    onPress={() =>
                      !isDisabled && setSelectedDate(date.dateString)
                    }
                    disabled={isDisabled}
                    style={{
                      alignItems: "center",
                      justifyContent: "center",
                      width: 40,
                      paddingVertical: 8,
                    }}
                  >
                    <View
                      style={{
                        alignItems: "center",
                        justifyContent: "center",
                        width: 32,
                        height: 32,
                        borderRadius: 16,
                        backgroundColor: isSelected
                          ? colors.eventBlue
                          : "transparent",
                        borderWidth: isToday ? 2 : 0,
                        borderColor: isToday ? colors.primary : "transparent",
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "Inter_500Medium",
                          fontSize: 16,
                          color: isSelected
                            ? colors.primary
                            : isDisabled
                              ? colors.lightGray
                              : colors.mainText,
                        }}
                      >
                        {date.day}
                      </Text>
                    </View>
                    {hasDots && (
                      <View
                        style={{
                          flexDirection: "row",
                          justifyContent: "center",
                          marginTop: 2,
                        }}
                      >
                        {markedDates[date.dateString].dots
                          .slice(0, 3)
                          .map((dot, index) => (
                            <View
                              key={index}
                              style={{
                                width: 4,
                                height: 4,
                                borderRadius: 2,
                                backgroundColor: dot.color,
                                marginHorizontal: 1,
                              }}
                            />
                          ))}
                      </View>
                    )}
                  </TouchableOpacity>
                );
              }}
            />

            {/* Selected Date Events */}
            <View>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: typography.sectionTitle,
                  color: colors.mainText,
                  marginBottom: 16,
                }}
              >
                {selectedDateFormatted}
              </Text>

              {eventsForSelectedDate.length > 0 ? (
                eventsForSelectedDate.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))
              ) : (
                <EmptyState
                  emoji="📅"
                  title={t("noEvents")}
                  description={t("noEvents")}
                  style={{ paddingVertical: 40 }}
                />
              )}
            </View>
          </>
        )}

        {/* List View */}
        {viewMode === "list" && (
          <View>
            {/* Events Pill */}
            <Pill
              label={`${t("allEvents")} (${upcomingEvents.length})`}
              style={{ marginBottom: 20 }}
            />

            {upcomingEvents.length > 0 ? (
              Object.keys(groupedEvents).map((dateKey) => {
                const eventsForDate = groupedEvents[dateKey];
                const isToday = dateKey === getTodayString();

                return (
                  <View key={dateKey} style={{ marginBottom: 20 }}>
                    {/* Date Header */}
                    <View
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        marginBottom: 12,
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "Inter_600SemiBold",
                          fontSize: typography.body,
                          color: isToday ? colors.primary : colors.mainText,
                        }}
                      >
                        {toLocalDate(dateKey).toLocaleDateString("en-US", {
                          weekday: "long",
                          month: "long",
                          day: "numeric",
                        })}
                      </Text>
                      {isToday && (
                        <View
                          style={{
                            backgroundColor: colors.primary + "20",
                            paddingHorizontal: 8,
                            paddingVertical: 2,
                            borderRadius: 8,
                            marginLeft: 8,
                          }}
                        >
                          <Text
                            style={{
                              fontFamily: "Inter_500Medium",
                              fontSize: typography.small,
                              color: colors.primary,
                            }}
                          >
                            {t("today") || "Today"}
                          </Text>
                        </View>
                      )}
                    </View>

                    {/* Events for this date */}
                    {eventsForDate.map((event) => (
                      <CompactEventCard key={event.id} event={event} />
                    ))}
                  </View>
                );
              })
            ) : loading ? (
              <EmptyState
                emoji="⏳"
                title={t("loading")}
                description={t("loading")}
                style={{ paddingVertical: 60 }}
              />
            ) : (
              <EmptyState
                emoji="📅"
                title={t("noEvents")}
                description={t("noEvents")}
                style={{ paddingVertical: 60 }}
              />
            )}
          </View>
        )}
      </Animated.ScrollView>
    </ScreenWrapper>
  );
}
