import React, { useState, useEffect } from "react";
import {
  Animated,
  RefreshControl,
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useFocusEffect } from "expo-router";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import EmptyState from "@/components/EmptyState";
import { useAuth } from "@/utils/auth/useAuth";
import { useDashboardData } from "@/hooks/useDashboardData";
import { useFundraisers } from "@/hooks/useFundraisers";
import useFundraiserActions from "@/hooks/useFundraiserActions";
import { calculateFundraiserStats } from "@/utils/fundraiserHelpers";
import { FundraiserCard } from "@/components/payments/FundraiserCard";
import { UpdateProgressModal } from "@/components/payments/UpdateProgressModal";
import { FundraiserHeader } from "@/components/payments/FundraiserHeader";
import { FundraiserSectionHeader } from "@/components/payments/FundraiserSectionHeader";
import { LoadingState } from "@/components/payments/LoadingState";
import useUser from "@/utils/auth/useUser";

export default function Fundraising() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const { auth, isReady, isAuthenticated } = useAuth();

  // Get selected team from dashboard data (no dropdown here)
  const { selectedTeam } = useDashboardData();
  const { data: user } = useUser();
  const canManage = React.useMemo(() => {
    const roleValue =
      selectedTeam?.user_role ||
      selectedTeam?.role ||
      selectedTeam?.current_user_role ||
      (selectedTeam?.is_owner ? "owner" : null);

    const roleStr =
      typeof roleValue === "string" ? roleValue.toLowerCase() : "";

    if (roleStr === "coach" || roleStr === "owner") return true;
    if (selectedTeam?.is_owner === true) return true;

    const ownerId = selectedTeam?.owner_id ?? selectedTeam?.ownerId;
    if (user?.id && ownerId && String(ownerId) === String(user.id)) return true;
    return false;
  }, [
    selectedTeam?.user_role,
    selectedTeam?.role,
    selectedTeam?.current_user_role,
    selectedTeam?.is_owner,
    selectedTeam?.owner_id,
    selectedTeam?.ownerId,
    user?.id,
  ]);

  const [scrollY] = useState(new Animated.Value(0));
  const [updateModalVisible, setUpdateModalVisible] = useState(false);
  const [selectedFundraiser, setSelectedFundraiser] = useState(null);

  // Use custom hooks with team filtering
  const { fundraisers, loading, refreshing, fetchFundraisers, refresh } =
    useFundraisers(selectedTeam);
  const { handleUpdateProgress, handleDeleteFundraiser } = useFundraiserActions(
    auth,
    fetchFundraisers,
  );

  // Debug auth state
  useEffect(() => {
    console.log("DEBUG: Fundraising component auth state:", {
      isReady,
      isAuthenticated,
      auth,
      authJwt: auth?.jwt,
      authKeys: auth ? Object.keys(auth) : "auth is null/undefined",
    });
  }, [auth, isReady, isAuthenticated]);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  // Refresh fundraisers when screen comes into focus — only after a team is selected
  useFocusEffect(
    React.useCallback(() => {
      if (selectedTeam?.id) {
        fetchFundraisers();
      }
      // Do nothing until a team is available to avoid cross-team overlap
    }, [selectedTeam?.id]),
  );

  if (!fontsLoaded) {
    return null;
  }

  const handleOpenUpdateModal = (fundraiser) => {
    setSelectedFundraiser(fundraiser);
    setUpdateModalVisible(true);
  };

  const handleCloseUpdateModal = () => {
    setUpdateModalVisible(false);
    setSelectedFundraiser(null);
  };

  // If no team is selected yet, show a friendly prompt
  if (!selectedTeam) {
    return (
      <ScreenWrapper>
        <Animated.ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 20,
            paddingHorizontal: 16,
          }}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: scrollY } } }],
            { useNativeDriver: false },
          )}
          scrollEventThrottle={16}
        >
          <FundraiserHeader selectedTeam={selectedTeam} />
          <EmptyState
            emoji="🏆"
            title={t("selectTeam")}
            description={t("chooseTeam")}
            style={{ paddingVertical: 60 }}
          />
        </Animated.ScrollView>
      </ScreenWrapper>
    );
  }

  // Calculate stats
  const stats = calculateFundraiserStats(fundraisers);

  if (loading) {
    return <LoadingState />;
  }

  return (
    <ScreenWrapper>
      <Animated.ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false },
        )}
        scrollEventThrottle={16}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Header */}
        <FundraiserHeader selectedTeam={selectedTeam} canManage={canManage} />

        {/* Fundraisers Section */}
        <FundraiserSectionHeader
          activeFundraisers={stats.activeFundraisers}
          completedFundraisers={stats.completedFundraisers}
        />

        {fundraisers.length > 0 ? (
          fundraisers.map((fundraiser) => (
            <FundraiserCard
              key={fundraiser.id}
              fundraiser={fundraiser}
              canManage={canManage}
              onUpdate={handleOpenUpdateModal}
              onDelete={handleDeleteFundraiser}
            />
          ))
        ) : (
          <>
            <EmptyState
              emoji="🎯"
              title={t("noFundraisers")}
              description={t("noFundraisers")}
              style={{ paddingVertical: 60 }}
            />
          </>
        )}
      </Animated.ScrollView>

      {/* Update Progress Modal */}
      <UpdateProgressModal
        visible={updateModalVisible}
        fundraiser={selectedFundraiser}
        onClose={handleCloseUpdateModal}
        onSave={handleUpdateProgress}
      />
    </ScreenWrapper>
  );
}
