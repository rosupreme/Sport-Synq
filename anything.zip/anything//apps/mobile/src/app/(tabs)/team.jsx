import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Animated,
  Alert,
  ActivityIndicator,
  Image,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useFocusEffect } from "expo-router";
import { Plus, Mail, Shield, User, Users } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import EmptyState from "@/components/EmptyState";
import Pill from "@/components/Pill";
import { useAuth } from "@/utils/auth/useAuth";
import useUser from "@/utils/auth/useUser";
import { useDashboardData } from "@/hooks/useDashboardData";
import { fetchWithAuth } from "@/utils/api"; // use shared helper so Authorization is included

export default function Team() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark, typography } = useTheme();
  const { t } = useLanguage();
  const { signOut } = useAuth();
  const { data: user } = useUser();

  // Get selected team from dashboard data (no dropdown here)
  const { selectedTeam } = useDashboardData();
  const isCoach = React.useMemo(() => {
    const roleValue =
      selectedTeam?.user_role ||
      selectedTeam?.role ||
      selectedTeam?.current_user_role ||
      (selectedTeam?.is_owner ? "owner" : null);

    const roleStr =
      typeof roleValue === "string" ? roleValue.toLowerCase() : "";

    if (roleStr === "coach" || roleStr === "owner") return true;
    if (selectedTeam?.is_owner === true) return true;

    const ownerId = selectedTeam?.owner_id ?? selectedTeam?.ownerId;
    if (user?.id && ownerId && String(ownerId) === String(user.id)) return true;
    return false;
  }, [
    selectedTeam?.user_role,
    selectedTeam?.role,
    selectedTeam?.current_user_role,
    selectedTeam?.is_owner,
    selectedTeam?.owner_id,
    selectedTeam?.ownerId,
    user?.id,
  ]);

  const [scrollY] = useState(new Animated.Value(0));
  const [teamMembers, setTeamMembers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  // Fetch team members when selectedTeam changes
  useEffect(() => {
    if (selectedTeam) {
      fetchTeamMembers();
    }
  }, [selectedTeam?.id]); // depend on stable id only

  // Refresh when screen comes into focus (e.g., returning from add player)
  useFocusEffect(
    React.useCallback(() => {
      if (selectedTeam) {
        fetchTeamMembers();
      }
    }, [selectedTeam?.id]),
  );

  const fetchTeamMembers = async () => {
    if (!selectedTeam?.id) {
      setTeamMembers([]);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);

      // Fetch team members for the selected team (authenticated)
      const membersData = await fetchWithAuth(
        `/api/players?teamId=${selectedTeam.id}`,
      );

      setTeamMembers(membersData.players || []);
    } catch (error) {
      console.error("Error fetching team members:", error);
      Alert.alert("Error", "Failed to load team members. Please try again.");
      setTeamMembers([]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  // Show loading spinner while fetching data
  if (isLoading) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top + 20,
          }}
        >
          <ActivityIndicator size="large" color={colors.primary} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.secondaryText,
              marginTop: 16,
            }}
          >
            {t("loading")}
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  // Only show players
  const players = teamMembers.filter((member) => member.role === "Player");

  const TeamMemberCard = ({ member }) => {
    // Get initials from name
    const getInitials = (name) => {
      if (!name) return "?";
      const parts = name.split(" ");
      if (parts.length === 1) {
        return parts[0].charAt(0).toUpperCase();
      }
      return (
        parts[0].charAt(0) + parts[parts.length - 1].charAt(0)
      ).toUpperCase();
    };

    return (
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 20,
          marginBottom: 16,
          borderWidth: 1,
          borderColor: colors.border,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.05,
          shadowRadius: 8,
          elevation: 2,
          opacity: member.isActive !== false ? 1 : 0.6,
        }}
        onPress={() =>
          router.push({
            pathname: "/player-details",
            params: { playerId: member.id },
          })
        }
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <View style={{ position: "relative", marginRight: 16 }}>
            {/* Avatar with initials or photo */}
            <View
              style={{
                width: 60,
                height: 60,
                borderRadius: 30,
                backgroundColor: colors.lavender,
                alignItems: "center",
                justifyContent: "center",
                overflow: "hidden",
              }}
            >
              {member.image ? (
                <Image
                  source={{ uri: member.image }}
                  style={{
                    width: 60,
                    height: 60,
                    borderRadius: 30,
                  }}
                />
              ) : (
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 20,
                    color: colors.primary,
                  }}
                >
                  {getInitials(member.name)}
                </Text>
              )}
            </View>

            {/* Jersey number badge */}
            {member.jerseyNumber && (
              <View
                style={{
                  position: "absolute",
                  bottom: -4,
                  right: -4,
                  backgroundColor: colors.primary,
                  borderRadius: 12,
                  width: 24,
                  height: 24,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 2,
                  borderColor: colors.surface,
                }}
              >
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 12,
                    color: "white",
                  }}
                >
                  {member.jerseyNumber}
                </Text>
              </View>
            )}
          </View>

          <View style={{ flex: 1 }}>
            {/* Player name */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 18,
                  color: colors.mainText,
                  flex: 1,
                }}
              >
                {member.name}
              </Text>
              {member.isActive === false && (
                <View
                  style={{
                    backgroundColor: colors.alert + "20",
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    borderRadius: 12,
                  }}
                >
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 10,
                      color: colors.alert,
                    }}
                  >
                    Inactive
                  </Text>
                </View>
              )}
            </View>

            {/* Role and position */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.success,
                }}
              >
                {member.role}
              </Text>
              {member.position && (
                <>
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 14,
                      color: colors.secondaryText,
                      marginHorizontal: 8,
                    }}
                  >
                    •
                  </Text>
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 14,
                      color: colors.secondaryText,
                    }}
                  >
                    {member.position}
                  </Text>
                </>
              )}
            </View>

            {/* Email */}
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Mail size={16} color={colors.secondaryText} />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.secondaryText,
                  marginLeft: 8,
                  flex: 1,
                }}
                numberOfLines={1}
              >
                {member.email}
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenWrapper>
      <Animated.ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false },
        )}
        scrollEventThrottle={16}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 24,
          }}
        >
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: typography.title,
                color: colors.mainText,
                marginBottom: 4,
              }}
            >
              {t("team")}
            </Text>
          </View>

          {isCoach && (
            <TouchableOpacity
              style={{
                width: 44,
                height: 44,
                backgroundColor: colors.primary,
                borderRadius: 22,
                alignItems: "center",
                justifyContent: "center",
                marginLeft: 16,
              }}
              onPress={() => router.push("/add-player")}
            >
              <Plus size={24} color="white" />
            </TouchableOpacity>
          )}
        </View>

        {/* Consistent pill placement (match Schedule/Fundraising) */}
        <View style={{ marginBottom: 20 }}>
          <Pill label={`${t("players")} (${players.length})`} />
        </View>

        {/* Team Members List */}
        <View>
          {!selectedTeam ? (
            <EmptyState
              emoji="🏆"
              title={t("selectTeam")}
              description={t("chooseTeam")}
              style={{ paddingVertical: 60 }}
            />
          ) : players.length > 0 ? (
            players.map((member) => (
              <TeamMemberCard key={member.id} member={member} />
            ))
          ) : (
            <EmptyState
              emoji="👥"
              title={t("noPlayers")}
              description={`${t("noPlayers")} ${selectedTeam.name}.`}
              style={{ paddingVertical: 60 }}
            />
          )}
        </View>
      </Animated.ScrollView>
    </ScreenWrapper>
  );
}
