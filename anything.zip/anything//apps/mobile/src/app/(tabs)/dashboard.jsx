import React, { useState, useMemo } from "react";
import { View, Text, TouchableOpacity, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback } from "react";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import {
  ChevronDown,
  Plus,
  MoreHorizontal,
  Sun,
  Clock,
  MapPin,
  Users,
  User,
  Calendar,
} from "lucide-react-native";
import ScreenWrapper from "../../components/ScreenWrapper";
import { useTheme } from "../../components/ThemeProvider";
import { useLanguage } from "../../components/LanguageProvider";
import Pill from "@/components/Pill";
import { useDashboardData } from "../../hooks/useDashboardData";
import { useUpcomingEvents } from "../../hooks/useUpcomingEvents";
import { TeamDropdown } from "../../components/dashboard/TeamDropdown";
import useUser from "@/utils/auth/useUser";

export default function Dashboard() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, typography } = useTheme();
  const { t } = useLanguage();
  const [showTeamDropdown, setShowTeamDropdown] = useState(false);
  const { data: user } = useUser();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  const { loading, teams, selectedTeam, loadingTeams, handleTeamSelect } =
    useDashboardData();

  // Determine if user is a coach/owner on ANY team (not just selected team)
  const isCoachOnAnyTeam = useMemo(() => {
    if (!teams || teams.length === 0 || !user?.id) return false;

    return teams.some((team) => {
      const roleValue =
        team.user_role ||
        team.role ||
        team.current_user_role ||
        (team.is_owner ? "owner" : null);
      const roleStr =
        typeof roleValue === "string" ? roleValue.toLowerCase() : "";

      if (roleStr === "coach" || roleStr === "owner") return true;
      if (team.is_owner === true) return true;

      const ownerId = team.owner_id ?? team.ownerId;
      if (ownerId && String(ownerId) === String(user.id)) return true;

      return false;
    });
  }, [teams, user?.id]);

  // Derive coach capability for selected team with fallbacks (role prop, ownership flag, or owner id)
  const isCoach = useMemo(() => {
    const roleValue =
      selectedTeam?.user_role ||
      selectedTeam?.role ||
      selectedTeam?.current_user_role ||
      (selectedTeam?.is_owner ? "owner" : null);

    const roleStr =
      typeof roleValue === "string" ? roleValue.toLowerCase() : "";

    if (roleStr === "coach" || roleStr === "owner") return true;

    // Fallback: explicit boolean from API
    if (selectedTeam?.is_owner === true) return true;

    // Fallback: compare owner id if present
    if (user?.id) {
      const ownerId = selectedTeam?.owner_id ?? selectedTeam?.ownerId;
      if (ownerId && String(ownerId) === String(user.id)) return true;
    }

    return false;
  }, [
    selectedTeam?.user_role,
    selectedTeam?.role,
    selectedTeam?.current_user_role,
    selectedTeam?.is_owner,
    selectedTeam?.owner_id,
    selectedTeam?.ownerId,
    user?.id,
  ]);

  const {
    upcomingEvents,
    loading: eventsLoading,
    refresh: refreshEvents,
  } = useUpcomingEvents(selectedTeam);

  // Refresh data when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      refreshEvents();
    }, [selectedTeam?.id]), // depend on stable team id so this doesn't remount on every render
  );

  // Filter events based on selected team - ensure upcomingEvents is always an array
  const filteredEvents =
    selectedTeam && upcomingEvents
      ? upcomingEvents.filter((event) => event.team_id === selectedTeam.id)
      : [];

  const onTeamSelect = (team) => {
    handleTeamSelect(team);
    setShowTeamDropdown(false);
    // Refresh events when team changes
    refreshEvents();
  };

  const EventCard = ({ event }) => {
    const eventTypes = {
      practice: {
        label: t("practice"),
        color: colors.primary,
        pillBg: colors.primary + "20",
      },
      game: {
        label: t("game"),
        color: colors.alert,
        pillBg: colors.alert + "20",
      },
      meeting: {
        label: t("meeting"),
        color: colors.success,
        pillBg: colors.success + "20",
      },
      other: {
        label: t("other"),
        color: colors.purple,
        pillBg: colors.purple + "20",
      },
    };

    // Determine event type
    const getEventTypeKey = (type) => {
      if (!type) return "other";
      if (type.toLowerCase().includes("practice")) return "practice";
      if (type.toLowerCase().includes("game")) return "game";
      if (type.toLowerCase().includes("meeting")) return "meeting";
      return "other";
    };

    const eventTypeKey = getEventTypeKey(event.event_type);
    const eventTypeConfig = eventTypes[eventTypeKey] || eventTypes.practice;

    // Format time from API format
    const formatTime = (timeString) => {
      if (!timeString) return "";
      const [hours, minutes] = timeString.split(":");
      const hour = parseInt(hours);
      const ampm = hour >= 12 ? "PM" : "AM";
      const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
      return `${displayHour}:${minutes} ${ampm}`;
    };

    // Parse a YYYY-MM-DD (or YYYY-MM-DDTHH:mm:ss) as LOCAL date to avoid UTC shift
    const parseLocalDate = (value) => {
      if (!value) return null;
      const str = String(value);
      const datePart = str.includes("T") ? str.split("T")[0] : str; // YYYY-MM-DD
      const [y, m, d] = datePart.split("-").map((n) => parseInt(n, 10));
      if (!y || !m || !d) return null;
      return new Date(y, m - 1, d); // Local time
    };

    // Format date using local parsing to avoid off-by-one
    const formatDate = (dateString) => {
      const date = parseLocalDate(dateString);
      if (!date) return "";
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
    };

    // Get attendance counts from event data
    const goingCount = event.going_count || 0;
    const totalInvited = event.total_invited || 0;

    return (
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          padding: 16,
          marginBottom: 12,
          borderLeftWidth: 4,
          borderLeftColor: eventTypeConfig.color,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.05,
          shadowRadius: 2,
          elevation: 1,
        }}
        onPress={() => {
          // Remove debug console.log statements
          if (event.id) {
            router.push({
              pathname: "/event-details",
              params: { id: event.id },
            });
          }
        }}
        activeOpacity={0.7}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "flex-start",
          }}
        >
          <View style={{ flex: 1, marginRight: 12 }}>
            {/* Date & Time Row */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Clock
                size={20}
                color={colors.secondaryText}
                style={{ marginRight: 10 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: typography.body,
                  color: colors.mainText,
                }}
              >
                {formatDate(event.event_date)} • {formatTime(event.event_time)}
              </Text>
            </View>

            {/* Location Row */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <MapPin
                size={20}
                color={colors.secondaryText}
                style={{ marginRight: 10 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.body,
                  color: colors.secondaryText,
                }}
              >
                {event.location || "TBD"}
              </Text>
            </View>

            {/* Attendance Row */}
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Users
                size={20}
                color={colors.secondaryText}
                style={{ marginRight: 10 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.body,
                  color: colors.secondaryText,
                }}
              >
                {goingCount}/{totalInvited}
              </Text>
            </View>
          </View>

          {/* Event Type Pill */}
          <View
            style={{
              backgroundColor: eventTypeConfig.pillBg,
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 16,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: typography.pill,
                color: eventTypeConfig.color,
              }}
            >
              {eventTypeConfig.label}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenWrapper>
      <TeamDropdown
        visible={showTeamDropdown}
        onClose={() => setShowTeamDropdown(false)}
        teams={teams}
        selectedTeam={selectedTeam}
        onTeamSelect={onTeamSelect}
        showCreateTeam={isCoachOnAnyTeam}
        showJoinTeam={!isCoachOnAnyTeam}
      />

      <View style={{ flex: 1, paddingTop: insets.top + 20 }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingHorizontal: 16,
            paddingBottom: 24, // increased to match other pages
          }}
        >
          {/* Profile Icon (left) */}
          <TouchableOpacity
            style={{
              width: 44,
              height: 44,
              backgroundColor: colors.surface,
              borderRadius: 22,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
            onPress={() => router.push("/profile")}
            activeOpacity={0.7}
            accessibilityLabel="Open profile"
          >
            <User size={20} color={colors.mainText} />
          </TouchableOpacity>

          {/* Center: Team selector - force true center by giving it flex:1 */}
          <View style={{ flex: 1, alignItems: "center" }}>
            <TouchableOpacity
              onPress={() => setShowTeamDropdown(true)}
              style={{
                flexDirection: "row",
                alignItems: "center",
                paddingHorizontal: 8,
                paddingVertical: 4,
              }}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              activeOpacity={0.7}
              accessibilityLabel="Select team"
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: typography.title,
                  color: colors.mainText,
                  marginRight: 6,
                }}
              >
                {selectedTeam?.name || "Team"}
              </Text>
              <ChevronDown size={18} color={colors.secondaryText} />
            </TouchableOpacity>
          </View>

          {/* Right spacer to keep title centered */}
          <View
            style={{
              width: 44,
              height: 44,
            }}
          />
        </View>

        {/* Events Cards */}
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingBottom: insets.bottom + 20,
            paddingHorizontal: 16,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Consistent pill placement under header, aligned with other pages */}
          <View style={{ marginBottom: 20 }}>
            <Pill label={`${t("upcomingEvents")} (${filteredEvents.length})`} />
          </View>

          {!selectedTeam ? (
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 60,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: typography.sectionTitle,
                  color: colors.mainText,
                  marginBottom: 8,
                  textAlign: "center",
                }}
              >
                {t("selectTeam")}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.body,
                  color: colors.secondaryText,
                  textAlign: "center",
                  lineHeight: 24,
                }}
              >
                {t("chooseTeam")}
              </Text>
            </View>
          ) : filteredEvents.length > 0 ? (
            filteredEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))
          ) : (
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 60,
              }}
            >
              <Text
                style={{
                  fontSize: 40,
                  marginBottom: 16,
                }}
              >
                📅
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: typography.sectionTitle,
                  color: colors.mainText,
                  marginBottom: 8,
                  textAlign: "center",
                }}
              >
                {t("noUpcomingEvents")}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: typography.body,
                  color: colors.secondaryText,
                  textAlign: "center",
                  lineHeight: 24,
                  marginBottom: 20,
                }}
              >
                {selectedTeam.name} {t("noUpcomingEvents").toLowerCase()}
              </Text>
              {/* Hide Create Event for players */}
              {isCoach && (
                <TouchableOpacity
                  style={{
                    backgroundColor: colors.primary,
                    paddingHorizontal: 20,
                    paddingVertical: 12,
                    borderRadius: 12,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                  onPress={() => router.push("/add-event")}
                >
                  <Plus
                    size={16}
                    color={colors.onPrimary}
                    style={{ marginRight: 8 }}
                  />
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: typography.button,
                      color: colors.onPrimary,
                    }}
                  >
                    {t("createEventButton")}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        </ScrollView>
      </View>
    </ScreenWrapper>
  );
}
