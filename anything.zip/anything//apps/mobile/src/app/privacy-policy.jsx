import React from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useTheme } from "@/components/ThemeProvider";

export default function PrivacyPolicy() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const H2 = ({ children }) => (
    <Text
      style={{
        fontFamily: "Inter_600SemiBold",
        fontSize: 16,
        color: colors.mainText,
        marginTop: 16,
        marginBottom: 8,
      }}
    >
      {children}
    </Text>
  );

  const P = ({ children }) => (
    <Text
      style={{
        fontFamily: "Inter_400Regular",
        fontSize: 14,
        lineHeight: 22,
        color: colors.bodyText,
        marginBottom: 10,
      }}
    >
      {children}
    </Text>
  );

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <TouchableOpacity
          style={{
            width: 40,
            height: 40,
            backgroundColor: colors.lavender,
            borderRadius: 20,
            alignItems: "center",
            justifyContent: "center",
            marginRight: 16,
          }}
          onPress={() => router.back()}
          accessibilityLabel="Go back"
        >
          <ArrowLeft size={20} color={colors.primary} />
        </TouchableOpacity>

        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: colors.mainText,
              marginBottom: 4,
            }}
          >
            Privacy Policy
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
            }}
          >
            Last updated: January 16, 2026
          </Text>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: 16,
          paddingHorizontal: 16,
          paddingBottom: insets.bottom + 40,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            borderWidth: 1,
            borderColor: colors.border,
            padding: 16,
          }}
        >
          <P>
            This Privacy Policy explains how Sport-Synq collects, uses, and
            shares information when you use the App.
          </P>

          <H2>1) What we collect</H2>
          <P>
            Depending on how you use the App, we may collect information like:
            your name, email, phone number, profile photo, team membership,
            schedules/events, attendance responses, evaluation notes, and
            fundraising information.
          </P>

          <H2>2) How we use information</H2>
          <P>
            We use information to operate the App (like letting you log in,
            showing your teams, saving your profile, and sending reminders if
            you enable notifications).
          </P>

          <H2>3) Sharing</H2>
          <P>
            Team-related information is shared with other team members according
            to the role and access rules in the App. We may also use trusted
            service providers to run the App (for example, hosting,
            authentication, payments/subscriptions, and file uploads).
          </P>

          <H2>4) Payments</H2>
          <P>
            If you purchase subscriptions or make payments, those transactions
            are processed by third-party providers (such as the app stores
            and/or payment processors). We do not store full payment card
            details ourselves.
          </P>

          <H2>5) Data retention</H2>
          <P>
            We keep information as long as needed to provide the App and for
            legitimate business purposes (like security, preventing abuse, and
            meeting legal obligations).
          </P>

          <H2>6) Security</H2>
          <P>
            We take reasonable steps to protect your information. No system is
            perfectly secure, so we can’t guarantee absolute security.
          </P>

          <H2>7) Children’s privacy</H2>
          <P>
            The App is designed for team management. If a child uses the App,
            their account should be created and managed with appropriate
            parent/guardian or coach oversight.
          </P>

          <H2>8) Changes</H2>
          <P>
            We may update this Privacy Policy from time to time. If we make
            major changes, we’ll try to make it clear in the App.
          </P>

          <H2>Contact</H2>
          <P>
            For privacy questions, please use the Help & Support screen inside
            the App.
          </P>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
