import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  Animated,
  Platform,
} from "react-native";
import { DeviceEventEmitter } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft, Users, Plus } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import { useAuth } from "@/utils/auth/useAuth";
import { fetchWithAuth } from "@/utils/api";

export default function AddTeam() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { auth } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    sport: "Soccer",
    season: "2024-25",
  });

  const focusedPadding = 12;
  const paddingAnimation = useRef(
    new Animated.Value(insets.bottom + focusedPadding),
  ).current;

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const animateTo = (value) => {
    Animated.timing(paddingAnimation, {
      toValue: value,
      duration: 200,
      useNativeDriver: false,
    }).start();
  };

  const handleInputFocus = () => {
    if (Platform.OS === "web") {
      return;
    }
    animateTo(focusedPadding);
  };

  const handleInputBlur = () => {
    if (Platform.OS === "web") {
      return;
    }
    animateTo(insets.bottom + focusedPadding);
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.name.trim()) {
      Alert.alert("Error", "Please enter a team name");
      return;
    }

    setLoading(true);

    try {
      // Use authenticated helper and let it set Authorization header
      const data = await fetchWithAuth("/api/teams", {
        method: "POST",
        body: JSON.stringify(formData),
      });

      const team = data?.team;

      // Persist selection and notify dashboard to refresh
      if (team?.id) {
        await AsyncStorage.setItem("selected_team_id", String(team.id));
        DeviceEventEmitter.emit("teamCreated", { team });
      }

      Alert.alert("Success", "Team created successfully!", [
        {
          text: "OK",
          onPress: () => router.back(),
        },
      ]);
    } catch (error) {
      console.error("Create team error:", error);
      Alert.alert("Error", error.message || "Failed to create team");
    } finally {
      setLoading(false);
    }
  };

  const sports = [
    "Soccer",
    "Basketball",
    "Football",
    "Baseball",
    "Tennis",
    "Volleyball",
    "Hockey",
    "Swimming",
    "Track & Field",
    "Other",
  ];

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <Animated.View
          style={{
            flex: 1,
            paddingBottom: paddingAnimation,
          }}
        >
          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{
              paddingTop: insets.top + 20,
              paddingHorizontal: 16,
              paddingBottom: 20,
            }}
            showsVerticalScrollIndicator={false}
          >
            {/* Header */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 32,
              }}
            >
              <TouchableOpacity
                onPress={() => router.back()}
                style={{
                  padding: 8,
                  marginRight: 12,
                  marginLeft: -8,
                }}
              >
                <ArrowLeft size={24} color={colors.mainText} />
              </TouchableOpacity>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 24,
                    color: colors.mainText,
                  }}
                >
                  Create Team
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 16,
                    color: colors.secondaryText,
                    marginTop: 4,
                  }}
                >
                  Set up your new team
                </Text>
              </View>
            </View>

            {/* Team Icon */}
            <View
              style={{
                alignItems: "center",
                marginBottom: 32,
              }}
            >
              <View
                style={{
                  width: 80,
                  height: 80,
                  backgroundColor: colors.primary + "20",
                  borderRadius: 40,
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 16,
                }}
              >
                <Users size={32} color={colors.primary} />
              </View>
            </View>

            {/* Form */}
            <View style={{ gap: 24 }}>
              {/* Team Name */}
              <View>
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 16,
                    color: colors.mainText,
                    marginBottom: 8,
                  }}
                >
                  Team Name *
                </Text>
                <TextInput
                  style={{
                    backgroundColor: colors.surface,
                    borderRadius: 12,
                    paddingHorizontal: 16,
                    paddingVertical: 14,
                    fontSize: 16,
                    color: colors.mainText,
                    borderWidth: 1,
                    borderColor: colors.border,
                    fontFamily: "Inter_400Regular",
                  }}
                  placeholder="Enter team name"
                  placeholderTextColor={colors.secondaryText}
                  value={formData.name}
                  onChangeText={(text) =>
                    setFormData({ ...formData, name: text })
                  }
                  onFocus={handleInputFocus}
                  onBlur={handleInputBlur}
                />
              </View>

              {/* Sport */}
              <View>
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 16,
                    color: colors.mainText,
                    marginBottom: 8,
                  }}
                >
                  Sport
                </Text>
                <View
                  style={{
                    flexDirection: "row",
                    flexWrap: "wrap",
                    gap: 8,
                  }}
                >
                  {sports.map((sport) => (
                    <TouchableOpacity
                      key={sport}
                      style={{
                        backgroundColor:
                          formData.sport === sport
                            ? colors.primary
                            : colors.surface,
                        borderRadius: 20,
                        paddingHorizontal: 16,
                        paddingVertical: 8,
                        borderWidth: 1,
                        borderColor:
                          formData.sport === sport
                            ? colors.primary
                            : colors.border,
                      }}
                      onPress={() => setFormData({ ...formData, sport })}
                    >
                      <Text
                        style={{
                          fontFamily: "Inter_500Medium",
                          fontSize: 14,
                          color:
                            formData.sport === sport
                              ? "white"
                              : colors.mainText,
                        }}
                      >
                        {sport}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {/* Season */}
              <View>
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 16,
                    color: colors.mainText,
                    marginBottom: 8,
                  }}
                >
                  Season
                </Text>
                <TextInput
                  style={{
                    backgroundColor: colors.surface,
                    borderRadius: 12,
                    paddingHorizontal: 16,
                    paddingVertical: 14,
                    fontSize: 16,
                    color: colors.mainText,
                    borderWidth: 1,
                    borderColor: colors.border,
                    fontFamily: "Inter_400Regular",
                  }}
                  placeholder="e.g., 2024-25"
                  placeholderTextColor={colors.secondaryText}
                  value={formData.season}
                  onChangeText={(text) =>
                    setFormData({ ...formData, season: text })
                  }
                  onFocus={handleInputFocus}
                  onBlur={handleInputBlur}
                />
              </View>
            </View>

            {/* Create Button */}
            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                borderRadius: 12,
                paddingVertical: 16,
                alignItems: "center",
                marginTop: 32,
                opacity: loading ? 0.6 : 1,
              }}
              onPress={handleSubmit}
              disabled={loading}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <Plus size={20} color="white" style={{ marginRight: 8 }} />
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 16,
                    color: "white",
                  }}
                >
                  {loading ? "Creating..." : "Create Team"}
                </Text>
              </View>
            </TouchableOpacity>
          </ScrollView>
        </Animated.View>
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
