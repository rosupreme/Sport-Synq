import React, { useEffect, useMemo, useState, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  Linking,
  ActivityIndicator,
  Platform,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import Purchases, { LOG_LEVEL } from "react-native-purchases";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Check,
  ArrowLeft,
  Info,
  Zap,
  XCircle,
  AlertTriangle,
} from "lucide-react-native";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useTheme } from "@/components/ThemeProvider";
import { useUser } from "@/utils/auth/useUser";
import { fetchWithAuth } from "@/utils/api";
import useInAppPurchase from "@/hooks/useInAppPurchase";

// Resolve the correct RevenueCat API key based on environment
const getRevenueCatApiKey = () => {
  try {
    if (process.env.EXPO_PUBLIC_CREATE_ENV === "DEVELOPMENT") {
      return (
        process.env.EXPO_PUBLIC_REVENUE_CAT_TEST_STORE_API_KEY ||
        process.env.REVENUE_CAT_API_KEY
      );
    }
    if (Platform.OS === "ios") {
      return (
        process.env.EXPO_PUBLIC_REVENUE_CAT_APP_STORE_API_KEY ||
        process.env.REVENUE_CAT_API_KEY
      );
    }
    if (Platform.OS === "android") {
      return (
        process.env.EXPO_PUBLIC_REVENUE_CAT_PLAY_STORE_API_KEY ||
        process.env.REVENUE_CAT_API_KEY
      );
    }
    return (
      process.env.EXPO_PUBLIC_REVENUE_CAT_TEST_STORE_API_KEY ||
      process.env.REVENUE_CAT_API_KEY
    );
  } catch (e) {
    return undefined;
  }
};

export default function SubscriptionsPage() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { data: user, loading: userLoading } = useUser();
  const queryClient = useQueryClient();
  const [rcReady, setRcReady] = useState(false);
  const [packages, setPackages] = useState([]);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const { isCoach } = useInAppPurchase();

  // Configure RevenueCat once
  useEffect(() => {
    const setup = async () => {
      try {
        const apiKey = getRevenueCatApiKey();
        if (!apiKey) {
          console.warn(
            "RevenueCat API key is not set. Please connect your RevenueCat project and set EXPO_PUBLIC_REVENUE_CAT_* keys.",
          );
          setRcReady(false);
          return;
        }
        Purchases.setLogLevel(LOG_LEVEL.WARN);
        await Purchases.configure({ apiKey });
        if (user?.id) {
          try {
            await Purchases.logIn(String(user.id));
          } catch {
            // Ignore; logIn can throw if already logged in
          }
        }
        setRcReady(true);
      } catch (e) {
        console.error("Failed to initialize RevenueCat", e);
        setRcReady(false);
      }
    };
    setup();
  }, [user?.id]);

  // Load available packages from RevenueCat
  useEffect(() => {
    const loadPackages = async () => {
      if (!rcReady) return;

      try {
        const offerings = await Purchases.getOfferings();
        if (offerings.current && offerings.current.availablePackages) {
          const availablePackages = offerings.current.availablePackages;

          // Filter to only include our custom plans (Standard, Plus, Pro)
          // This excludes default package types like "monthly", "yearly", "lifetime"
          const customPlans = availablePackages.filter((pkg) => {
            const id = pkg.identifier.toLowerCase();
            return (
              id.includes("standard") ||
              id.includes("plus") ||
              id.includes("pro")
            );
          });

          // Sort packages: Standard, Plus, Pro
          const sortedPackages = customPlans.sort((a, b) => {
            const getOrder = (identifier) => {
              const id = identifier.toLowerCase();
              if (id.includes("standard")) return 0;
              if (id.includes("plus")) return 1;
              if (id.includes("pro")) return 2;
              return 999;
            };
            return getOrder(a.identifier) - getOrder(b.identifier);
          });

          console.log(
            "📦 Loaded custom packages:",
            sortedPackages.map((p) => p.identifier),
          );
          setPackages(sortedPackages);
        }
      } catch (e) {
        console.error("Failed to load packages", e);
        setPackages([]);
      }
    };

    loadPackages();
  }, [rcReady]);

  // Fetch current customer info (entitlements)
  const customerInfoQuery = useQuery({
    queryKey: ["revenuecat", "customerInfo", user?.id],
    queryFn: async () => {
      if (!rcReady) throw new Error("RevenueCat not ready");
      const info = await Purchases.getCustomerInfo();
      return info;
    },
    enabled: !!user?.id && rcReady,
    retry: 1,
  });

  // Determine current plan from entitlements
  const currentPlan = useMemo(() => {
    const active = customerInfoQuery.data?.entitlements?.active || {};
    if (active.pro) return "pro";
    if (active.plus) return "plus";
    if (active.standard) return "standard";
    return null;
  }, [customerInfoQuery.data]);

  // Sync plan to backend
  const syncMutation = useMutation({
    mutationFn: async (plan) => {
      const body = { planType: plan };
      return fetchWithAuth("/api/subscriptions/revenuecat-sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["revenuecat", "customerInfo", user?.id],
      });
      Alert.alert("Success", "Your subscription is active.");
    },
    onError: (e) => {
      console.error("Failed to sync subscription", e);
      Alert.alert(
        "Sync issue",
        "We updated your purchase, but couldn't sync with the server just yet. It will retry automatically.",
      );
    },
  });

  const getPlanInfo = (pkg) => {
    const identifier = pkg.identifier.toLowerCase();

    if (identifier.includes("standard")) {
      return {
        title: "Standard",
        subtitle: "1 Team",
        features: ["1 team", "Unlimited players per team", "Core features"],
        isRecommended: false,
      };
    }

    if (identifier.includes("plus")) {
      return {
        title: "Plus",
        subtitle: "Up to 3 Teams",
        features: [
          "Up to 3 teams",
          "Unlimited players per team",
          "Everything in Standard",
        ],
        isRecommended: true,
      };
    }

    if (identifier.includes("pro")) {
      return {
        title: "Pro",
        subtitle: "Unlimited Teams",
        features: [
          "Unlimited teams",
          "Unlimited players per team",
          "Advanced analytics",
          "Priority support",
        ],
        isRecommended: false,
      };
    }

    return {
      title: pkg.product.title.replace(/\s*\(.*?\)\s*/g, "").trim(),
      subtitle: "",
      features: [],
      isRecommended: false,
    };
  };

  const handlePurchase = useCallback(
    async (pkg) => {
      try {
        if (!rcReady) {
          Alert.alert(
            "In-app purchases not ready",
            "RevenueCat is not configured yet. Please try again later.",
          );
          return;
        }

        // Purchase the specific package
        const { customerInfo } = await Purchases.purchasePackage(pkg);

        // Determine which plan was purchased
        const active = customerInfo?.entitlements?.active || {};
        let plan = null;
        if (active.pro) plan = "pro";
        else if (active.plus) plan = "plus";
        else if (active.standard) plan = "standard";

        if (plan) {
          syncMutation.mutate(plan);
        } else {
          Alert.alert("Success", "Your subscription is now active!");
          queryClient.invalidateQueries({
            queryKey: ["revenuecat", "customerInfo", user?.id],
          });
        }
      } catch (e) {
        if (e.userCancelled) {
          console.log("User cancelled purchase");
          return;
        }
        console.error("Purchase error:", e);
        Alert.alert(
          "Purchase Error",
          e?.message || "Something went wrong. Please try again.",
        );
      }
    },
    [rcReady, syncMutation, queryClient, user?.id],
  );

  const handleCancelSubscription = useCallback(async () => {
    try {
      setCancelling(true);

      // Get customer info to access management URL
      const customerInfo = await Purchases.getCustomerInfo();
      const managementURL = customerInfo.managementURL;

      if (managementURL) {
        // Open the management URL for the user to cancel
        const supported = await Linking.canOpenURL(managementURL);
        if (supported) {
          await Linking.openURL(managementURL);
          setShowCancelModal(false);

          // Show info that they can cancel through the link
          Alert.alert(
            "Manage Subscription",
            "You'll be redirected to manage your subscription. You can cancel there and will have access until the end of your billing period.",
          );
        } else {
          Alert.alert("Error", "Unable to open subscription management page.");
        }
      } else {
        Alert.alert(
          "Error",
          "Unable to find subscription management URL. Please contact support.",
        );
      }
    } catch (error) {
      console.error("Cancel error:", error);
      Alert.alert(
        "Error",
        "Unable to access subscription management. Please try again or contact support.",
      );
    } finally {
      setCancelling(false);
    }
  }, []);

  const handleRestore = useCallback(async () => {
    try {
      const { customerInfo } = await Purchases.restorePurchases();
      const active = customerInfo?.entitlements?.active || {};
      let plan = null;
      if (active.pro) plan = "pro";
      else if (active.plus) plan = "plus";
      else if (active.standard) plan = "standard";

      if (plan) {
        syncMutation.mutate(plan);
      } else {
        Alert.alert(
          "No purchases found",
          "We didn't find any active subscriptions to restore.",
        );
      }
    } catch (e) {
      console.error("Restore error", e);
      Alert.alert(
        "Restore error",
        e?.message || "Unable to restore purchases.",
      );
    }
  }, [syncMutation]);

  const Feature = ({ children }) => (
    <View
      style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}
    >
      <Check size={16} color={colors.success} />
      <Text
        style={{
          marginLeft: 8,
          color: colors.mainText,
          fontFamily: "Inter_400Regular",
          fontSize: 14,
        }}
      >
        {children}
      </Text>
    </View>
  );

  const PlanCard = ({ pkg, isCurrent }) => {
    const planInfo = getPlanInfo(pkg);
    const price = pkg.product.priceString;
    const period =
      pkg.packageType === "MONTHLY"
        ? "month"
        : pkg.packageType === "ANNUAL"
          ? "year"
          : "period";

    // Determine if this is an upgrade or downgrade
    const planOrder = { standard: 1, plus: 2, pro: 3 };
    const currentPlanOrder = planOrder[currentPlan] || 0;
    const thisPlanOrder = planOrder[planInfo.title.toLowerCase()] || 0;
    const isUpgrade = thisPlanOrder > currentPlanOrder;

    return (
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 20,
          borderWidth: 2,
          borderColor: isCurrent ? colors.primary : colors.border,
          marginBottom: 16,
          position: "relative",
        }}
      >
        {isCurrent && (
          <View
            style={{
              position: "absolute",
              top: -12,
              left: 20,
              backgroundColor: colors.primary,
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 12,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Check size={12} color="white" style={{ marginRight: 4 }} />
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 11,
                color: "white",
                textTransform: "uppercase",
                letterSpacing: 0.5,
              }}
            >
              Current Plan
            </Text>
          </View>
        )}

        {planInfo.isRecommended && !isCurrent && (
          <View
            style={{
              position: "absolute",
              top: -12,
              right: 20,
              backgroundColor: colors.success,
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 12,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Zap size={12} color="white" style={{ marginRight: 4 }} />
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 11,
                color: "white",
                textTransform: "uppercase",
                letterSpacing: 0.5,
              }}
            >
              Recommended
            </Text>
          </View>
        )}

        <Text
          style={{
            fontFamily: "Inter_700Bold",
            fontSize: 24,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          {planInfo.title}
        </Text>

        {planInfo.subtitle && (
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 15,
              color: colors.secondaryText,
              marginBottom: 12,
            }}
          >
            {planInfo.subtitle}
          </Text>
        )}

        <View
          style={{
            flexDirection: "row",
            alignItems: "baseline",
            marginBottom: 16,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_700Bold",
              fontSize: 32,
              color: colors.primary,
            }}
          >
            {price}
          </Text>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.secondaryText,
              marginLeft: 4,
            }}
          >
            /{period}
          </Text>
        </View>

        {planInfo.features.map((feature, index) => (
          <Feature key={index}>{feature}</Feature>
        ))}

        {!isCurrent && (
          <TouchableOpacity
            onPress={() => handlePurchase(pkg)}
            style={{
              backgroundColor: colors.primary,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              marginTop: 12,
            }}
          >
            <Text
              style={{
                color: "white",
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
              }}
            >
              {isUpgrade ? "Upgrade" : "Select Plan"}
            </Text>
          </TouchableOpacity>
        )}

        {isCurrent && (
          <View style={{ marginTop: 12 }}>
            <View
              style={{
                backgroundColor: colors.primary + "15",
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Text
                style={{
                  color: colors.primary,
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                }}
              >
                Active Plan
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => setShowCancelModal(true)}
              style={{
                backgroundColor: "transparent",
                borderWidth: 1,
                borderColor: colors.alert,
                borderRadius: 12,
                paddingVertical: 12,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  color: colors.alert,
                  fontFamily: "Inter_500Medium",
                  fontSize: 15,
                }}
              >
                Cancel Subscription
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };

  const CancelConfirmationModal = () => (
    <Modal
      visible={showCancelModal}
      transparent
      animationType="fade"
      onRequestClose={() => setShowCancelModal(false)}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "center",
          alignItems: "center",
          padding: 20,
        }}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 20,
            padding: 24,
            width: "100%",
            maxWidth: 400,
          }}
        >
          <View
            style={{
              width: 60,
              height: 60,
              borderRadius: 30,
              backgroundColor: colors.alert + "20",
              alignItems: "center",
              justifyContent: "center",
              alignSelf: "center",
              marginBottom: 16,
            }}
          >
            <AlertTriangle size={32} color={colors.alert} />
          </View>

          <Text
            style={{
              fontFamily: "Inter_700Bold",
              fontSize: 20,
              color: colors.mainText,
              textAlign: "center",
              marginBottom: 12,
            }}
          >
            Cancel Subscription?
          </Text>

          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 15,
              color: colors.secondaryText,
              textAlign: "center",
              lineHeight: 22,
              marginBottom: 24,
            }}
          >
            You'll have access to your subscription until the end of your
            current billing period. After that, your plan will revert to the
            free tier.
          </Text>

          <TouchableOpacity
            onPress={handleCancelSubscription}
            disabled={cancelling}
            style={{
              backgroundColor: colors.alert,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              marginBottom: 12,
              opacity: cancelling ? 0.6 : 1,
            }}
          >
            {cancelling ? (
              <ActivityIndicator size="small" color="white" />
            ) : (
              <Text
                style={{
                  color: "white",
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                }}
              >
                Yes, Cancel Subscription
              </Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setShowCancelModal(false)}
            disabled={cancelling}
            style={{
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.border,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
            }}
          >
            <Text
              style={{
                color: colors.mainText,
                fontFamily: "Inter_500Medium",
                fontSize: 16,
              }}
            >
              Keep My Subscription
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  const isLoading = userLoading || customerInfoQuery.isLoading || !rcReady;

  // Redirect players to dashboard
  if (!isLoading && !isCoach) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            paddingTop: insets.top + 20,
            paddingHorizontal: 16,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 32,
            }}
          >
            <TouchableOpacity
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: colors.surface,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={() => router.back()}
            >
              <ArrowLeft size={20} color={colors.mainText} />
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
              }}
            >
              Subscriptions
            </Text>
            <View style={{ width: 40 }} />
          </View>

          <View
            style={{
              flex: 1,
              justifyContent: "center",
              alignItems: "center",
              paddingHorizontal: 32,
            }}
          >
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: colors.primary + "20",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 20,
              }}
            >
              <Info size={40} color={colors.primary} />
            </View>

            <Text
              style={{
                fontFamily: "Inter_700Bold",
                fontSize: 24,
                color: colors.mainText,
                textAlign: "center",
                marginBottom: 12,
              }}
            >
              Coach Access Only
            </Text>

            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.secondaryText,
                textAlign: "center",
                lineHeight: 24,
                marginBottom: 32,
              }}
            >
              Subscription management is only available for coaches. As a
              player, you have full access to your teams without needing a
              subscription.
            </Text>

            <TouchableOpacity
              onPress={() => router.back()}
              style={{
                backgroundColor: colors.primary,
                borderRadius: 12,
                paddingVertical: 14,
                paddingHorizontal: 32,
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                }}
              >
                Go Back
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScreenWrapper>
    );
  }

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: colors.surface,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.mainText} />
          </TouchableOpacity>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
            }}
          >
            Subscriptions
          </Text>
          <View style={{ width: 40 }} />
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Info banner if RC not configured */}
        {!rcReady && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
              borderRadius: 12,
              padding: 12,
              marginBottom: 16,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Info size={20} color={colors.secondaryText} />
            <Text
              style={{
                marginLeft: 8,
                color: colors.secondaryText,
                fontFamily: "Inter_400Regular",
                flex: 1,
              }}
            >
              RevenueCat isn't configured yet. Contact support to set up
              subscriptions.
            </Text>
          </View>
        )}

        {/* Current plan badge */}
        {currentPlan && (
          <View
            style={{
              backgroundColor: colors.primary + "15",
              borderRadius: 12,
              padding: 16,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: colors.primary + "30",
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.primary,
                marginBottom: 4,
              }}
            >
              Current Plan
            </Text>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {currentPlan.charAt(0).toUpperCase() + currentPlan.slice(1)}
            </Text>
          </View>
        )}

        {/* No active subscription warning */}
        {!currentPlan && !isLoading && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.alert,
              borderWidth: 1,
              borderRadius: 12,
              padding: 16,
              marginBottom: 16,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.alert,
                marginBottom: 4,
              }}
            >
              No Active Subscription
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              You need an active subscription to use the app. Choose a plan
              below.
            </Text>
          </View>
        )}

        {/* Loading state */}
        {isLoading && (
          <View style={{ marginTop: 40, alignItems: "center" }}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.secondaryText,
                marginTop: 16,
              }}
            >
              Loading plans...
            </Text>
          </View>
        )}

        {/* Plan cards from RevenueCat */}
        {!isLoading && packages.length > 0 && (
          <>
            {packages.map((pkg) => {
              const planInfo = getPlanInfo(pkg);
              const planKey = planInfo.title.toLowerCase();
              const isCurrent = currentPlan === planKey;

              return (
                <PlanCard
                  key={pkg.identifier}
                  pkg={pkg}
                  isCurrent={isCurrent}
                />
              );
            })}
          </>
        )}

        {/* No packages available */}
        {!isLoading && rcReady && packages.length === 0 && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 12,
              padding: 20,
              marginTop: 20,
              alignItems: "center",
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
                marginBottom: 8,
                textAlign: "center",
              }}
            >
              No Plans Available
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
                textAlign: "center",
              }}
            >
              Unable to load subscription plans. Please try again later or
              contact support.
            </Text>
          </View>
        )}

        {/* Restore purchases */}
        {rcReady && (
          <TouchableOpacity
            onPress={handleRestore}
            style={{ alignSelf: "center", marginTop: 16, marginBottom: 8 }}
          >
            <Text
              style={{
                color: colors.primary,
                fontFamily: "Inter_500Medium",
                fontSize: 15,
              }}
            >
              Restore purchases
            </Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      <CancelConfirmationModal />
    </ScreenWrapper>
  );
}
