import React from "react";
import { View, Text, ScrollView, Alert } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useFeedback } from "@/hooks/useFeedback";
import { useFeedbackSubmission } from "@/hooks/useFeedbackSubmission";
import { HelpSupportHeader } from "@/components/help-support/HelpSupportHeader";
import { FeedbackSection } from "@/components/help-support/FeedbackSection";
import { FeedbackModal } from "@/components/help-support/FeedbackModal";

export default function Feedback() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  const {
    feedbackList,
    loadingFeedback,
    selectedFilter,
    setSelectedFilter,
    filteredFeedback,
    handleVote,
    fetchFeedback,
  } = useFeedback();

  const {
    showAddModal,
    setShowAddModal,
    newFeedback,
    setNewFeedback,
    submitting,
    handleSubmitFeedback,
  } = useFeedbackSubmission(async () => {
    await fetchFeedback();
    Alert.alert("Success", "Thank you for your feedback!");
  });

  const handleVoteWithAlert = async (feedbackId) => {
    try {
      await handleVote(feedbackId);
    } catch (error) {
      Alert.alert("Error", "Failed to vote. Please try again.");
    }
  };

  const handleSubmitWithAlert = async () => {
    try {
      await handleSubmitFeedback();
    } catch (error) {
      Alert.alert(
        "Error",
        error.message || "Failed to submit feedback. Please try again.",
      );
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <ScreenWrapper>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
      >
        <HelpSupportHeader onBack={() => router.back()} />

        <Text
          style={{
            fontFamily: "Inter_700Bold",
            fontSize: 28,
            color: colors.mainText,
            marginBottom: 8,
          }}
        >
          Community Feedback
        </Text>

        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 15,
            color: colors.secondaryText,
            marginBottom: 24,
          }}
        >
          Share your ideas and vote on features you'd like to see
        </Text>

        <FeedbackSection
          feedbackList={feedbackList}
          loadingFeedback={loadingFeedback}
          selectedFilter={selectedFilter}
          setSelectedFilter={setSelectedFilter}
          filteredFeedback={filteredFeedback}
          onVote={handleVoteWithAlert}
          onAddFeedback={() => setShowAddModal(true)}
        />
      </ScrollView>

      <FeedbackModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        newFeedback={newFeedback}
        setNewFeedback={setNewFeedback}
        submitting={submitting}
        onSubmit={handleSubmitWithAlert}
      />
    </ScreenWrapper>
  );
}
