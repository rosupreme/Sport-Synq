import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { Image } from "expo-image";
import { Mail, Lock, Eye, EyeOff } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useAuth } from "@/utils/auth/useAuth";
import { fetchJson } from "@/utils/api";

export default function SignIn() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();
  // NOTE: stop using web modal for auth here; handle native email/password directly
  const { isReady, isAuthenticated, setAuth } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  useEffect(() => {
    if (isReady && isAuthenticated) {
      // Navigate to a concrete tab screen to avoid blank view
      router.replace("/(tabs)/dashboard");
    }
  }, [isReady, isAuthenticated, router]);

  if (!fontsLoaded) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: colors.background,
        }}
      >
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={{ marginTop: 12, color: colors.secondaryText }}>
          Loading…
        </Text>
      </View>
    );
  }

  const handleSignIn = async () => {
    // Native email/password sign in hitting our backend directly
    try {
      setLoading(true);
      setError("");
      if (!email || !password) {
        setError("Please enter your email and password");
        return;
      }

      const data = await fetchJson("/api/mobile-auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const { sessionToken, user } = data || {};
      if (!sessionToken) {
        throw new Error("Invalid response from server");
      }

      // Save auth locally so the rest of the app sees it
      setAuth({ sessionToken, user: user || null });

      // Go straight to dashboard
      router.replace("/(tabs)/dashboard");
    } catch (e) {
      console.error("Sign in error:", e);
      setError(e?.message || "Could not sign in. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <StatusBar style={isDark ? "light" : "dark"} />
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          flexGrow: 1,
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 24,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Logo and Header */}
        <View style={{ alignItems: "center", marginBottom: 48 }}>
          <Image
            source="https://ucarecdn.com/22980b5d-5d32-47b8-8fd4-84b718d6db46/-/format/auto/"
            style={{
              width: 80,
              height: 80,
              marginBottom: 24,
            }}
            contentFit="contain"
          />
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 28,
              color: colors.mainText,
              textAlign: "center",
              marginBottom: 8,
            }}
          >
            Welcome Back
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
            }}
          >
            Sign in to your Sport-Synq account
          </Text>
        </View>

        {/* Form */}
        <View style={{ flex: 1 }}>
          {/* Email Input */}
          <View style={{ marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Email Address
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                paddingHorizontal: 16,
                height: 56,
              }}
            >
              <Mail size={20} color={colors.secondaryText} />
              <TextInput
                style={{
                  flex: 1,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                  marginLeft: 12,
                }}
                placeholder="Enter your email"
                placeholderTextColor={colors.secondaryText}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
          </View>

          {/* Password Input */}
          <View style={{ marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Password
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                paddingHorizontal: 16,
                height: 56,
              }}
            >
              <Lock size={20} color={colors.secondaryText} />
              <TextInput
                style={{
                  flex: 1,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                  marginLeft: 12,
                }}
                placeholder="Enter your password"
                placeholderTextColor={colors.secondaryText}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <TouchableOpacity
                onPress={() => setShowPassword(!showPassword)}
                style={{ padding: 4 }}
              >
                {showPassword ? (
                  <EyeOff size={20} color={colors.secondaryText} />
                ) : (
                  <Eye size={20} color={colors.secondaryText} />
                )}
              </TouchableOpacity>
            </View>
          </View>

          {/* Forgot Password Link */}
          <View style={{ alignItems: "center", marginBottom: 16 }}>
            <TouchableOpacity
              onPress={() => router.push("/auth/forgot-password")}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 14,
                  color: colors.primary,
                }}
              >
                Forgot password?
              </Text>
            </TouchableOpacity>
          </View>

          {/* Error Message */}
          {error ? (
            <View
              style={{
                backgroundColor: colors.alert + "10",
                borderRadius: 12,
                padding: 16,
                marginBottom: 20,
                borderWidth: 1,
                borderColor: colors.alert + "20",
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.alert,
                  textAlign: "center",
                }}
              >
                {error}
              </Text>
            </View>
          ) : null}

          {/* Sign In Button */}
          <TouchableOpacity
            style={{
              backgroundColor: colors.primary,
              borderRadius: 12,
              height: 56,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 24,
              opacity: loading ? 0.7 : 1,
            }}
            onPress={handleSignIn}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator size="small" color="white" />
            ) : (
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                  color: "white",
                }}
              >
                Sign In
              </Text>
            )}
          </TouchableOpacity>

          {/* Sign Up Link */}
          <View style={{ alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
                textAlign: "center",
              }}
            >
              Don't have an account?{" "}
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 14,
                  color: colors.primary,
                }}
                onPress={() => router.replace("/auth/signup")}
              >
                Create one here
              </Text>
            </Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
