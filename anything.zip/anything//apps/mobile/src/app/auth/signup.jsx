import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { Image } from "expo-image";
import { Mail, Lock, Eye, EyeOff, User, Phone } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useAuth } from "@/utils/auth/useAuth";
import { fetchJson } from "@/utils/api";

export default function SignUp() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();
  // Switch to native signup using API; don't open web modal here
  const { isReady, isAuthenticated, setAuth } = useAuth();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  useEffect(() => {
    if (isReady && isAuthenticated) {
      router.replace("/onboarding/role-selection");
    }
  }, [isReady, isAuthenticated, router]);

  if (!fontsLoaded) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: colors.background,
        }}
      >
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={{ marginTop: 12, color: colors.secondaryText }}>
          Loading…
        </Text>
      </View>
    );
  }

  const handleSignUp = async () => {
    // Native sign up via API
    try {
      setLoading(true);
      setError("");
      if (!fullName || !email || !password) {
        setError("Please fill out name, email, and password");
        return;
      }
      if (password.length < 6) {
        setError("Password must be at least 6 characters");
        return;
      }
      if (password !== confirmPassword) {
        setError("Passwords do not match");
        return;
      }

      // CHANGE: use fetchJson with absolute API URL and safe parsing
      const data = await fetchJson("/api/mobile-auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: fullName, email, phone, password }),
      });

      const { sessionToken, user } = data || {};
      if (!sessionToken) {
        throw new Error("Invalid response from server");
      }

      // Save auth locally and go to onboarding
      setAuth({ sessionToken, user: user || null });
      router.replace("/onboarding/role-selection");
    } catch (e) {
      console.error("Sign up error:", e);
      setError(e?.message || "Could not create account. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <StatusBar style={isDark ? "light" : "dark"} />
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          flexGrow: 1,
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 24,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Logo and Header */}
        <View style={{ alignItems: "center", marginBottom: 48 }}>
          <Image
            source="https://ucarecdn.com/22980b5d-5d32-47b8-8fd4-84b718d6db46/-/format/auto/"
            style={{
              width: 80,
              height: 80,
              marginBottom: 24,
            }}
            contentFit="contain"
          />
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 28,
              color: colors.mainText,
              textAlign: "center",
              marginBottom: 8,
            }}
          >
            Join Sport-Synq
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
            }}
          >
            Create your team management account
          </Text>
        </View>

        {/* Form */}
        <View style={{ flex: 1 }}>
          {/* Full Name Input */}
          <View style={{ marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Full Name *
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                paddingHorizontal: 16,
                height: 56,
              }}
            >
              <User size={20} color={colors.secondaryText} />
              <TextInput
                style={{
                  flex: 1,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                  marginLeft: 12,
                }}
                placeholder="Enter your full name"
                placeholderTextColor={colors.secondaryText}
                value={fullName}
                onChangeText={setFullName}
                autoCapitalize="words"
                autoCorrect={false}
              />
            </View>
          </View>

          {/* Email Input */}
          <View style={{ marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Email Address *
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                paddingHorizontal: 16,
                height: 56,
              }}
            >
              <Mail size={20} color={colors.secondaryText} />
              <TextInput
                style={{
                  flex: 1,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                  marginLeft: 12,
                }}
                placeholder="Enter your email"
                placeholderTextColor={colors.secondaryText}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
          </View>

          {/* Phone Number Input */}
          <View style={{ marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Phone Number
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                paddingHorizontal: 16,
                height: 56,
              }}
            >
              <Phone size={20} color={colors.secondaryText} />
              <TextInput
                style={{
                  flex: 1,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                  marginLeft: 12,
                }}
                placeholder="Enter your phone number"
                placeholderTextColor={colors.secondaryText}
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
          </View>

          {/* Password Input */}
          <View style={{ marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Password *
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                paddingHorizontal: 16,
                height: 56,
              }}
            >
              <Lock size={20} color={colors.secondaryText} />
              <TextInput
                style={{
                  flex: 1,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                  marginLeft: 12,
                }}
                placeholder="Create a password (min. 6 characters)"
                placeholderTextColor={colors.secondaryText}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <TouchableOpacity
                onPress={() => setShowPassword(!showPassword)}
                style={{ padding: 4 }}
              >
                {showPassword ? (
                  <EyeOff size={20} color={colors.secondaryText} />
                ) : (
                  <Eye size={20} color={colors.secondaryText} />
                )}
              </TouchableOpacity>
            </View>
          </View>

          {/* Confirm Password Input */}
          <View style={{ marginBottom: 20 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Confirm Password *
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.border,
                paddingHorizontal: 16,
                height: 56,
              }}
            >
              <Lock size={20} color={colors.secondaryText} />
              <TextInput
                style={{
                  flex: 1,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                  marginLeft: 12,
                }}
                placeholder="Confirm your password"
                placeholderTextColor={colors.secondaryText}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry={!showConfirmPassword}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <TouchableOpacity
                onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                style={{ padding: 4 }}
              >
                {showConfirmPassword ? (
                  <EyeOff size={20} color={colors.secondaryText} />
                ) : (
                  <Eye size={20} color={colors.secondaryText} />
                )}
              </TouchableOpacity>
            </View>
          </View>

          {/* Error Message */}
          {error ? (
            <View
              style={{
                backgroundColor: colors.alert + "10",
                borderRadius: 12,
                padding: 16,
                marginBottom: 20,
                borderWidth: 1,
                borderColor: colors.alert + "20",
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.alert,
                  textAlign: "center",
                }}
              >
                {error}
              </Text>
            </View>
          ) : null}

          {/* Create Account Button */}
          <TouchableOpacity
            style={{
              backgroundColor: colors.primary,
              borderRadius: 12,
              height: 56,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 20,
              opacity: loading ? 0.7 : 1,
            }}
            onPress={handleSignUp}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator size="small" color="white" />
            ) : (
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                  color: "white",
                }}
              >
                Create Account
              </Text>
            )}
          </TouchableOpacity>

          {/* Terms */}
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 12,
              color: colors.secondaryText,
              textAlign: "center",
              marginBottom: 24,
            }}
          >
            By creating an account, you agree to our Terms of Service and
            Privacy Policy
          </Text>

          {/* Sign In Link */}
          <View style={{ alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
                textAlign: "center",
              }}
            >
              Already have an account?{" "}
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 14,
                  color: colors.primary,
                }}
                onPress={() => router.replace("/auth/signin")}
              >
                Sign in here
              </Text>
            </Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
