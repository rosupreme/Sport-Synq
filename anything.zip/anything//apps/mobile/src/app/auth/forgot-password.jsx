import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { Mail, ArrowLeft } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useMutation } from "@tanstack/react-query";

export default function ForgotPassword() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const canSubmit = useMemo(
    () => email.trim().length > 3 && email.includes("@"),
    [email],
  );

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/auth/password/forgot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(
          `When fetching /api/auth/password/forgot, the response was [${res.status}] ${res.statusText}. ${text}`,
        );
      }
      return res.json();
    },
    onSuccess: (data) => {
      setError("");
      Alert.alert(
        "Check your email",
        "If that email is registered, we've sent a reset link.",
        [
          {
            text: "OK",
            onPress: () => router.back(),
          },
        ],
      );
      if (data?.debugResetUrl) {
        console.log("Password reset URL (debug):", data.debugResetUrl);
      }
    },
    onError: (e) => {
      console.error(e);
      setError(e?.message || "Could not send reset email");
    },
  });

  if (!fontsLoaded) return null;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
          backgroundColor: colors.background,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 16,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 24,
                color: colors.mainText,
              }}
            >
              Forgot Password
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 20,
          paddingBottom: insets.bottom + 24,
        }}
        showsVerticalScrollIndicator={false}
      >
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 16,
            color: colors.secondaryText,
            marginBottom: 16,
          }}
        >
          Enter your account email and we'll send you a link to reset your
          password.
        </Text>

        {/* Email */}
        <View style={{ marginBottom: 16 }}>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            Email
          </Text>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: colors.surface,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: colors.border,
              paddingHorizontal: 16,
              height: 56,
            }}
          >
            <Mail size={20} color={colors.secondaryText} />
            <TextInput
              style={{
                flex: 1,
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.mainText,
                marginLeft: 12,
              }}
              placeholder="you@example.com"
              placeholderTextColor={colors.secondaryText}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              value={email}
              onChangeText={setEmail}
            />
          </View>
        </View>

        {error ? (
          <View
            style={{
              backgroundColor: colors.alert + "10",
              borderRadius: 12,
              padding: 12,
              marginBottom: 12,
              borderWidth: 1,
              borderColor: colors.alert + "20",
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.alert,
              }}
            >
              {error}
            </Text>
          </View>
        ) : null}

        {/* Submit */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.primary,
            borderRadius: 12,
            height: 56,
            alignItems: "center",
            justifyContent: "center",
            opacity: !canSubmit || mutation.isLoading ? 0.7 : 1,
          }}
          onPress={() => mutation.mutate()}
          disabled={!canSubmit || mutation.isLoading}
        >
          {mutation.isLoading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: "#fff",
              }}
            >
              Send reset link
            </Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
