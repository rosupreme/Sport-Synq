import { useAuth } from "@/utils/auth/useAuth";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "@/components/ThemeProvider";
import { LanguageProvider } from "@/components/LanguageProvider";
import { View, ActivityIndicator, Text, Platform, LogBox } from "react-native";
import { useColorScheme } from "react-native";
import Purchases, { LOG_LEVEL } from "react-native-purchases";

// Suppress React 19 ref warning from third-party packages
LogBox.ignoreLogs(["Accessing element.ref was removed in React 19"]);

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 30, // 30 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function RootLayout() {
  const { initiate, isReady } = useAuth();
  const scheme = useColorScheme();

  useEffect(() => {
    initiate();
  }, [initiate]);

  useEffect(() => {
    // Initialize RevenueCat
    const initializeRevenueCat = async () => {
      try {
        Purchases.setLogLevel(LOG_LEVEL.DEBUG);

        if (Platform.OS === "ios") {
          const apiKey = process.env.EXPO_PUBLIC_REVENUE_CAT_APP_STORE_API_KEY;
          if (apiKey) {
            await Purchases.configure({ apiKey });
            console.log("✅ RevenueCat configured for iOS");
          } else {
            console.warn("⚠️ RevenueCat iOS API key not found");
          }
        } else if (Platform.OS === "android") {
          const apiKey =
            process.env.EXPO_PUBLIC_REVENUE_CAT_PLAY_STORE_API_KEY_;
          if (apiKey) {
            await Purchases.configure({ apiKey });
            console.log("✅ RevenueCat configured for Android");
          } else {
            console.warn("⚠️ RevenueCat Android API key not found");
          }
        } else {
          // For web/testing, use test store API key
          const apiKey = process.env.EXPO_PUBLIC_REVENUE_CAT_TEST_STORE_API_KEY;
          if (apiKey) {
            await Purchases.configure({ apiKey });
            console.log("✅ RevenueCat configured for test environment");
          } else {
            console.warn("⚠️ RevenueCat test API key not found");
          }
        }
      } catch (error) {
        console.error("❌ Error initializing RevenueCat:", error);
      }
    };

    initializeRevenueCat();
  }, []);

  useEffect(() => {
    if (isReady) {
      SplashScreen.hideAsync();
    }
  }, [isReady]);

  if (!isReady) {
    const bg = scheme === "dark" ? "#121212" : "#FFFFFF";
    const spinner = scheme === "dark" ? "#FFFFFF" : "#111827";
    const text = scheme === "dark" ? "#B8B8B8" : "#6B7280";
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: bg,
        }}
      >
        <ActivityIndicator size="large" color={spinner} />
        <Text style={{ marginTop: 12, color: text }}>Preparing app…</Text>
      </View>
    );
  }

  return (
    <LanguageProvider>
      <ThemeProvider>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <Stack
              screenOptions={{ headerShown: false }}
              initialRouteName="index"
            >
              <Stack.Screen name="index" />
              <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
              <Stack.Screen name="event-details" />
              <Stack.Screen name="player-details" />
              <Stack.Screen name="add-event" />
              <Stack.Screen name="add-player" />
            </Stack>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ThemeProvider>
    </LanguageProvider>
  );
}
