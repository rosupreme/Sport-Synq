import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  Animated,
  Platform,
  Keyboard,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  ArrowLeft,
  Target,
  Calendar,
  DollarSign,
  FileText,
  Save,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import InputField from "@/components/add-event/InputField";
import PickerField from "@/components/add-event/PickerField";
import DatePickerModal from "@/components/add-event/DatePickerModal";
import { fetchWithAuth } from "@/utils/api";
import { useDashboardData } from "@/hooks/useDashboardData";

export default function AddFundraiser() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);

  // Selected team from shared dashboard hook
  const { selectedTeam } = useDashboardData();

  // Separate state variables for better text input handling
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [goalAmount, setGoalAmount] = useState("");
  const [startDate, setStartDate] = useState(
    new Date().toISOString().split("T")[0],
  );
  const [endDate, setEndDate] = useState("");

  // Date picker states
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  const handleStartDateSelect = (day) => {
    const selectedDate = day.dateString;
    setStartDate(selectedDate);
    setShowStartDatePicker(false);
  };

  const handleEndDateSelect = (day) => {
    const selectedDate = day.dateString;
    setEndDate(selectedDate);
    setShowEndDatePicker(false);
  };

  const formatDisplayDate = (dateString) => {
    if (!dateString) return "";

    // Parse the date as local time to avoid timezone shifts
    const [year, month, day] = dateString.split("-");
    const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));

    return date.toLocaleDateString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      Alert.alert(
        t("error"),
        t("enterFundraiserTitle") || "Please enter a fundraiser title",
      );
      return;
    }

    if (!goalAmount || parseInt(goalAmount) <= 0) {
      Alert.alert(
        t("error"),
        t("enterValidGoal") || "Please enter a valid goal amount",
      );
      return;
    }

    if (!endDate) {
      Alert.alert(
        t("error"),
        t("selectEndDate") || "Please select an end date",
      );
      return;
    }

    // Validate end date is after start date
    if (new Date(endDate) <= new Date(startDate)) {
      Alert.alert(
        t("error"),
        t("endDateAfterStart") || "End date must be after start date",
      );
      return;
    }

    // Team is required so fundraisers don't overlap across teams
    if (!selectedTeam?.id) {
      Alert.alert(t("selectTeam"), t("chooseTeam"));
      return;
    }

    setLoading(true);

    try {
      const data = await fetchWithAuth("/api/fundraisers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          description,
          goal_amount: parseInt(goalAmount),
          start_date: startDate,
          end_date: endDate,
          team_id: selectedTeam.id,
        }),
      });

      Alert.alert(t("success"), t("fundraiserCreated"), [
        {
          text: t("ok"),
          onPress: () => router.back(),
        },
      ]);
    } catch (error) {
      console.error("Error creating fundraiser:", error);
      const message =
        error?.data?.error ||
        error?.message ||
        t("failedCreateFundraiser") ||
        "Failed to create fundraiser";
      Alert.alert(t("error"), message);
    } finally {
      setLoading(false);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <View style={{ flex: 1, paddingTop: insets.top }}>
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: colors.border,
            }}
          >
            <TouchableOpacity
              onPress={() => router.back()}
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: colors.surface,
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <ArrowLeft size={20} color={colors.mainText} />
            </TouchableOpacity>

            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 18,
                  color: colors.mainText,
                }}
              >
                {t("createFundraiser") || "Create Fundraiser"}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.secondaryText,
                }}
              >
                {t("setUpFundraisingGoal") || "Set up a new fundraising goal"}
              </Text>
            </View>
          </View>

          {/* Form */}
          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{
              padding: 16,
              paddingBottom: insets.bottom + 20,
            }}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <InputField
              label={t("fundraiserTitle") || "Fundraiser Title"}
              value={title}
              onChangeText={setTitle}
              placeholder={
                t("fundraiserTitlePlaceholder") || "e.g. New Team Uniforms"
              }
              icon={Target}
            />

            <InputField
              label={t("description")}
              value={description}
              onChangeText={setDescription}
              placeholder={
                t("describeWhatRaisingFor") ||
                "Describe what you're raising money for..."
              }
              icon={FileText}
              multiline={true}
            />

            <InputField
              label={t("goalAmount")}
              value={goalAmount}
              onChangeText={setGoalAmount}
              placeholder="1000"
              icon={DollarSign}
              keyboardType="numeric"
            />

            <PickerField
              label={t("startDate")}
              placeholder={t("selectStartDate") || "Select start date"}
              value={formatDisplayDate(startDate)}
              onPress={() => setShowStartDatePicker(true)}
              icon={Calendar}
            />

            <PickerField
              label={t("endDate")}
              placeholder={t("selectEndDate") || "Select end date"}
              value={formatDisplayDate(endDate)}
              onPress={() => setShowEndDatePicker(true)}
              icon={Calendar}
            />

            {/* Submit Button */}
            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 16,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                marginTop: 20,
                opacity: loading ? 0.7 : 1,
              }}
              onPress={handleSubmit}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <>
                  <Save size={20} color="white" />
                  <Text
                    style={{
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 16,
                      color: "white",
                      marginLeft: 8,
                    }}
                  >
                    {t("createFundraiser") || "Create Fundraiser"}
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </ScrollView>

          {/* Date Picker Modals */}
          <DatePickerModal
            visible={showStartDatePicker}
            onClose={() => setShowStartDatePicker(false)}
            onDayPress={handleStartDateSelect}
            selectedDate={startDate}
          />

          <DatePickerModal
            visible={showEndDatePicker}
            onClose={() => setShowEndDatePicker(false)}
            onDayPress={handleEndDateSelect}
            selectedDate={endDate}
          />
        </View>
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
