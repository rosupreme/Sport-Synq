import React, { useState } from "react";
import { View, Text, TouchableOpacity, Share } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft, Users, Copy, Check, Share2 } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import * as Clipboard from "expo-clipboard";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { fetchWithAuth } from "@/utils/api";

export default function AddPlayer() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const [teams, setTeams] = useState([]);
  const [selectedTeamId, setSelectedTeamId] = useState(null);
  const [loadingTeams, setLoadingTeams] = useState(true);
  const [teamCode, setTeamCode] = useState("");
  const [teamName, setTeamName] = useState("");
  const [copiedCode, setCopiedCode] = useState(false);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  // Fetch user's teams on component mount
  React.useEffect(() => {
    const fetchTeams = async () => {
      try {
        const data = await fetchWithAuth("/api/teams");
        const list = data.teams || [];
        setTeams(list);

        // Try to honor the globally selected team if available
        const savedTeamId = await AsyncStorage.getItem("selected_team_id");
        const initial = savedTeamId
          ? list.find((t) => String(t.id) === String(savedTeamId))
          : list[0];
        if (initial) {
          setSelectedTeamId(initial.id);
          setTeamCode(initial.invite_code || "");
          setTeamName(initial.name || "");
        }
      } catch (error) {
        console.error("Error fetching teams:", error);
      } finally {
        setLoadingTeams(false);
      }
    };

    fetchTeams();
  }, []);

  // Update code when selection changes
  React.useEffect(() => {
    const team = teams.find((t) => t.id === selectedTeamId);
    setTeamCode(team?.invite_code || "");
    setTeamName(team?.name || "");
  }, [selectedTeamId, teams]);

  if (!fontsLoaded) {
    return null;
  }

  const handleCopyCode = async () => {
    await Clipboard.setStringAsync(teamCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `${t("joinOurTeam") || "Join our team"}! ${t("useCode") || "Use code"}: ${teamCode}\n\n${t("openAppEnterCode") || "Download the app and enter this code to join"} ${teamName}.`,
        title: t("joinOurTeam") || "Join Our Team",
      });
    } catch (error) {
      console.error("Error sharing:", error);
    }
  };

  // Show loading state while teams are being fetched
  if (loadingTeams) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
            }}
          >
            {t("loadingTeams") || "Loading teams..."}
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  // Show message if no teams are available
  if (teams.length === 0) {
    return (
      <ScreenWrapper>
        <View
          style={{
            paddingTop: insets.top + 20,
            paddingHorizontal: 16,
            paddingBottom: 16,
            borderBottomWidth: 1,
            borderBottomColor: colors.border,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <TouchableOpacity
              style={{
                width: 40,
                height: 40,
                backgroundColor: colors.lavender,
                borderRadius: 20,
                alignItems: "center",
                justifyContent: "center",
              }}
              onPress={() => router.back()}
            >
              <ArrowLeft size={20} color={colors.primary} />
            </TouchableOpacity>

            <View style={{ flex: 1, alignItems: "center" }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 18,
                  color: colors.mainText,
                }}
              >
                {t("addPlayer") || "Add Player"}
              </Text>
            </View>

            <View style={{ width: 40 }} />
          </View>
        </View>

        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingHorizontal: 32,
          }}
        >
          <Users size={48} color={colors.secondaryText} />
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
              marginTop: 16,
              marginBottom: 8,
              textAlign: "center",
            }}
          >
            {t("noTeamsAvailable") || "No Teams Available"}
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
              textAlign: "center",
              lineHeight: 20,
            }}
          >
            {t("createTeamFirst") ||
              "You need to create a team first before adding players."}
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1, alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
              }}
            >
              {t("addPlayer") || "Add Player"}
            </Text>
          </View>

          <View style={{ width: 40 }} />
        </View>
      </View>

      {/* Content */}
      <View
        style={{
          flex: 1,
          paddingHorizontal: 16,
          justifyContent: "center",
        }}
      >
        {/* Icon and Title */}
        <View style={{ alignItems: "center", marginBottom: 32 }}>
          <View
            style={{
              width: 80,
              height: 80,
              backgroundColor: colors.primary + "20",
              borderRadius: 40,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 20,
            }}
          >
            <Users size={40} color={colors.primary} />
          </View>

          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: colors.mainText,
              marginBottom: 8,
              textAlign: "center",
            }}
          >
            {t("invitePlayersToJoin") || "Invite Players to Join"}
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
              lineHeight: 24,
              paddingHorizontal: 16,
            }}
          >
            {t("shareTeamCodeDescription") ||
              `Share your team code with players so they can join ${teamName}`}
          </Text>
        </View>

        {/* Team Code Card */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 24,
            borderWidth: 1,
            borderColor: colors.border,
            alignItems: "center",
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.secondaryText,
              marginBottom: 8,
              textTransform: "uppercase",
              letterSpacing: 1,
            }}
          >
            {t("teamCode") || "Team Code"}
          </Text>

          <View
            style={{
              backgroundColor: colors.primary + "10",
              borderRadius: 12,
              paddingHorizontal: 24,
              paddingVertical: 14,
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 32,
                color: colors.primary,
                letterSpacing: 4,
              }}
            >
              {teamCode}
            </Text>
          </View>

          <View style={{ flexDirection: "row", gap: 12 }}>
            <TouchableOpacity
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.primary,
                borderRadius: 12,
                paddingHorizontal: 20,
                paddingVertical: 12,
              }}
              onPress={handleCopyCode}
            >
              {copiedCode ? (
                <Check size={18} color="white" style={{ marginRight: 8 }} />
              ) : (
                <Copy size={18} color="white" style={{ marginRight: 8 }} />
              )}
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: "white",
                }}
              >
                {copiedCode
                  ? t("copied") || "Copied!"
                  : t("copyCode") || "Copy Code"}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.surface,
                borderRadius: 12,
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={handleShare}
            >
              <Share2
                size={18}
                color={colors.mainText}
                style={{ marginRight: 8 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                }}
              >
                {t("share") || "Share"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScreenWrapper>
  );
}
