import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  ArrowLeft,
  User,
  DollarSign,
  Calendar,
  FileText,
  ChevronDown,
  CreditCard,
  Target,
  Users,
  Hash,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";

export default function AddPayment() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();
  const [isLoading, setIsLoading] = useState(false);

  // Form state
  const [paymentData, setPaymentData] = useState({
    playerId: "",
    playerName: "",
    type: "",
    amount: "",
    description: "",
    dueDate: "",
    notes: "",
  });

  // Picker states
  const [showPlayerPicker, setShowPlayerPicker] = useState(false);
  const [showTypePicker, setShowTypePicker] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  // Mock player data
  const mockPlayers = [
    { id: "1", name: "Sarah Johnson", jerseyNumber: 10 },
    { id: "2", name: "Mike Chen", jerseyNumber: 7 },
    { id: "3", name: "Emily Davis", jerseyNumber: 4 },
    { id: "4", name: "James Wilson", jerseyNumber: 1 },
    { id: "5", name: "Alex Rodriguez", jerseyNumber: 15 },
    { id: "6", name: "Jessica Brown", jerseyNumber: 8 },
  ];

  // Stabilized update functions using useCallback
  const updatePaymentData = useCallback((field, value) => {
    setPaymentData((prev) => ({ ...prev, [field]: value }));
  }, []);

  const handleAmountChange = useCallback(
    (value) => {
      // Remove non-numeric characters except decimal point
      const cleaned = value.replace(/[^0-9.]/g, "");
      // Ensure only one decimal point
      const parts = cleaned.split(".");
      if (parts.length > 2) {
        const formatted = parts[0] + "." + parts.slice(1).join("");
        updatePaymentData("amount", formatted);
      } else {
        updatePaymentData("amount", cleaned);
      }
    },
    [updatePaymentData],
  );

  const handleDescriptionChange = useCallback(
    (value) => {
      updatePaymentData("description", value);
    },
    [updatePaymentData],
  );

  const handleNotesChange = useCallback(
    (value) => {
      updatePaymentData("notes", value);
    },
    [updatePaymentData],
  );

  const handlePlayerChange = useCallback(
    (player) => {
      updatePaymentData("playerId", player.id);
      updatePaymentData("playerName", player.name);
      setShowPlayerPicker(false);
    },
    [updatePaymentData],
  );

  const handleTypeChange = useCallback(
    (type) => {
      updatePaymentData("type", type.value);
      setShowTypePicker(false);
    },
    [updatePaymentData],
  );

  if (!fontsLoaded) {
    return null;
  }

  const paymentTypes = [
    {
      value: "dues",
      label: "Monthly Dues",
      color: colors.primary,
      icon: CreditCard,
      description: "Regular monthly team dues",
    },
    {
      value: "fundraising",
      label: "Fundraising",
      color: colors.success,
      icon: Target,
      description: "Team fundraising contribution",
    },
    {
      value: "tournament",
      label: "Tournament Fee",
      color: colors.warning,
      icon: Calendar,
      description: "Tournament registration fee",
    },
    {
      value: "equipment",
      label: "Equipment",
      color: colors.secondary,
      icon: Users,
      description: "Team equipment purchase",
    },
    {
      value: "other",
      label: "Other",
      color: colors.secondaryText,
      icon: FileText,
      description: "Other payment type",
    },
  ];

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const generateDueDate = () => {
    const today = new Date();
    const nextMonth = new Date(
      today.getFullYear(),
      today.getMonth() + 1,
      today.getDate(),
    );
    return nextMonth.toISOString().split("T")[0];
  };

  const handleSavePayment = async () => {
    // Validate required fields
    if (!paymentData.playerId.trim()) {
      Alert.alert("Error", "Please select a player");
      return;
    }
    if (!paymentData.type.trim()) {
      Alert.alert("Error", "Please select a payment type");
      return;
    }
    if (!paymentData.amount.trim()) {
      Alert.alert("Error", "Please enter an amount");
      return;
    }
    if (!paymentData.description.trim()) {
      Alert.alert("Error", "Please enter a description");
      return;
    }

    setIsLoading(true);

    try {
      // Here you would typically save to your backend
      console.log("Saving payment:", paymentData);

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      Alert.alert("Success", "Payment added successfully!", [
        {
          text: "OK",
          onPress: () => router.back(),
        },
      ]);
    } catch (error) {
      console.error("Error saving payment:", error);
      Alert.alert("Error", "Failed to add payment. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const InputField = ({
    label,
    placeholder,
    value,
    onChangeText,
    icon: Icon,
    multiline = false,
    keyboardType = "default",
    required = false,
    prefix = "",
    ...props
  }) => (
    <View style={{ marginBottom: 20 }}>
      <View
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}
      >
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 14,
            color: colors.mainText,
          }}
        >
          {label}
        </Text>
        {required && (
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.error,
              marginLeft: 4,
            }}
          >
            *
          </Text>
        )}
      </View>
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          flexDirection: "row",
          alignItems: multiline ? "flex-start" : "center",
          paddingHorizontal: 16,
          paddingVertical: multiline ? 16 : 14,
        }}
      >
        {Icon && (
          <Icon
            size={20}
            color={colors.secondaryText}
            style={{ marginRight: 12, marginTop: multiline ? 2 : 0 }}
          />
        )}
        {prefix && (
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 15,
              color: colors.secondaryText,
              marginRight: 4,
            }}
          >
            {prefix}
          </Text>
        )}
        <TextInput
          placeholder={placeholder}
          placeholderTextColor={colors.secondaryText}
          value={value}
          onChangeText={onChangeText}
          multiline={multiline}
          keyboardType={keyboardType}
          style={{
            flex: 1,
            fontFamily: "Inter_400Regular",
            fontSize: 15,
            color: colors.mainText,
            minHeight: multiline ? 80 : 20,
            textAlignVertical: multiline ? "top" : "center",
          }}
          {...props}
        />
      </View>
    </View>
  );

  const PickerField = ({
    label,
    placeholder,
    value,
    onPress,
    icon: Icon,
    required = false,
  }) => (
    <View style={{ marginBottom: 20 }}>
      <View
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}
      >
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 14,
            color: colors.mainText,
          }}
        >
          {label}
        </Text>
        {required && (
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.error,
              marginLeft: 4,
            }}
          >
            *
          </Text>
        )}
      </View>
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 14,
        }}
        onPress={onPress}
      >
        {Icon && (
          <Icon
            size={20}
            color={colors.secondaryText}
            style={{ marginRight: 12 }}
          />
        )}
        <Text
          style={{
            flex: 1,
            fontFamily: "Inter_400Regular",
            fontSize: 15,
            color: value ? colors.mainText : colors.secondaryText,
          }}
        >
          {value || placeholder}
        </Text>
        <ChevronDown size={20} color={colors.secondaryText} />
      </TouchableOpacity>
    </View>
  );

  const PlayerPickerModal = () => (
    <Modal
      visible={showPlayerPicker}
      transparent={true}
      animationType="slide"
      onRequestClose={() => setShowPlayerPicker(false)}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingBottom: insets.bottom + 20,
            maxHeight: "70%",
          }}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: colors.border,
            }}
          >
            <TouchableOpacity onPress={() => setShowPlayerPicker(false)}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.secondaryText,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 17,
                color: colors.mainText,
              }}
            >
              Select Player
            </Text>
            <View style={{ width: 60 }} />
          </View>

          {/* Player Options */}
          <ScrollView style={{ paddingHorizontal: 20, paddingTop: 20 }}>
            {mockPlayers.map((player) => (
              <TouchableOpacity
                key={player.id}
                style={{
                  backgroundColor: colors.background,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor:
                    paymentData.playerId === player.id
                      ? colors.primary
                      : colors.border,
                  flexDirection: "row",
                  alignItems: "center",
                }}
                onPress={() => handlePlayerChange(player)}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    backgroundColor: colors.primary + "20",
                    borderRadius: 20,
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <User size={20} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 16,
                      color:
                        paymentData.playerId === player.id
                          ? colors.primary
                          : colors.mainText,
                    }}
                  >
                    {player.name}
                  </Text>
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 14,
                      color: colors.secondaryText,
                    }}
                  >
                    Jersey #{player.jerseyNumber}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  const TypePickerModal = () => (
    <Modal
      visible={showTypePicker}
      transparent={true}
      animationType="slide"
      onRequestClose={() => setShowTypePicker(false)}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingBottom: insets.bottom + 20,
          }}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: colors.border,
            }}
          >
            <TouchableOpacity onPress={() => setShowTypePicker(false)}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.secondaryText,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 17,
                color: colors.mainText,
              }}
            >
              Payment Type
            </Text>
            <View style={{ width: 60 }} />
          </View>

          {/* Type Options */}
          <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
            {paymentTypes.map((type) => (
              <TouchableOpacity
                key={type.value}
                style={{
                  backgroundColor: colors.background,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor:
                    paymentData.type === type.value
                      ? type.color
                      : colors.border,
                  flexDirection: "row",
                  alignItems: "center",
                }}
                onPress={() => handleTypeChange(type)}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    backgroundColor: type.color + "20",
                    borderRadius: 20,
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <type.icon size={20} color={type.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 16,
                      color:
                        paymentData.type === type.value
                          ? type.color
                          : colors.mainText,
                      marginBottom: 2,
                    }}
                  >
                    {type.label}
                  </Text>
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 12,
                      color: colors.secondaryText,
                    }}
                  >
                    {type.description}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>
    </Modal>
  );

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1, alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
              }}
            >
              Add Payment
            </Text>
          </View>

          <TouchableOpacity
            style={{
              backgroundColor: colors.primary,
              borderRadius: 20,
              paddingHorizontal: 16,
              paddingVertical: 10,
              opacity: isLoading ? 0.6 : 1,
            }}
            onPress={handleSavePayment}
            disabled={isLoading}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: "white",
              }}
            >
              {isLoading ? "Saving..." : "Save"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Form Content */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Player & Type Section */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            Payment Details
          </Text>

          <PickerField
            label="Player"
            placeholder="Select player"
            value={paymentData.playerName}
            onPress={() => setShowPlayerPicker(true)}
            icon={User}
            required={true}
          />

          <PickerField
            label="Payment Type"
            placeholder="Select payment type"
            value={
              paymentTypes.find((t) => t.value === paymentData.type)?.label
            }
            onPress={() => setShowTypePicker(true)}
            icon={CreditCard}
            required={true}
          />

          <InputField
            label="Amount"
            placeholder="0.00"
            value={paymentData.amount}
            onChangeText={handleAmountChange}
            icon={DollarSign}
            keyboardType="decimal-pad"
            required={true}
            prefix="$"
          />

          <InputField
            label="Description"
            placeholder="Enter payment description"
            value={paymentData.description}
            onChangeText={handleDescriptionChange}
            icon={FileText}
            required={true}
          />
        </View>

        {/* Additional Information Section */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            Additional Information
          </Text>

          <InputField
            label="Notes"
            placeholder="Add any additional notes..."
            value={paymentData.notes}
            onChangeText={handleNotesChange}
            icon={FileText}
            multiline={true}
          />
        </View>

        {/* Preview Card */}
        {paymentData.playerName && paymentData.type && paymentData.amount && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.border,
              marginTop: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.secondaryText,
                marginBottom: 12,
              }}
            >
              Payment Preview
            </Text>

            <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  backgroundColor: colors.primary + "20",
                  borderRadius: 24,
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 12,
                }}
              >
                <User size={24} color={colors.primary} />
              </View>

              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 16,
                    color: colors.mainText,
                    marginBottom: 4,
                  }}
                >
                  {paymentData.playerName}
                </Text>

                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 14,
                    color: colors.secondaryText,
                    marginBottom: 8,
                  }}
                >
                  {paymentData.description}
                </Text>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginBottom: 4,
                  }}
                >
                  {(() => {
                    const selectedType = paymentTypes.find(
                      (t) => t.value === paymentData.type,
                    );
                    const TypeIcon = selectedType?.icon || CreditCard;
                    return <TypeIcon size={14} color={colors.secondaryText} />;
                  })()}
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 12,
                      color: colors.secondaryText,
                      marginLeft: 6,
                      textTransform: "capitalize",
                    }}
                  >
                    {
                      paymentTypes.find((t) => t.value === paymentData.type)
                        ?.label
                    }
                  </Text>
                </View>

                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <DollarSign size={14} color={colors.success} />
                  <Text
                    style={{
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 18,
                      color: colors.success,
                      marginLeft: 4,
                    }}
                  >
                    ${paymentData.amount}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}
      </ScrollView>

      <PlayerPickerModal />
      <TypePickerModal />
    </ScreenWrapper>
  );
}
