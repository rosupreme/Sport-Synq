import React, { useMemo, useState, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft, Lock, Eye, EyeOff } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import { useMutation } from "@tanstack/react-query";
import { fetchJson } from "@/utils/api";

export default function ChangePassword() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState("");

  const canSubmit = useMemo(() => {
    return (
      currentPassword.trim().length > 0 &&
      newPassword.trim().length >= 8 &&
      confirmPassword.trim().length >= 8 &&
      newPassword === confirmPassword
    );
  }, [currentPassword, newPassword, confirmPassword]);

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await fetchJson("/api/user/change-password", {
        method: "POST",
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      return res;
    },
    onSuccess: () => {
      Alert.alert(
        t("success") || "Success",
        t("passwordChanged") || "Your password has been updated.",
        [
          {
            text: t("ok") || "OK",
            onPress: () => router.back(),
          },
        ],
      );
      setError("");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    },
    onError: (e) => {
      console.error("Change password error:", e);
      setError(
        e?.message || t("somethingWentWrong") || "Could not change password.",
      );
    },
  });

  const handleSubmit = useCallback(() => {
    if (!canSubmit) {
      const msg =
        newPassword !== confirmPassword
          ? t("passwordsDoNotMatch") || "Passwords do not match."
          : (newPassword?.length || 0) < 8
            ? t("passwordTooShort") ||
              "New password must be at least 8 characters."
            : t("fillAllFields") || "Please fill all fields.";
      setError(msg);
      return;
    }
    setError("");
    mutation.mutate();
  }, [canSubmit, mutation, newPassword, confirmPassword, t]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
          backgroundColor: colors.background,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 16,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 24,
                color: colors.mainText,
              }}
            >
              {t("changePassword") || "Change Password"}
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1, backgroundColor: colors.background }}
        contentContainerStyle={{
          paddingTop: 20,
          paddingBottom: insets.bottom + 40,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Current Password */}
        <View style={{ marginBottom: 16 }}>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            {t("currentPassword") || "Current Password"}
          </Text>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: colors.surface,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: colors.border,
              paddingHorizontal: 16,
              height: 56,
            }}
          >
            <Lock size={20} color={colors.secondaryText} />
            <TextInput
              style={{
                flex: 1,
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.mainText,
                marginLeft: 12,
              }}
              placeholder={
                t("enterCurrentPassword") || "Enter your current password"
              }
              placeholderTextColor={colors.secondaryText}
              value={currentPassword}
              onChangeText={setCurrentPassword}
              secureTextEntry={!showCurrent}
              autoCapitalize="none"
            />
            <TouchableOpacity
              onPress={() => setShowCurrent((s) => !s)}
              style={{ padding: 4 }}
            >
              {showCurrent ? (
                <EyeOff size={20} color={colors.secondaryText} />
              ) : (
                <Eye size={20} color={colors.secondaryText} />
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* New Password */}
        <View style={{ marginBottom: 16 }}>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            {t("newPassword") || "New Password"}
          </Text>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: colors.surface,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: colors.border,
              paddingHorizontal: 16,
              height: 56,
            }}
          >
            <Lock size={20} color={colors.secondaryText} />
            <TextInput
              style={{
                flex: 1,
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.mainText,
                marginLeft: 12,
              }}
              placeholder={
                t("enterNewPassword") ||
                "Enter a new password (min 8 characters)"
              }
              placeholderTextColor={colors.secondaryText}
              value={newPassword}
              onChangeText={setNewPassword}
              secureTextEntry={!showNew}
              autoCapitalize="none"
            />
            <TouchableOpacity
              onPress={() => setShowNew((s) => !s)}
              style={{ padding: 4 }}
            >
              {showNew ? (
                <EyeOff size={20} color={colors.secondaryText} />
              ) : (
                <Eye size={20} color={colors.secondaryText} />
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* Confirm Password */}
        <View style={{ marginBottom: 12 }}>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            {t("confirmNewPassword") || "Confirm New Password"}
          </Text>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: colors.surface,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: colors.border,
              paddingHorizontal: 16,
              height: 56,
            }}
          >
            <Lock size={20} color={colors.secondaryText} />
            <TextInput
              style={{
                flex: 1,
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.mainText,
                marginLeft: 12,
              }}
              placeholder={
                t("reenterNewPassword") || "Re-enter the new password"
              }
              placeholderTextColor={colors.secondaryText}
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry={!showConfirm}
              autoCapitalize="none"
            />
            <TouchableOpacity
              onPress={() => setShowConfirm((s) => !s)}
              style={{ padding: 4 }}
            >
              {showConfirm ? (
                <EyeOff size={20} color={colors.secondaryText} />
              ) : (
                <Eye size={20} color={colors.secondaryText} />
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* Helper + Errors */}
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 12,
            color: colors.secondaryText,
            marginBottom: 12,
          }}
        >
          {t("passwordRequirements") ||
            "Use at least 8 characters. Consider a mix of letters, numbers, and symbols."}
        </Text>
        {error ? (
          <View
            style={{
              backgroundColor: colors.alert + "10",
              borderRadius: 12,
              padding: 12,
              marginBottom: 12,
              borderWidth: 1,
              borderColor: colors.alert + "20",
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.alert,
              }}
            >
              {error}
            </Text>
          </View>
        ) : null}

        {/* Submit */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.primary,
            borderRadius: 12,
            height: 56,
            alignItems: "center",
            justifyContent: "center",
            opacity: !canSubmit || mutation.isLoading ? 0.7 : 1,
          }}
          onPress={handleSubmit}
          disabled={!canSubmit || mutation.isLoading}
        >
          {mutation.isLoading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: "#fff",
              }}
            >
              {t("save") || "Save"}
            </Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingAnimatedView>
  );
}
