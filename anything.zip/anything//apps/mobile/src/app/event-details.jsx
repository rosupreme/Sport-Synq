import React, { useState, useEffect, useMemo } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  Share,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import {
  ArrowLeft,
  Calendar,
  Clock,
  MapPin,
  Users,
  FileText,
  Edit3,
  Share2,
  Trash2,
  CheckCircle,
  XCircle,
  User,
  MessageCircle,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useUser } from "@/utils/auth/useUser";
import { useDashboardData } from "@/hooks/useDashboardData";
import useEventAttendance from "@/hooks/useEventAttendance";
import { fetchWithAuth } from "@/utils/api";
import { DeviceEventEmitter } from "react-native";

export default function EventDetails() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();
  const { id } = useLocalSearchParams();
  const [isLoading, setIsLoading] = useState(true);
  const [event, setEvent] = useState(null);
  const { data: user } = useUser();
  const { selectedTeam } = useDashboardData();

  // New: attendance query for this event
  const {
    data: attendanceData,
    isLoading: attendanceLoading,
    error: attendanceError,
    rsvp,
  } = useEventAttendance(id);

  // Derive role flags
  const isCoach = useMemo(
    () =>
      (selectedTeam?.user_role || "").toLowerCase() === "coach" ||
      selectedTeam?.is_owner === true,
    [selectedTeam?.user_role, selectedTeam?.is_owner],
  );
  const isPlayer = useMemo(
    () => (selectedTeam?.user_role || "").toLowerCase() === "player",
    [selectedTeam?.user_role],
  );

  // Derive current user's RSVP from attendanceData
  const currentUserStatus = useMemo(() => {
    if (!attendanceData || !user?.id) return null;
    const uid = String(user.id);
    if (
      (attendanceData.attendees?.going || []).some((u) => String(u.id) === uid)
    )
      return "going";
    if (
      (attendanceData.attendees?.not_going || []).some(
        (u) => String(u.id) === uid,
      )
    )
      return "not_going";
    if (
      (attendanceData.attendees?.maybe || []).some((u) => String(u.id) === uid)
    )
      return "maybe";
    return null;
  }, [attendanceData, user?.id]);

  // Build a flat list for rendering attendee rows
  const flatAttendees = (() => {
    const list = [];
    if (attendanceData?.attendees?.going) {
      for (const u of attendanceData.attendees.going)
        list.push({ ...u, status: "going" });
    }
    if (attendanceData?.attendees?.not_going) {
      for (const u of attendanceData.attendees.not_going)
        list.push({ ...u, status: "not_going" });
    }
    if (attendanceData?.attendees?.maybe) {
      for (const u of attendanceData.attendees.maybe)
        list.push({ ...u, status: "maybe" });
    }
    return list;
  })();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  useEffect(() => {
    loadEventDetails();
  }, [id]);

  const loadEventDetails = async () => {
    setIsLoading(true);
    try {
      if (!id) {
        console.error("No event ID provided");
        setEvent(null);
        return;
      }

      const response = await fetchWithAuth("/api/events");

      const data = response;
      const events = data.events || [];

      const foundEvent = events.find(
        (event) => event.id.toString() === id.toString(),
      );

      if (!foundEvent) {
        console.error(`Event with ID ${id} not found`);
        setEvent(null);
        return;
      }

      // Transform the event data to match the expected format
      const transformedEvent = {
        id: foundEvent.id,
        title: foundEvent.title,
        type: foundEvent.event_type,
        date: foundEvent.event_date.split("T")[0],
        time: formatTimeFromDb(foundEvent.event_time),
        location: foundEvent.location || "Location TBD",
        description: foundEvent.description || "No description provided.",
        organizer: foundEvent.organizer_name || "Unknown",
        attendees: [
          { id: "1", name: "Alex Smith", status: "going", avatar: null },
          { id: "2", name: "Sarah Wilson", status: "going", avatar: null },
          { id: "3", name: "Mike Chen", status: "not_going", avatar: null },
          { id: "4", name: "Emma Davis", status: "going", avatar: null },
        ],
        totalInvited: 12,
        createdAt: foundEvent.created_at,
        teamName: foundEvent.team_name,
      };

      setEvent(transformedEvent);
    } catch (error) {
      console.error("Error loading event:", error);
      Alert.alert("Error", "Failed to load event details");
      setEvent(null);
    } finally {
      setIsLoading(false);
    }
  };

  const formatTimeFromDb = (timeString) => {
    if (!timeString) return "";
    try {
      const [hours, minutes] = timeString.split(":");
      const hour24 = parseInt(hours);
      const period = hour24 >= 12 ? "PM" : "AM";
      const hour12 = hour24 === 0 ? 12 : hour24 > 12 ? hour24 - 12 : hour24;
      return `${hour12}:${minutes} ${period}`;
    } catch (error) {
      console.error("Error formatting time:", error);
      return timeString;
    }
  };

  if (!fontsLoaded || isLoading) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
            }}
          >
            Loading event details...
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  if (!event) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
            }}
          >
            Event not found
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  const eventTypes = {
    practice: { label: "Practice", icon: Users, color: colors.primary },
    game: { label: "Game", icon: Calendar, color: colors.success },
    meeting: { label: "Meeting", icon: FileText, color: colors.warning },
    other: { label: "Other", icon: Clock, color: colors.secondary },
  };

  const currentType = eventTypes[event.type] || eventTypes.practice;
  const IconComponent = currentType.icon;

  const handleAttendanceChange = async (status) => {
    try {
      await rsvp.mutateAsync(status);
    } catch (error) {
      console.error("Error updating attendance:", error);
      Alert.alert("Error", error?.message || "Failed to update attendance");
    }
  };

  const handleShareEvent = async () => {
    try {
      await Share.share({
        message: `${event.title}\n${event.date} at ${event.time}\n${event.location}`,
        title: event.title,
      });
    } catch (error) {
      console.error("Error sharing event:", error);
    }
  };

  const handleEditEvent = () => {
    router.push(`/add-event?id=${event.id}&edit=true`);
  };

  const handleDeleteEvent = () => {
    Alert.alert(
      "Delete Event",
      "Are you sure you want to delete this event? This action cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await fetchWithAuth(`/api/events/${event.id}`, {
                method: "DELETE",
              });

              // Emit event to refresh dashboard
              DeviceEventEmitter.emit("eventDeleted", {
                eventId: event.id,
              });

              Alert.alert("Success", "Event deleted successfully", [
                { text: "OK", onPress: () => router.back() },
              ]);
            } catch (error) {
              console.error("Error deleting event:", error);
              Alert.alert("Error", "Failed to delete event");
            }
          },
        },
      ],
    );
  };

  // Replace placeholder attendee counts with server-driven values
  const goingCount = attendanceData?.counts?.going || 0;
  const notGoingCount = attendanceData?.counts?.not_going || 0;
  const totalInvited = attendanceData?.totalInvited ?? 0;
  const rsvpBusy = rsvp?.isPending;

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1, alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
              }}
            >
              Event Details
            </Text>
          </View>

          <View style={{ flexDirection: "row", gap: 8 }}>
            <TouchableOpacity
              style={{
                width: 40,
                height: 40,
                backgroundColor: colors.surface,
                borderRadius: 20,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={handleShareEvent}
            >
              <Share2 size={18} color={colors.mainText} />
            </TouchableOpacity>

            {/* Only coaches can edit/delete */}
            {isCoach && (
              <TouchableOpacity
                style={{
                  width: 40,
                  height: 40,
                  backgroundColor: colors.surface,
                  borderRadius: 20,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
                onPress={handleEditEvent}
              >
                <Edit3 size={18} color={colors.mainText} />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Event Header Card */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 20,
            borderWidth: 1,
            borderColor: colors.border,
            marginBottom: 20,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
            <View
              style={{
                width: 56,
                height: 56,
                backgroundColor: currentType.color + "20",
                borderRadius: 28,
                alignItems: "center",
                justifyContent: "center",
                marginRight: 16,
              }}
            >
              <IconComponent size={28} color={currentType.color} />
            </View>

            <View style={{ flex: 1 }}>
              <View
                style={{
                  backgroundColor: currentType.color + "20",
                  borderRadius: 12,
                  paddingHorizontal: 10,
                  paddingVertical: 4,
                  alignSelf: "flex-start",
                  marginBottom: 8,
                }}
              >
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 11,
                    color: currentType.color,
                    textTransform: "uppercase",
                    letterSpacing: 0.5,
                  }}
                >
                  {currentType.label}
                </Text>
              </View>

              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 20,
                  color: colors.mainText,
                  marginBottom: 12,
                  lineHeight: 26,
                }}
              >
                {event.title}
              </Text>

              <View style={{ gap: 8 }}>
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Calendar size={16} color={colors.secondaryText} />
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 14,
                      color: colors.secondaryText,
                      marginLeft: 8,
                    }}
                  >
                    {event.date} • {event.time}
                  </Text>
                </View>

                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <MapPin size={16} color={colors.secondaryText} />
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 14,
                      color: colors.secondaryText,
                      marginLeft: 8,
                    }}
                  >
                    {event.location}
                  </Text>
                </View>

                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <User size={16} color={colors.secondaryText} />
                  <Text
                    style={{
                      fontFamily: "Inter_400Regular",
                      fontSize: 14,
                      color: colors.secondaryText,
                      marginLeft: 8,
                    }}
                  >
                    Organized by {event.organizer}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Attendance Response - Only show for Players */}
        {isPlayer && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 20,
              borderWidth: 1,
              borderColor: colors.border,
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 16,
              }}
            >
              Will you attend?
            </Text>

            <View style={{ flexDirection: "row", gap: 12 }}>
              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor:
                    currentUserStatus === "going"
                      ? colors.success + "20"
                      : colors.background,
                  borderRadius: 12,
                  paddingVertical: 14,
                  paddingHorizontal: 16,
                  borderWidth: 1,
                  borderColor:
                    currentUserStatus === "going"
                      ? colors.success
                      : colors.border,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: rsvpBusy ? 0.6 : 1,
                }}
                onPress={() => handleAttendanceChange("going")}
                disabled={rsvpBusy}
              >
                <CheckCircle
                  size={18}
                  color={
                    currentUserStatus === "going"
                      ? colors.success
                      : colors.secondaryText
                  }
                  style={{ marginRight: 8 }}
                />
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 14,
                    color:
                      currentUserStatus === "going"
                        ? colors.success
                        : colors.mainText,
                  }}
                >
                  Going
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor:
                    currentUserStatus === "not_going"
                      ? colors.error + "20"
                      : colors.background,
                  borderRadius: 12,
                  paddingVertical: 14,
                  paddingHorizontal: 16,
                  borderWidth: 1,
                  borderColor:
                    currentUserStatus === "not_going"
                      ? colors.error
                      : colors.border,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: rsvpBusy ? 0.6 : 1,
                }}
                onPress={() => handleAttendanceChange("not_going")}
                disabled={rsvpBusy}
              >
                <XCircle
                  size={18}
                  color={
                    currentUserStatus === "not_going"
                      ? colors.error
                      : colors.secondaryText
                  }
                  style={{ marginRight: 8 }}
                />
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 14,
                    color:
                      currentUserStatus === "not_going"
                        ? colors.error
                        : colors.mainText,
                  }}
                >
                  Can't Go
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Description */}
        {event.description && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 20,
              borderWidth: 1,
              borderColor: colors.border,
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 12,
              }}
            >
              Notes
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
                lineHeight: 20,
              }}
            >
              {event.description}
            </Text>
          </View>
        )}

        {/* Attendance Summary */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 20,
            borderWidth: 1,
            borderColor: colors.border,
            marginBottom: 20,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            Attendance ({goingCount}/{totalInvited})
          </Text>

          <View style={{ flexDirection: "row", marginBottom: 16, gap: 16 }}>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <CheckCircle size={16} color={colors.success} />
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.success,
                  marginLeft: 6,
                }}
              >
                {goingCount} Going
              </Text>
            </View>

            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <XCircle size={16} color={colors.error} />
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.error,
                  marginLeft: 6,
                }}
              >
                {notGoingCount} Can't Go
              </Text>
            </View>
          </View>

          {/* Attendee List */}
          {attendanceLoading ? (
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              Loading attendance…
            </Text>
          ) : flatAttendees.length === 0 ? (
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              No responses yet
            </Text>
          ) : (
            <View style={{ gap: 12 }}>
              {flatAttendees.map((attendee) => (
                <View
                  key={`${attendee.status}-${attendee.id}`}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      flex: 1,
                    }}
                  >
                    <View
                      style={{
                        width: 32,
                        height: 32,
                        backgroundColor: colors.primary + "20",
                        borderRadius: 16,
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 12,
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "Inter_500Medium",
                          fontSize: 12,
                          color: colors.primary,
                        }}
                      >
                        {(attendee.name || "?").charAt(0)}
                      </Text>
                    </View>
                    <Text
                      style={{
                        fontFamily: "Inter_400Regular",
                        fontSize: 14,
                        color: colors.mainText,
                        flex: 1,
                      }}
                    >
                      {attendee.name || "Unnamed"}
                    </Text>
                  </View>

                  <View
                    style={{
                      backgroundColor:
                        attendee.status === "going"
                          ? colors.success + "20"
                          : attendee.status === "not_going"
                            ? colors.error + "20"
                            : colors.lavender,
                      borderRadius: 8,
                      paddingHorizontal: 8,
                      paddingVertical: 4,
                    }}
                  >
                    <Text
                      style={{
                        fontFamily: "Inter_500Medium",
                        fontSize: 11,
                        color:
                          attendee.status === "going"
                            ? colors.success
                            : attendee.status === "not_going"
                              ? colors.error
                              : colors.mainText,
                      }}
                    >
                      {attendee.status === "going"
                        ? "Going"
                        : attendee.status === "not_going"
                          ? "Can't Go"
                          : "Maybe"}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>

        {/* Action Buttons */}
        {isCoach && (
          <View style={{ gap: 12 }}>
            <TouchableOpacity
              style={{
                backgroundColor: colors.error + "20",
                borderRadius: 12,
                paddingVertical: 16,
                alignItems: "center",
                flexDirection: "row",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.error,
              }}
              onPress={handleDeleteEvent}
            >
              <Trash2
                size={18}
                color={colors.error}
                style={{ marginRight: 8 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                  color: colors.error,
                }}
              >
                Delete Event
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </ScreenWrapper>
  );
}
