import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Image,
  Linking,
  ActivityIndicator,
  Alert,
  TextInput,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import {
  ArrowLeft,
  Mail,
  Phone,
  Shield,
  User,
  FileText,
  Plus,
  Calendar,
  TrendingUp,
  Edit3,
  Save,
  X,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import { fetchWithAuth } from "@/utils/api";
import { useDashboardData } from "@/hooks/useDashboardData";
import { useUser } from "@/utils/auth/useUser";
import { useAuthStore } from "@/utils/auth/store";

// Move InfoRow component OUTSIDE to prevent recreation on every render
const InfoRow = ({
  icon: Icon,
  label,
  value,
  onPress,
  editable = false,
  isEditing,
  phoneInput,
  handlePhoneInputChange,
  colors,
}) => {
  if (editable && isEditing) {
    return (
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 12,
          padding: 16,
          marginBottom: 12,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 8,
          }}
        >
          <Icon size={20} color={colors.primary} style={{ marginRight: 16 }} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.secondaryText,
            }}
          >
            {label}
          </Text>
        </View>
        <TextInput
          style={{
            backgroundColor: colors.background,
            borderRadius: 8,
            padding: 12,
            fontSize: 16,
            color: colors.mainText,
            borderWidth: 1,
            borderColor: colors.border,
            fontFamily: "Inter_400Regular",
          }}
          placeholder="Enter phone number"
          placeholderTextColor={colors.secondaryText}
          value={phoneInput}
          onChangeText={handlePhoneInputChange}
          keyboardType="phone-pad"
          autoCorrect={false}
          maxLength={20}
        />
      </View>
    );
  }

  return (
    <TouchableOpacity
      style={{
        backgroundColor: colors.surface,
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        flexDirection: "row",
        alignItems: "center",
        borderWidth: 1,
        borderColor: colors.border,
      }}
      onPress={onPress}
      disabled={!onPress}
    >
      <Icon size={20} color={colors.primary} style={{ marginRight: 16 }} />
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 16,
          color: colors.mainText,
          flex: 1,
        }}
      >
        {value}
      </Text>
    </TouchableOpacity>
  );
};

// Move EvaluationCard component OUTSIDE to prevent recreation on every render
const EvaluationCard = ({ evaluation, handleViewEvaluation, colors }) => {
  // Get status config (matching the TypeScript version)
  const getStatusConfig = (status) => {
    switch (status) {
      case "submitted":
        return {
          chipBg: colors.success + "20",
          chipText: colors.success,
          iconColor: colors.success,
          icon: "✓",
        };
      case "draft":
        return {
          chipBg: colors.chipBg,
          chipText: colors.secondaryText,
          iconColor: colors.secondaryText,
          icon: "📄",
        };
      default:
        return {
          chipBg: colors.primary + "20",
          chipText: colors.primary,
          iconColor: colors.primary,
          icon: "📄",
        };
    }
  };

  // Get score badge color (matching the TypeScript version)
  const getScoreBadgeColors = (score) => {
    if (score >= 8) return { bg: colors.success + "20", text: colors.success };
    if (score >= 6) return { bg: colors.primary + "20", text: colors.primary };
    if (score > 0) return { bg: colors.alert + "20", text: colors.alert };
    return { bg: colors.chipBg, text: colors.secondaryText };
  };

  const getEvaluationTypeLabel = (type) => {
    switch (type) {
      case "mid_season":
        return "Mid-Season";
      case "end_season":
        return "End of Season";
      case "monthly":
        return "Monthly";
      default:
        return type;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const statusConfig = getStatusConfig(evaluation.status);
  const scoreBadgeColors = getScoreBadgeColors(evaluation.overallScore);

  return (
    <TouchableOpacity
      style={{
        backgroundColor: colors.surface,
        borderRadius: 12,
        padding: 12,
        marginBottom: 8,
        borderWidth: 1,
        borderColor: colors.border,
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "space-between",
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 3,
      }}
      onPress={() => handleViewEvaluation(evaluation.id)}
    >
      {/* Left content - min-w-0 for truncation */}
      <View style={{ flex: 1, minWidth: 0 }}>
        {/* First row: Title and Status chip together */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 2,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.mainText,
              marginRight: 8,
            }}
            numberOfLines={1}
          >
            {getEvaluationTypeLabel(evaluation.type)}
          </Text>

          {/* Status Chip - positioned right after title */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
              backgroundColor: statusConfig.chipBg,
              paddingHorizontal: 8,
              paddingVertical: 2,
              borderRadius: 20,
            }}
          >
            <Text style={{ fontSize: 10, color: statusConfig.iconColor }}>
              {statusConfig.icon}
            </Text>
            <Text
              style={{
                fontSize: 10,
                fontFamily: "Inter_500Medium",
                color: statusConfig.chipText,
                textTransform: "uppercase",
              }}
            >
              {evaluation.status}
            </Text>
          </View>
        </View>

        {/* Second row: Calendar icon and date with gap-1 (4px) */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Calendar size={14} color={colors.secondaryText} />
          <Text
            style={{
              fontSize: 12,
              color: colors.secondaryText,
              fontFamily: "Inter_400Regular",
            }}
            numberOfLines={1}
          >
            {formatDate(evaluation.date)}
          </Text>
        </View>
      </View>

      {/* Score Badge */}
      <View
        style={{
          minWidth: 48,
          height: 32,
          backgroundColor: scoreBadgeColors.bg,
          borderRadius: 16,
          alignItems: "center",
          justifyContent: "center",
          paddingHorizontal: 8,
          marginLeft: 12,
        }}
      >
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Inter_600SemiBold",
            color: scoreBadgeColors.text,
          }}
        >
          {evaluation.overallScore.toFixed(1)}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

export default function PlayerDetails() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { playerId } = useLocalSearchParams();
  const { colors } = useTheme();
  const [player, setPlayer] = useState(null);
  const [evaluations, setEvaluations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingEvaluations, setIsLoadingEvaluations] = useState(true);
  const { selectedTeam } = useDashboardData();
  const { data: user } = useUser();
  const { auth, setAuth } = useAuthStore();
  const viewerRole = selectedTeam?.user_role; // 'Coach' | 'Player'
  const isSelf = user?.id?.toString() === playerId?.toString();
  // Treat owners as coaches and support lowercase roles
  const normalizedRole = (selectedTeam?.user_role || "").toLowerCase();
  const isCoach =
    normalizedRole === "coach" ||
    normalizedRole === "owner" ||
    selectedTeam?.is_owner === true ||
    (selectedTeam?.owner_id &&
      String(selectedTeam.owner_id) === String(user?.id));

  // Can edit phone number only if: user is viewing their own profile
  const canEdit = isSelf;

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [phoneInput, setPhoneInput] = useState("");

  // Helper function to get initials from name
  const getInitials = (name) => {
    if (!name) return "??";
    const names = name.split(" ");
    if (names.length >= 2) {
      return (
        names[0].charAt(0) + names[names.length - 1].charAt(0)
      ).toUpperCase();
    }
    return name.charAt(0).toUpperCase();
  };

  useEffect(() => {
    if (playerId) {
      fetchPlayerDetails();
      fetchPlayerEvaluations();
    }
  }, [playerId]);

  useEffect(() => {
    if (player) {
      setPhoneInput(player.phone || "");
    }
  }, [player]);

  const fetchPlayerDetails = async () => {
    try {
      setIsLoading(true);
      // CHANGED: use fetchWithAuth
      const data = await fetchWithAuth(`/api/players/${playerId}`);
      setPlayer(data.player);
    } catch (error) {
      console.error("Error fetching player details:", error);
      Alert.alert("Error", "Failed to load player details. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchPlayerEvaluations = async () => {
    try {
      setIsLoadingEvaluations(true);
      // CHANGED: use fetchWithAuth
      const data = await fetchWithAuth(`/api/evaluations?playerId=${playerId}`);
      if (data.success) {
        // Process evaluations to match the expected format
        const processedEvaluations = data.evaluations.map((evaluation) => ({
          id: evaluation.id,
          type: evaluation.evaluation_type,
          date: evaluation.created_at,
          status: evaluation.status,
          // Calculate overall score as average of all skills
          overallScore:
            (evaluation.ball_control +
              evaluation.passing +
              evaluation.shooting +
              evaluation.defending +
              evaluation.fitness_level +
              evaluation.teamwork +
              evaluation.attitude +
              evaluation.leadership) /
            8,
          // Technical average
          technicalAverage:
            (evaluation.ball_control +
              evaluation.passing +
              evaluation.shooting +
              evaluation.defending) /
            4,
          // Mental/Physical average
          mentalPhysicalAverage:
            (evaluation.fitness_level +
              evaluation.teamwork +
              evaluation.attitude +
              evaluation.leadership) /
            4,
        }));
        setEvaluations(processedEvaluations);
      }
    } catch (error) {
      console.error("Error fetching evaluations:", error);
      // Don't show error alert for evaluations, just log it
    } finally {
      setIsLoadingEvaluations(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const response = await fetchWithAuth(`/api/players/${playerId}`, {
        method: "PUT",
        body: JSON.stringify({ phone: phoneInput }),
      });

      if (response.success) {
        setPlayer(response.player);

        // If editing own profile, update auth store too
        if (isSelf && auth && response.player) {
          setAuth({
            ...auth,
            user: {
              ...auth.user,
              phone: response.player.phone,
            },
          });
        }

        setIsEditing(false);
        Alert.alert("Success", "Phone number updated successfully!");
      } else {
        throw new Error("Failed to update player");
      }
    } catch (error) {
      console.error("Error updating player:", error);
      Alert.alert("Error", "Failed to update phone number. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setPhoneInput(player?.phone || "");
    setIsEditing(false);
  };

  const handlePhoneInputChange = useCallback((text) => {
    setPhoneInput(text);
  }, []);

  if (!fontsLoaded) {
    return null;
  }

  // Show loading spinner while fetching data
  if (isLoading) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top + 20,
          }}
        >
          <ActivityIndicator size="large" color={colors.primary} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.secondaryText,
              marginTop: 16,
            }}
          >
            Loading player details...
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  // Show error if player not found
  if (!player) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top + 20,
            paddingHorizontal: 16,
          }}
        >
          <User
            size={64}
            color={colors.secondaryText}
            style={{ marginBottom: 16 }}
          />
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
              marginBottom: 8,
              textAlign: "center",
            }}
          >
            Player Not Found
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
              marginBottom: 24,
            }}
          >
            The player you're looking for doesn't exist or has been removed.
          </Text>
          <TouchableOpacity
            style={{
              backgroundColor: colors.primary,
              borderRadius: 12,
              paddingHorizontal: 24,
              paddingVertical: 12,
            }}
            onPress={() => router.back()}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: "white",
              }}
            >
              Go Back
            </Text>
          </TouchableOpacity>
        </View>
      </ScreenWrapper>
    );
  }

  const getRoleColor = (role) => {
    switch (role) {
      case "Coach":
        return colors.primary;
      case "Player":
        return colors.success;
      default:
        return colors.secondaryText;
    }
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case "Coach":
        return Shield;
      case "Player":
        return User;
      default:
        return User;
    }
  };

  const getScoreColor = (score) => {
    if (score >= 8) return colors.success;
    if (score >= 6) return colors.primary;
    return colors.alert;
  };

  const getEvaluationTypeLabel = (type) => {
    switch (type) {
      case "mid_season":
        return "Mid-Season";
      case "end_season":
        return "End of Season";
      case "monthly":
        return "Monthly";
      default:
        return type;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const handleCall = () => {
    Linking.openURL(`tel:${player.phone}`);
  };

  const handleEmail = () => {
    Linking.openURL(`mailto:${player.email}`);
  };

  const handleNewEvaluation = () => {
    router.push(`/player-evaluation?playerId=${playerId}`);
  };

  // UPDATED: Players go to view-only details; coaches go to edit screen
  const handleViewEvaluation = (evaluationId) => {
    if (isCoach) {
      router.push(
        `/player-evaluation?evaluationId=${evaluationId}&playerId=${playerId}`,
      );
    } else {
      router.push(`/evaluation-details?evaluationId=${evaluationId}`);
    }
  };

  const RoleIcon = getRoleIcon(player.role);

  return (
    <ScreenWrapper>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 32,
          }}
        >
          <TouchableOpacity
            style={{
              width: 44,
              height: 44,
              backgroundColor: colors.surface,
              borderRadius: 22,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color={colors.mainText} />
          </TouchableOpacity>

          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 20,
              color: colors.mainText,
            }}
          >
            Player Profile
          </Text>

          {canEdit && (
            <TouchableOpacity
              style={{
                width: 44,
                height: 44,
                backgroundColor: isEditing
                  ? colors.alert + "15"
                  : colors.primary + "15",
                borderRadius: 22,
                alignItems: "center",
                justifyContent: "center",
              }}
              onPress={isEditing ? handleCancel : () => setIsEditing(true)}
            >
              {isEditing ? (
                <X size={20} color={colors.alert} />
              ) : (
                <Edit3 size={20} color={colors.primary} />
              )}
            </TouchableOpacity>
          )}
          {!canEdit && <View style={{ width: 44 }} />}
        </View>

        {/* Player Profile Card */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 32,
            marginBottom: 32,
            alignItems: "center",
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 8,
            elevation: 4,
          }}
        >
          {/* Avatar with Initials or Photo - Centered */}
          <View
            style={{
              position: "relative",
              marginBottom: 20,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: colors.lavender,
                alignItems: "center",
                justifyContent: "center",
                overflow: "hidden",
              }}
            >
              {player.image ? (
                <Image
                  source={{ uri: player.image }}
                  style={{
                    width: 80,
                    height: 80,
                    borderRadius: 40,
                  }}
                />
              ) : (
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 28,
                    color: colors.primary,
                  }}
                >
                  {getInitials(player.name)}
                </Text>
              )}
            </View>
          </View>

          {/* Name - Centered */}
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: colors.mainText,
              marginBottom: 12,
              textAlign: "center",
            }}
          >
            {player.name}
          </Text>

          {/* Role - Perfectly Centered */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              alignSelf: "center",
            }}
          >
            {/* Role Pill with Icon */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: colors.success + "20",
                borderRadius: 20,
                paddingHorizontal: 12,
                paddingVertical: 6,
              }}
            >
              <User
                size={16}
                color={colors.success}
                style={{ marginRight: 6 }}
              />
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.success,
                }}
              >
                {player.role}
              </Text>
            </View>
          </View>
        </View>

        {/* Evaluation Section - Only for Players */}
        {player.role === "Player" && (
          <View style={{ marginBottom: 32 }}>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 20,
                  color: colors.mainText,
                }}
              >
                Evaluations
              </Text>
              {isCoach && (
                <TouchableOpacity
                  style={{
                    backgroundColor: colors.primary,
                    borderRadius: 20,
                    paddingHorizontal: 16,
                    paddingVertical: 8,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                  onPress={handleNewEvaluation}
                >
                  <Plus size={16} color="white" style={{ marginRight: 6 }} />
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 14,
                      color: "white",
                    }}
                  >
                    New
                  </Text>
                </TouchableOpacity>
              )}
            </View>

            {viewerRole === "Player" && !isSelf ? (
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 16,
                  padding: 32,
                  alignItems: "center",
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 4,
                }}
              >
                <FileText
                  size={48}
                  color={colors.secondaryText}
                  style={{ marginBottom: 16 }}
                />
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 18,
                    color: colors.mainText,
                    marginBottom: 8,
                    textAlign: "center",
                  }}
                >
                  Evaluations Hidden
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 14,
                    color: colors.secondaryText,
                    textAlign: "center",
                  }}
                >
                  Players can only view their own evaluations.
                </Text>
              </View>
            ) : evaluations.length > 0 ? (
              evaluations.map((evaluation) => (
                <EvaluationCard
                  key={evaluation.id}
                  evaluation={evaluation}
                  handleViewEvaluation={handleViewEvaluation}
                  colors={colors}
                />
              ))
            ) : (
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 16,
                  padding: 32,
                  alignItems: "center",
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 4,
                }}
              >
                <FileText
                  size={48}
                  color={colors.secondaryText}
                  style={{ marginBottom: 16 }}
                />
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 18,
                    color: colors.mainText,
                    marginBottom: 8,
                    textAlign: "center",
                  }}
                >
                  No Evaluations Yet
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 14,
                    color: colors.secondaryText,
                    textAlign: "center",
                    marginBottom: 24,
                    lineHeight: 20,
                  }}
                >
                  Start tracking this player's progress by creating their first
                  evaluation.
                </Text>
                {isCoach && (
                  <TouchableOpacity
                    style={{
                      backgroundColor: colors.primary,
                      borderRadius: 12,
                      paddingHorizontal: 24,
                      paddingVertical: 12,
                    }}
                    onPress={handleNewEvaluation}
                  >
                    <Text
                      style={{
                        fontFamily: "Inter_500Medium",
                        fontSize: 16,
                        color: "white",
                      }}
                    >
                      Create First Evaluation
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
          </View>
        )}

        {/* Contact Information */}
        <View style={{ marginBottom: 24 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 20,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            Contact Information
          </Text>

          <InfoRow
            icon={Mail}
            label="Email Address"
            value={player.email}
            onPress={handleEmail}
            isEditing={isEditing}
            colors={colors}
          />

          <InfoRow
            icon={Phone}
            label="Phone Number"
            value={phoneInput || "No phone number"}
            onPress={!isEditing ? handleCall : undefined}
            editable={true}
            isEditing={isEditing}
            phoneInput={phoneInput}
            handlePhoneInputChange={handlePhoneInputChange}
            colors={colors}
          />

          {isEditing && (
            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                borderRadius: 12,
                paddingVertical: 16,
                alignItems: "center",
                marginTop: 8,
                opacity: isSaving ? 0.7 : 1,
              }}
              onPress={handleSave}
              disabled={isSaving}
            >
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Save size={20} color="white" />
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 16,
                    color: "white",
                    marginLeft: 8,
                  }}
                >
                  {isSaving ? "Saving..." : "Save Changes"}
                </Text>
              </View>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
