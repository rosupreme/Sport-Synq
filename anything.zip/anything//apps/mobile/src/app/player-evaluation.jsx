import React, { useState } from "react";
import { ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import { usePlayerEvaluation } from "@/hooks/usePlayerEvaluation";
import { LoadingState } from "@/components/player-evaluation/LoadingState";
import { PlayerNotFoundState } from "@/components/player-evaluation/PlayerNotFoundState";
import { EvaluationHeader } from "@/components/player-evaluation/EvaluationHeader";
import { EvaluationDetails } from "@/components/player-evaluation/EvaluationDetails";
import { SkillsRatingSection } from "@/components/player-evaluation/SkillsRatingSection";
import { WrittenFeedbackSection } from "@/components/player-evaluation/WrittenFeedbackSection";
import { EvaluationSummary } from "@/components/player-evaluation/EvaluationSummary";
import { TypePickerModal } from "@/components/player-evaluation/TypePickerModal";
import {
  getScoreColor,
  getScoreLabel,
  evaluationTypes,
  skillCategories,
} from "@/utils/evaluationHelpers";

export default function PlayerEvaluation() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { playerId, evaluationId } = useLocalSearchParams();
  const { colors } = useTheme();
  const [showTypePicker, setShowTypePicker] = useState(false);

  const {
    isLoading,
    isLoadingPlayer,
    player,
    strengths,
    setStrengths,
    areasForImprovement,
    setAreasForImprovement,
    goalsNextPeriod,
    setGoalsNextPeriod,
    coachNotes,
    setCoachNotes,
    evaluation,
    updateEvaluation,
    handleSaveEvaluation,
    handleDeleteEvaluation,
  } = usePlayerEvaluation(playerId, evaluationId, router);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  // Loading state
  if (isLoadingPlayer) {
    return <LoadingState insets={insets} colors={colors} />;
  }

  // Player not found state
  if (!player) {
    return (
      <PlayerNotFoundState
        insets={insets}
        colors={colors}
        onGoBack={() => router.back()}
      />
    );
  }

  const isNewEvaluation = !evaluationId;

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <EvaluationHeader
          insets={insets}
          colors={colors}
          isNewEvaluation={isNewEvaluation}
          player={player}
          isLoading={isLoading}
          onBack={() => router.back()}
          onDelete={handleDeleteEvaluation}
          onSaveDraft={() => handleSaveEvaluation("draft")}
          onSubmit={() => handleSaveEvaluation("submitted")}
        />

        {/* Form Content */}
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingHorizontal: 16,
            paddingTop: 20,
            paddingBottom: insets.bottom + 20,
          }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <EvaluationDetails
            colors={colors}
            evaluation={evaluation}
            evaluationTypes={evaluationTypes}
            onShowTypePicker={() => setShowTypePicker(true)}
          />

          <SkillsRatingSection
            colors={colors}
            skillCategories={skillCategories}
            evaluation={evaluation}
            updateEvaluation={updateEvaluation}
            getScoreColor={(score) => getScoreColor(score, colors)}
            getScoreLabel={getScoreLabel}
          />

          <WrittenFeedbackSection
            colors={colors}
            strengths={strengths}
            setStrengths={setStrengths}
            areasForImprovement={areasForImprovement}
            setAreasForImprovement={setAreasForImprovement}
            goalsNextPeriod={goalsNextPeriod}
            setGoalsNextPeriod={setGoalsNextPeriod}
            coachNotes={coachNotes}
            setCoachNotes={setCoachNotes}
          />

          <EvaluationSummary colors={colors} evaluation={evaluation} />
        </ScrollView>

        <TypePickerModal
          visible={showTypePicker}
          onClose={() => setShowTypePicker(false)}
          colors={colors}
          insets={insets}
          evaluationTypes={evaluationTypes}
          selectedType={evaluation.evaluationType}
          onSelectType={(type) => updateEvaluation("evaluationType", type)}
        />
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
