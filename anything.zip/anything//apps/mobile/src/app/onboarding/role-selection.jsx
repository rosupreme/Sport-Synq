import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  Animated,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Shield, User, ArrowRight } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";

export default function RoleSelection() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();
  const [selectedRole, setSelectedRole] = useState(null);
  const [scaleAnim] = useState(new Animated.Value(1));

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleRoleSelect = (role) => {
    setSelectedRole(role);

    // Animate button press
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const handleContinue = () => {
    if (selectedRole === "coach") {
      // Coaches must select subscription first
      router.push("/onboarding/coach/subscription-selection");
    } else if (selectedRole === "player") {
      // Players skip subscription and go directly to join team
      router.push("/onboarding/player/join-team");
    }
  };

  const RoleCard = ({ role, title, description, icon: Icon, benefits }) => {
    const isSelected = selectedRole === role;

    return (
      <TouchableOpacity
        style={{
          backgroundColor: isSelected ? colors.primary + "10" : colors.surface,
          borderRadius: 20,
          padding: 24,
          marginBottom: 16,
          borderWidth: 2,
          borderColor: isSelected ? colors.primary : colors.border,
        }}
        onPress={() => handleRoleSelect(role)}
      >
        <View style={{ alignItems: "center", marginBottom: 20 }}>
          <View
            style={{
              width: 80,
              height: 80,
              backgroundColor: isSelected ? colors.primary : colors.lavender,
              borderRadius: 40,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 16,
            }}
          >
            <Icon size={40} color={isSelected ? "white" : colors.primary} />
          </View>

          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: colors.mainText,
              marginBottom: 8,
              textAlign: "center",
            }}
          >
            {title}
          </Text>

          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
              lineHeight: 24,
            }}
          >
            {description}
          </Text>
        </View>

        <View style={{ marginBottom: 8 }}>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 12,
            }}
          >
            You can:
          </Text>

          {benefits.map((benefit, index) => (
            <View
              key={index}
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <View
                style={{
                  width: 6,
                  height: 6,
                  backgroundColor: colors.primary,
                  borderRadius: 3,
                  marginRight: 12,
                }}
              />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.secondaryText,
                  flex: 1,
                }}
              >
                {benefit}
              </Text>
            </View>
          ))}
        </View>

        {isSelected && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              marginTop: 8,
              padding: 8,
              backgroundColor: colors.primary + "20",
              borderRadius: 12,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.primary,
                marginRight: 4,
              }}
            >
              Selected
            </Text>
            <View
              style={{
                width: 20,
                height: 20,
                backgroundColor: colors.primary,
                borderRadius: 10,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 12,
                  color: "white",
                }}
              >
                ✓
              </Text>
            </View>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <ScreenWrapper>
      <View
        style={{
          flex: 1,
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
      >
        {/* Header */}
        <View style={{ alignItems: "center", marginBottom: 40 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 32,
              color: colors.mainText,
              marginBottom: 12,
              textAlign: "center",
            }}
          >
            Welcome! 👋
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 18,
              color: colors.secondaryText,
              textAlign: "center",
              lineHeight: 26,
              paddingHorizontal: 20,
            }}
          >
            Choose your role to get started with your team management experience
          </Text>
        </View>

        {/* Role Cards */}
        <ScrollView style={{ flex: 1 }}>
          <RoleCard
            role="coach"
            title="Coach"
            description="Lead and manage your team with powerful organizational tools"
            icon={Shield}
            benefits={[
              "Create and manage team events",
              "Track player attendance and payments",
              "Send team announcements",
              "Organize practice sessions and games",
              "Manage team roster and roles",
            ]}
          />

          <RoleCard
            role="player"
            title="Player"
            description="Join your team and stay connected with teammates and coaches"
            icon={User}
            benefits={[
              "RSVP to team events and practices",
              "View team schedule and updates",
              "Chat with teammates",
              "Track your attendance",
              "Receive important announcements",
            ]}
          />
        </ScrollView>

        {/* Continue Button */}
        <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
          <TouchableOpacity
            style={{
              backgroundColor: selectedRole ? colors.primary : colors.border,
              borderRadius: 16,
              padding: 18,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              marginTop: 20,
              opacity: selectedRole ? 1 : 0.5,
            }}
            onPress={handleContinue}
            disabled={!selectedRole}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: selectedRole ? "white" : colors.secondaryText,
                marginRight: 8,
              }}
            >
              Continue as{" "}
              {selectedRole === "coach"
                ? "Coach"
                : selectedRole === "player"
                  ? "Player"
                  : "..."}
            </Text>
            <ArrowRight
              size={20}
              color={selectedRole ? "white" : colors.secondaryText}
            />
          </TouchableOpacity>
        </Animated.View>
      </View>
    </ScreenWrapper>
  );
}
