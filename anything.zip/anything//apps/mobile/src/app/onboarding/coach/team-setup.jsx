import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Platform,
  Animated,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  ArrowLeft,
  ArrowRight,
  Users,
  MapPin,
  Calendar,
  Trophy,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";

export default function CoachTeamSetup() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();

  const [teamName, setTeamName] = useState("");
  const [sport, setSport] = useState("");
  const [location, setLocation] = useState("");
  const [season, setSeason] = useState("");
  const [ageGroup, setAgeGroup] = useState("");

  const focusedPadding = 12;
  const paddingAnimation = useRef(
    new Animated.Value(insets.bottom + focusedPadding),
  ).current;

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const animateTo = (value) => {
    Animated.timing(paddingAnimation, {
      toValue: value,
      duration: 200,
      useNativeDriver: true,
    }).start();
  };

  const handleInputFocus = () => {
    if (Platform.OS === "web") {
      return;
    }
    animateTo(focusedPadding);
  };

  const handleInputBlur = () => {
    if (Platform.OS === "web") {
      return;
    }
    animateTo(insets.bottom + focusedPadding);
  };

  const isFormValid = teamName.trim() && sport.trim() && ageGroup.trim();

  const handleContinue = () => {
    if (isFormValid) {
      // Pass team data as route params
      router.push({
        pathname: "/onboarding/coach/invite-players",
        params: {
          teamName,
          sport,
          ageGroup,
          location,
          season,
        },
      });
    }
  };

  const sportsOptions = [
    "Soccer",
    "Basketball",
    "Baseball",
    "Football",
    "Tennis",
    "Volleyball",
    "Hockey",
    "Swimming",
    "Track & Field",
    "Other",
  ];

  const ageGroups = [
    "Under 8",
    "Under 10",
    "Under 12",
    "Under 14",
    "Under 16",
    "Under 18",
    "Adult",
    "Mixed Ages",
  ];

  const SelectionGrid = ({ options, selectedValue, onSelect, columns = 2 }) => (
    <View
      style={{
        flexDirection: "row",
        flexWrap: "wrap",
        gap: 8,
        marginTop: 8,
      }}
    >
      {options.map((option) => (
        <TouchableOpacity
          key={option}
          style={{
            backgroundColor:
              selectedValue === option ? colors.primary : colors.surface,
            borderWidth: 1,
            borderColor:
              selectedValue === option ? colors.primary : colors.border,
            borderRadius: 12,
            paddingHorizontal: 16,
            paddingVertical: 10,
            minWidth: `${Math.floor(100 / columns) - 2}%`,
            alignItems: "center",
          }}
          onPress={() => onSelect(option)}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: selectedValue === option ? "white" : colors.mainText,
              textAlign: "center",
            }}
          >
            {option}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingHorizontal: 16,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 32,
            }}
          >
            <TouchableOpacity
              style={{
                width: 44,
                height: 44,
                backgroundColor: colors.surface,
                borderRadius: 22,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={() => router.back()}
            >
              <ArrowLeft size={24} color={colors.mainText} />
            </TouchableOpacity>

            <View style={{ alignItems: "center" }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.secondaryText,
                }}
              >
                Step 1 of 2
              </Text>
              <View style={{ flexDirection: "row", gap: 4, marginTop: 4 }}>
                <View
                  style={{
                    width: 20,
                    height: 4,
                    backgroundColor: colors.primary,
                    borderRadius: 2,
                  }}
                />
                <View
                  style={{
                    width: 20,
                    height: 4,
                    backgroundColor: colors.border,
                    borderRadius: 2,
                  }}
                />
              </View>
            </View>

            <View style={{ width: 44 }} />
          </View>

          {/* Content */}
          <View style={{ marginBottom: 40 }}>
            <View
              style={{
                width: 80,
                height: 80,
                backgroundColor: colors.primary + "20",
                borderRadius: 40,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 24,
                alignSelf: "center",
              }}
            >
              <Trophy size={40} color={colors.primary} />
            </View>

            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 28,
                color: colors.mainText,
                marginBottom: 12,
                textAlign: "center",
              }}
            >
              Set up your team
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.secondaryText,
                textAlign: "center",
                lineHeight: 24,
                paddingHorizontal: 20,
              }}
            >
              Tell us about your team so we can customize your experience
            </Text>
          </View>

          {/* Form */}
          <View>
            {/* Team Name */}
            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Team Name *
              </Text>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                }}
                placeholder="Enter your team name"
                placeholderTextColor={colors.secondaryText}
                value={teamName}
                onChangeText={setTeamName}
                onFocus={handleInputFocus}
                onBlur={handleInputBlur}
              />
            </View>

            {/* Sport */}
            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Sport *
              </Text>
              <SelectionGrid
                options={sportsOptions}
                selectedValue={sport}
                onSelect={setSport}
                columns={3}
              />
            </View>

            {/* Age Group */}
            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Age Group *
              </Text>
              <SelectionGrid
                options={ageGroups}
                selectedValue={ageGroup}
                onSelect={setAgeGroup}
                columns={2}
              />
            </View>

            {/* Location */}
            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Location
              </Text>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                }}
                placeholder="City, State"
                placeholderTextColor={colors.secondaryText}
                value={location}
                onChangeText={setLocation}
                onFocus={handleInputFocus}
                onBlur={handleInputBlur}
              />
            </View>

            {/* Season */}
            <View style={{ marginBottom: 32 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Season
              </Text>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                }}
                placeholder="e.g., Spring 2024, Fall Season"
                placeholderTextColor={colors.secondaryText}
                value={season}
                onChangeText={setSeason}
                onFocus={handleInputFocus}
                onBlur={handleInputBlur}
              />
            </View>
          </View>
        </ScrollView>

        {/* Continue Button */}
        <Animated.View
          style={{
            paddingBottom: paddingAnimation,
            paddingHorizontal: 16,
            paddingTop: 16,
            backgroundColor: colors.background,
            borderTopWidth: 1,
            borderTopColor: colors.border,
          }}
        >
          <TouchableOpacity
            style={{
              backgroundColor: isFormValid ? colors.primary : colors.border,
              borderRadius: 16,
              padding: 18,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              opacity: isFormValid ? 1 : 0.5,
            }}
            onPress={handleContinue}
            disabled={!isFormValid}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: isFormValid ? "white" : colors.secondaryText,
                marginRight: 8,
              }}
            >
              Continue
            </Text>
            <ArrowRight
              size={20}
              color={isFormValid ? "white" : colors.secondaryText}
            />
          </TouchableOpacity>
        </Animated.View>
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
