import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Platform,
  Animated,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { DeviceEventEmitter } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { fetchWithAuth } from "@/utils/api";
import {
  ArrowLeft,
  ArrowRight,
  Users,
  Search,
  Check,
  AlertCircle,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";

export default function PlayerJoinTeam() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();

  const [teamCode, setTeamCode] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [teamFound, setTeamFound] = useState(null);
  const [error, setError] = useState("");
  const [joining, setJoining] = useState(false);

  const focusedPadding = 12;
  const paddingAnimation = useRef(
    new Animated.Value(insets.bottom + focusedPadding),
  ).current;

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const animateTo = (value) => {
    Animated.timing(paddingAnimation, {
      toValue: value,
      duration: 200,
      useNativeDriver: true,
    }).start();
  };

  const handleInputFocus = () => {
    if (Platform.OS === "web") {
      return;
    }
    animateTo(focusedPadding);
  };

  const handleInputBlur = () => {
    if (Platform.OS === "web") {
      return;
    }
    animateTo(insets.bottom + focusedPadding);
  };

  // Validate team code against backend
  const validateTeamCode = async (code) => {
    try {
      setIsValidating(true);
      setError("");
      setTeamFound(null);

      const data = await fetchWithAuth(
        `/api/teams/validate-code?code=${encodeURIComponent(code)}`,
      );

      if (data?.valid && data?.team) {
        setTeamFound(data.team);
        setError("");
      } else {
        setTeamFound(null);
        setError("Team code not found. Please check the code and try again.");
      }
    } catch (e) {
      console.error("Validate team code error:", e);
      setError(e?.message || "Could not validate code. Please try again.");
      setTeamFound(null);
    } finally {
      setIsValidating(false);
    }
  };

  const handleTeamCodeChange = (text) => {
    const next = text.toUpperCase();
    setTeamCode(next);
    setError("");
    setTeamFound(null);

    if (next.trim().length >= 4) {
      validateTeamCode(next.trim());
    }
  };

  const handleJoinTeam = async () => {
    if (!teamFound || !teamCode) return;
    try {
      setJoining(true);
      const data = await fetchWithAuth("/api/teams/join", {
        method: "POST",
        body: JSON.stringify({ code: teamCode.trim().toUpperCase() }),
      });

      // Save selected team and notify other screens
      if (data?.team?.id) {
        await AsyncStorage.setItem("selected_team_id", String(data.team.id));
        DeviceEventEmitter.emit("teamSelected", {
          team: { id: data.team.id, name: data.team.name },
        });
      }

      // Proceed to profile setup
      router.push("/onboarding/player/profile-setup");
    } catch (e) {
      console.error("Join team error:", e);
      setError(e?.message || "Could not join team. Please try again.");
    } finally {
      setJoining(false);
    }
  };

  const handleCreateTeam = () => {
    router.replace("/onboarding/role-selection");
  };

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingHorizontal: 16,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 32,
            }}
          >
            <TouchableOpacity
              style={{
                width: 44,
                height: 44,
                backgroundColor: colors.surface,
                borderRadius: 22,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={() => router.back()}
            >
              <ArrowLeft size={24} color={colors.mainText} />
            </TouchableOpacity>

            <View style={{ alignItems: "center" }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.secondaryText,
                }}
              >
                Step 1 of 2
              </Text>
              <View style={{ flexDirection: "row", gap: 4, marginTop: 4 }}>
                <View
                  style={{
                    width: 20,
                    height: 4,
                    backgroundColor: colors.primary,
                    borderRadius: 2,
                  }}
                />
                <View
                  style={{
                    width: 20,
                    height: 4,
                    backgroundColor: colors.border,
                    borderRadius: 2,
                  }}
                />
              </View>
            </View>

            <View style={{ width: 44 }} />
          </View>

          {/* Content */}
          <View style={{ marginBottom: 40 }}>
            <View
              style={{
                width: 80,
                height: 80,
                backgroundColor: colors.success + "20",
                borderRadius: 40,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 24,
                alignSelf: "center",
              }}
            >
              <Users size={40} color={colors.success} />
            </View>

            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 28,
                color: colors.mainText,
                marginBottom: 12,
                textAlign: "center",
              }}
            >
              Join your team
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.secondaryText,
                textAlign: "center",
                lineHeight: 24,
                paddingHorizontal: 20,
              }}
            >
              Enter the team code provided by your coach to join your team
            </Text>
          </View>

          {/* Team Code Input */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Team Code
            </Text>
            <View style={{ position: "relative" }}>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderWidth: 2,
                  borderColor: teamFound
                    ? colors.success
                    : error
                      ? colors.alert
                      : colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  paddingRight: 48,
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 18,
                  color: colors.mainText,
                  textAlign: "center",
                  letterSpacing: 2,
                }}
                placeholder="ENTER CODE"
                placeholderTextColor={colors.secondaryText}
                value={teamCode}
                onChangeText={handleTeamCodeChange}
                onFocus={handleInputFocus}
                onBlur={handleInputBlur}
                autoCapitalize="characters"
                autoCorrect={false}
                maxLength={12}
              />

              {/* Status Icon */}
              <View
                style={{
                  position: "absolute",
                  right: 16,
                  top: "50%",
                  marginTop: -12,
                }}
              >
                {isValidating && (
                  <View
                    style={{
                      width: 24,
                      height: 24,
                      borderWidth: 2,
                      borderColor: colors.primary,
                      borderTopColor: "transparent",
                      borderRadius: 12,
                    }}
                  />
                )}
                {teamFound && (
                  <View
                    style={{
                      width: 24,
                      height: 24,
                      backgroundColor: colors.success,
                      borderRadius: 12,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Check size={16} color="white" />
                  </View>
                )}
                {error && (
                  <View
                    style={{
                      width: 24,
                      height: 24,
                      backgroundColor: colors.alert,
                      borderRadius: 12,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <AlertCircle size={16} color="white" />
                  </View>
                )}
              </View>
            </View>

            {/* Error Message */}
            {error && (
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 14,
                  color: colors.alert,
                  marginTop: 8,
                  textAlign: "center",
                }}
              >
                {error}
              </Text>
            )}
          </View>

          {/* Team Found Card */}
          {teamFound && (
            <View
              style={{
                backgroundColor: colors.success + "10",
                borderRadius: 16,
                padding: 20,
                marginBottom: 32,
                borderWidth: 1,
                borderColor: colors.success + "30",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 16,
                }}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    backgroundColor: colors.success,
                    borderRadius: 20,
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <Check size={20} color="white" />
                </View>
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 18,
                    color: colors.success,
                  }}
                >
                  Team Found!
                </Text>
              </View>

              <View style={{ marginBottom: 12 }}>
                <Text
                  style={{
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 20,
                    color: colors.mainText,
                    marginBottom: 4,
                  }}
                >
                  {teamFound.name}
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 16,
                    color: colors.secondaryText,
                  }}
                >
                  {teamFound.sport} • {teamFound.ageGroup}
                </Text>
              </View>

              <View style={{ gap: 4 }}>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 14,
                    color: colors.secondaryText,
                  }}
                >
                  Coach: {teamFound.coach}
                </Text>
                <Text
                  style={{
                    fontFamily: "Inter_400Regular",
                    fontSize: 14,
                    color: colors.secondaryText,
                  }}
                >
                  Location: {teamFound.location}
                </Text>
              </View>
            </View>
          )}

          {/* Help Section */}
          <View
            style={{
              backgroundColor: colors.lavender,
              borderRadius: 12,
              padding: 16,
              marginBottom: 32,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.mainText,
                marginBottom: 8,
              }}
            >
              Don't have a team code?
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
                lineHeight: 20,
                marginBottom: 12,
              }}
            >
              Ask your coach for the team code, or if you're a coach, create
              your own team instead.
            </Text>
            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                borderRadius: 8,
                paddingHorizontal: 16,
                paddingVertical: 8,
                alignSelf: "flex-start",
              }}
              onPress={handleCreateTeam}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: "white",
                }}
              >
                Create a Team Instead
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

        {/* Continue Button */}
        <Animated.View
          style={{
            paddingBottom: paddingAnimation,
            paddingHorizontal: 16,
            paddingTop: 16,
            backgroundColor: colors.background,
            borderTopWidth: 1,
            borderTopColor: colors.border,
          }}
        >
          <TouchableOpacity
            style={{
              backgroundColor: teamFound ? colors.primary : colors.border,
              borderRadius: 16,
              padding: 18,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              opacity: teamFound ? 1 : 0.5,
            }}
            onPress={handleJoinTeam}
            disabled={!teamFound || joining}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: teamFound ? "white" : colors.secondaryText,
                marginRight: 8,
              }}
            >
              {joining ? "Joining..." : "Join Team"}
            </Text>
            <ArrowRight
              size={20}
              color={teamFound ? "white" : colors.secondaryText}
            />
          </TouchableOpacity>
        </Animated.View>
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
