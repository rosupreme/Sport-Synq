import { Redirect } from "expo-router";

export default function OnboardingIndex() {
  // When navigating to /onboarding, send users to the first real onboarding screen.
  return <Redirect href="/onboarding/role-selection" />;
}
