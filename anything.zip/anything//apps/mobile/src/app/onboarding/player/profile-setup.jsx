import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft, ArrowRight, User } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { fetchWithAuth } from "@/utils/api";

export default function PlayerProfileSetup() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();

  const [playerName, setPlayerName] = useState("");
  const [parentEmail, setParentEmail] = useState("");
  const [teamData, setTeamData] = useState(null);
  const [loading, setLoading] = useState(true);

  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  // Load team data on mount
  useEffect(() => {
    loadTeamData();
  }, []);

  const loadTeamData = async () => {
    try {
      setLoading(true);
      const teamId = await AsyncStorage.getItem("selected_team_id");

      if (teamId) {
        // Fetch full team details from API
        const response = await fetchWithAuth(`/api/teams?teamId=${teamId}`);
        if (response?.team) {
          setTeamData(response.team);
        }
      }
    } catch (error) {
      console.error("Error loading team data:", error);
      // Set default if error
      setTeamData({ name: "your team", sport: "Soccer" });
    } finally {
      setLoading(false);
    }
  };

  if ((!fontsLoaded && !fontError) || loading) {
    return (
      <ScreenWrapper>
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </ScreenWrapper>
    );
  }

  const isFormValid = playerName.trim();

  const handleComplete = async () => {
    if (isFormValid) {
      try {
        // Save player profile to backend
        const teamId = await AsyncStorage.getItem("selected_team_id");
        if (teamId) {
          await fetchWithAuth("/api/players", {
            method: "POST",
            body: JSON.stringify({
              teamId: parseInt(teamId),
              parentEmail: parentEmail || null,
            }),
          });
        }

        await AsyncStorage.setItem("onboarding_complete", "true");
        router.replace("/(tabs)/dashboard");
      } catch (error) {
        console.error("Error saving player profile:", error);
        // Continue anyway even if error
        await AsyncStorage.setItem("onboarding_complete", "true");
        router.replace("/(tabs)/dashboard");
      }
    }
  };

  return (
    <ScreenWrapper>
      <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 100,
            paddingHorizontal: 16,
          }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 32,
            }}
          >
            <TouchableOpacity
              style={{
                width: 44,
                height: 44,
                backgroundColor: colors.surface,
                borderRadius: 22,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={() => router.back()}
            >
              <ArrowLeft size={24} color={colors.mainText} />
            </TouchableOpacity>

            <View style={{ alignItems: "center" }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.secondaryText,
                }}
              >
                Step 2 of 2
              </Text>
              <View style={{ flexDirection: "row", gap: 4, marginTop: 4 }}>
                <View
                  style={{
                    width: 20,
                    height: 4,
                    backgroundColor: colors.primary,
                    borderRadius: 2,
                  }}
                />
                <View
                  style={{
                    width: 20,
                    height: 4,
                    backgroundColor: colors.primary,
                    borderRadius: 2,
                  }}
                />
              </View>
            </View>

            <View style={{ width: 44 }} />
          </View>

          {/* Content */}
          <View style={{ marginBottom: 40 }}>
            <View
              style={{
                width: 80,
                height: 80,
                backgroundColor: colors.primary + "20",
                borderRadius: 40,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 24,
                alignSelf: "center",
              }}
            >
              <User size={40} color={colors.primary} />
            </View>

            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 28,
                color: colors.mainText,
                marginBottom: 12,
                textAlign: "center",
              }}
            >
              Set up your profile
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 16,
                color: colors.secondaryText,
                textAlign: "center",
                lineHeight: 24,
                paddingHorizontal: 20,
              }}
            >
              Complete your player profile to join{" "}
              {teamData?.name || "the team"}
            </Text>
          </View>

          {/* Form */}
          <View>
            {/* Player Name */}
            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Your Name *
              </Text>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                }}
                placeholder="Enter your full name"
                placeholderTextColor={colors.secondaryText}
                value={playerName}
                onChangeText={setPlayerName}
              />
            </View>

            {/* Parent/Guardian Email */}
            <View style={{ marginBottom: 32 }}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.mainText,
                  marginBottom: 8,
                }}
              >
                Parent/Guardian Email
              </Text>
              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  fontFamily: "Inter_400Regular",
                  fontSize: 16,
                  color: colors.mainText,
                }}
                placeholder="parent@email.com"
                placeholderTextColor={colors.secondaryText}
                value={parentEmail}
                onChangeText={setParentEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 12,
                  color: colors.secondaryText,
                  marginTop: 4,
                }}
              >
                For team updates and important notifications (for players under
                18)
              </Text>
            </View>
          </View>
        </ScrollView>

        {/* Complete Button */}
        <View
          style={{
            paddingBottom: insets.bottom + 12,
            paddingHorizontal: 16,
            paddingTop: 16,
            backgroundColor: colors.background,
            borderTopWidth: 1,
            borderTopColor: colors.border,
          }}
        >
          <TouchableOpacity
            style={{
              backgroundColor: isFormValid ? colors.primary : colors.border,
              borderRadius: 16,
              padding: 18,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              opacity: isFormValid ? 1 : 0.5,
            }}
            onPress={handleComplete}
            disabled={!isFormValid}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: isFormValid ? "white" : colors.secondaryText,
                marginRight: 8,
              }}
            >
              Complete Setup
            </Text>
            <ArrowRight
              size={20}
              color={isFormValid ? "white" : colors.secondaryText}
            />
          </TouchableOpacity>

          <View
            style={{
              backgroundColor: colors.success + "10",
              borderRadius: 12,
              padding: 12,
              marginTop: 16,
              alignItems: "center",
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.success,
                textAlign: "center",
              }}
            >
              🎉 You're joining {teamData?.name || "the team"}!
            </Text>
          </View>
        </View>
      </KeyboardAvoidingAnimatedView>
    </ScreenWrapper>
  );
}
