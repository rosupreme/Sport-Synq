import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import Carousel from "react-native-reanimated-carousel";
import {
  User,
  Users,
  UsersRound,
  Check,
  ArrowRight,
  X,
  CheckCircle,
  Calendar,
  BarChart3,
  MessageSquare,
  Shield,
  Star,
  Zap,
  Trophy,
  Crown,
  Headphones,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from "@expo-google-fonts/inter";
import ScreenWrapper from "@/components/ScreenWrapper";
import useInAppPurchase from "@/hooks/useInAppPurchase";

// Colors matching SwiftUI design
const TEAL = "#33BAA3";
const BLUE_PRIMARY = "#1F75FA";
const BLUE_DARK = "#0D59E6";

const PLAN_CONFIG = {
  standard: {
    name: "Standard",
    subtitle: "Perfect for getting started",
    teamCount: "1 Team",
    icon: User,
    badge: null,
    features: [
      { icon: Users, text: "Up to 20 players" },
      { icon: Calendar, text: "Unlimited events" },
      { icon: BarChart3, text: "Player evaluations" },
      { icon: MessageSquare, text: "Team messaging" },
    ],
  },
  plus: {
    name: "Plus",
    subtitle: "Best for growing coaches",
    teamCount: "Up to 3 Teams",
    icon: Users,
    badge: "MOST POPULAR",
    features: [
      { icon: Users, text: "Up to 25 players per team" },
      { icon: Star, text: "Priority support" },
      { icon: BarChart3, text: "Advanced analytics" },
      { icon: Zap, text: "All Standard features" },
    ],
  },
  pro: {
    name: "Pro",
    subtitle: "For serious organizations",
    teamCount: "Up to 10 Teams",
    icon: UsersRound,
    badge: "BEST VALUE",
    features: [
      { icon: Trophy, text: "Unlimited players" },
      { icon: Crown, text: "White-label branding" },
      { icon: Headphones, text: "Dedicated support" },
      { icon: Shield, text: "All Plus features" },
    ],
  },
};

function PlanCard({ pkg, planKey, isActive, cardHeight }) {
  const config = PLAN_CONFIG[planKey] || PLAN_CONFIG.standard;
  const IconComponent = config.icon;
  const price = pkg.product.priceString;

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "white",
        borderRadius: 28,
        borderWidth: isActive ? 3 : 1,
        borderColor: isActive ? BLUE_PRIMARY : "rgba(0,0,0,0.08)",
        padding: 24,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 12 },
        shadowOpacity: isActive ? 0.15 : 0.08,
        shadowRadius: isActive ? 24 : 16,
        elevation: isActive ? 12 : 6,
        height: cardHeight,
      }}
    >
      {/* Badge */}
      {config.badge && (
        <View
          style={{
            position: "absolute",
            top: -14,
            alignSelf: "center",
            left: 0,
            right: 0,
            alignItems: "center",
          }}
        >
          <View
            style={{
              backgroundColor: planKey === "plus" ? TEAL : BLUE_PRIMARY,
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 999,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_700Bold",
                fontSize: 12,
                color: "white",
                letterSpacing: 0.5,
              }}
            >
              {config.badge}
            </Text>
          </View>
        </View>
      )}

      {/* Icon */}
      <View
        style={{
          width: 72,
          height: 72,
          borderRadius: 36,
          backgroundColor: BLUE_PRIMARY + "15",
          alignItems: "center",
          justifyContent: "center",
          alignSelf: "center",
          marginTop: config.badge ? 16 : 8,
          marginBottom: 16,
        }}
      >
        <IconComponent size={32} color={BLUE_PRIMARY} strokeWidth={2} />
      </View>

      {/* Plan name */}
      <Text
        style={{
          fontFamily: "Inter_700Bold",
          fontSize: 28,
          color: "#1a1a1a",
          textAlign: "center",
          marginBottom: 4,
        }}
      >
        {config.name}
      </Text>

      {/* Subtitle */}
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 14,
          color: "#666",
          textAlign: "center",
          marginBottom: 8,
        }}
      >
        {config.subtitle}
      </Text>

      {/* Team count badge */}
      <View
        style={{
          backgroundColor: TEAL + "20",
          paddingHorizontal: 16,
          paddingVertical: 6,
          borderRadius: 999,
          alignSelf: "center",
          marginBottom: 16,
        }}
      >
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 13,
            color: TEAL,
          }}
        >
          {config.teamCount}
        </Text>
      </View>

      {/* Price */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "baseline",
          justifyContent: "center",
          marginBottom: 20,
        }}
      >
        <Text
          style={{
            fontFamily: "Inter_700Bold",
            fontSize: 42,
            color: BLUE_PRIMARY,
          }}
        >
          {price}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_600SemiBold",
            fontSize: 16,
            color: "#666",
            marginLeft: 4,
          }}
        >
          /month
        </Text>
      </View>

      {/* Divider */}
      <View
        style={{
          height: 1,
          backgroundColor: "rgba(0,0,0,0.08)",
          marginBottom: 20,
        }}
      />

      {/* Features */}
      <View style={{ gap: 14 }}>
        {config.features.map((feature, index) => {
          const FeatureIcon = feature.icon;
          return (
            <View
              key={index}
              style={{ flexDirection: "row", alignItems: "center" }}
            >
              <View
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: 14,
                  backgroundColor: TEAL + "15",
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 12,
                }}
              >
                <FeatureIcon size={14} color={TEAL} strokeWidth={2.5} />
              </View>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 15,
                  color: "#333",
                  flex: 1,
                }}
              >
                {feature.text}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

function PaginationDots({ total, activeIndex }) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 8,
      }}
    >
      {Array.from({ length: total }).map((_, index) => (
        <View
          key={index}
          style={{
            width: index === activeIndex ? 24 : 8,
            height: 8,
            borderRadius: 4,
            backgroundColor:
              index === activeIndex ? BLUE_PRIMARY : "rgba(0,0,0,0.15)",
          }}
        />
      ))}
    </View>
  );
}

function Bullet({ text }) {
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "rgba(255,255,255,0.7)",
        paddingVertical: 8,
        paddingHorizontal: 14,
        borderRadius: 999,
      }}
    >
      <CheckCircle size={16} color={TEAL} strokeWidth={2.5} />
      <Text
        style={{
          fontFamily: "Inter_600SemiBold",
          fontSize: 13,
          color: "#444",
          marginLeft: 8,
        }}
      >
        {text}
      </Text>
    </View>
  );
}

export default function SubscriptionSelection() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { width, height } = useWindowDimensions();

  const [activeIndex, setActiveIndex] = useState(1); // Start on Plus (middle)
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);
  const [packages, setPackages] = useState([]);
  const carouselRef = useRef(null);

  const { isReady, getAvailableSubscriptions, startSubscription } =
    useInAppPurchase();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    loadPackages();
  }, [isReady]);

  const loadPackages = async () => {
    if (!isReady) return;

    try {
      setLoading(true);
      const availablePackages = getAvailableSubscriptions();

      // Filter to custom plans (Standard, Plus, Pro)
      const customPlans = (availablePackages || []).filter((pkg) => {
        const id = pkg.identifier.toLowerCase();
        return (
          id.includes("standard") || id.includes("plus") || id.includes("pro")
        );
      });

      // Sort: Standard, Plus, Pro
      const sortedPackages = customPlans.sort((a, b) => {
        const getOrder = (identifier) => {
          const id = identifier.toLowerCase();
          if (id.includes("standard")) return 0;
          if (id.includes("plus")) return 1;
          if (id.includes("pro")) return 2;
          return 999;
        };
        return getOrder(a.identifier) - getOrder(b.identifier);
      });

      setPackages(sortedPackages);

      // Auto-select Plus (index 1)
      if (sortedPackages.length > 1) {
        setSelectedPackage(sortedPackages[1]);
        setActiveIndex(1);
      } else if (sortedPackages.length > 0) {
        setSelectedPackage(sortedPackages[0]);
        setActiveIndex(0);
      }
    } catch (error) {
      console.error("Error loading packages:", error);
      setPackages([]);
    } finally {
      setLoading(false);
    }
  };

  const getPlanKey = (pkg) => {
    const id = pkg.identifier.toLowerCase();
    if (id.includes("standard")) return "standard";
    if (id.includes("plus")) return "plus";
    if (id.includes("pro")) return "pro";
    return "standard";
  };

  const handleSnapToItem = useCallback(
    (index) => {
      if (index !== activeIndex) {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
      setActiveIndex(index);
      if (packages[index]) {
        setSelectedPackage(packages[index]);
      }
    },
    [activeIndex, packages],
  );

  const handleContinue = async () => {
    if (!selectedPackage) {
      Alert.alert(
        "No Plan Selected",
        "Please select a subscription plan to continue.",
      );
      return;
    }

    try {
      setPurchasing(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      const success = await startSubscription({
        subscription: selectedPackage,
      });

      if (success) {
        router.push("/onboarding/coach/team-setup");
      }
    } catch (error) {
      if (error.userCancelled) {
        console.log("User cancelled purchase");
      } else {
        console.error("Error purchasing subscription:", error);
        Alert.alert(
          "Purchase Error",
          "There was an error processing your subscription. Please try again.",
          [{ text: "OK", style: "cancel" }],
        );
      }
    } finally {
      setPurchasing(false);
    }
  };

  const handleClose = () => {
    router.back();
  };

  if (!fontsLoaded) {
    return null;
  }

  // Calculate card dimensions
  const cardWidth = width * 0.85;
  const cardHeight = height * 0.58;

  const selectedPlanName = selectedPackage
    ? PLAN_CONFIG[getPlanKey(selectedPackage)]?.name || "Plan"
    : "Plan";

  if (loading) {
    return (
      <ScreenWrapper>
        <LinearGradient
          colors={["#F0F4FF", "#E6EFFF"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <ActivityIndicator size="large" color={BLUE_PRIMARY} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: "#666",
              marginTop: 16,
            }}
          >
            Loading plans...
          </Text>
        </LinearGradient>
      </ScreenWrapper>
    );
  }

  if (packages.length === 0) {
    return (
      <ScreenWrapper>
        <LinearGradient
          colors={["#F0F4FF", "#E6EFFF"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingHorizontal: 32,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 20,
              color: "#1a1a1a",
              marginBottom: 12,
              textAlign: "center",
            }}
          >
            No Plans Available
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: "#666",
              textAlign: "center",
              marginBottom: 24,
            }}
          >
            Unable to load subscription plans. Please try again or continue to
            set up your team.
          </Text>
          <TouchableOpacity
            onPress={() => router.push("/onboarding/coach/team-setup")}
          >
            <LinearGradient
              colors={[BLUE_PRIMARY, BLUE_DARK]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                paddingVertical: 14,
                paddingHorizontal: 32,
                borderRadius: 16,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 16,
                  color: "white",
                }}
              >
                Continue Anyway
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>
      </ScreenWrapper>
    );
  }

  return (
    <ScreenWrapper>
      <LinearGradient
        colors={["#F0F4FF", "#E6EFFF"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 12,
            paddingHorizontal: 20,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View style={{ width: 36 }} />
          <Text
            style={{
              fontFamily: "Inter_700Bold",
              fontSize: 18,
              color: "#1a1a1a",
            }}
          >
            Choose Your Plan
          </Text>
          <TouchableOpacity
            onPress={handleClose}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={{
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: "rgba(0,0,0,0.06)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <X size={18} color="#666" />
          </TouchableOpacity>
        </View>

        {/* Subtitle */}
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 15,
            color: "#666",
            textAlign: "center",
            marginTop: 8,
            marginBottom: 20,
          }}
        >
          Swipe to compare plans
        </Text>

        {/* Carousel */}
        <View style={{ flex: 1 }}>
          <Carousel
            ref={carouselRef}
            data={packages}
            width={width}
            height={cardHeight}
            defaultIndex={1}
            loop={false}
            mode="parallax"
            modeConfig={{
              parallaxScrollingScale: 0.88,
              parallaxScrollingOffset: 50,
            }}
            onSnapToItem={handleSnapToItem}
            renderItem={({ item, index }) => (
              <View
                style={{
                  flex: 1,
                  justifyContent: "center",
                  alignItems: "center",
                  paddingHorizontal: (width - cardWidth) / 2,
                }}
              >
                <PlanCard
                  pkg={item}
                  planKey={getPlanKey(item)}
                  isActive={index === activeIndex}
                  cardHeight={cardHeight}
                />
              </View>
            )}
          />
        </View>

        {/* Bottom section */}
        <View
          style={{
            paddingHorizontal: 20,
            paddingBottom: insets.bottom + 20,
          }}
        >
          {/* Pagination */}
          <View style={{ marginBottom: 16 }}>
            <PaginationDots total={packages.length} activeIndex={activeIndex} />
          </View>

          {/* Bullets */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "center",
              flexWrap: "wrap",
              gap: 10,
              marginBottom: 16,
            }}
          >
            <Bullet text="7-day free trial" />
            <Bullet text="Cancel anytime" />
          </View>

          {/* CTA Button */}
          <TouchableOpacity
            onPress={handleContinue}
            activeOpacity={0.9}
            disabled={purchasing}
            style={{ opacity: purchasing ? 0.7 : 1 }}
          >
            <LinearGradient
              colors={[BLUE_PRIMARY, BLUE_DARK]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 16,
                borderRadius: 16,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 10 },
                shadowOpacity: 0.2,
                shadowRadius: 14,
                elevation: 6,
              }}
            >
              {purchasing ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <>
                  <Text
                    style={{
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 17,
                      color: "white",
                      marginRight: 10,
                    }}
                  >
                    Start {selectedPlanName} Free Trial
                  </Text>
                  <ArrowRight size={18} color="white" strokeWidth={2.5} />
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>

          {/* Footer note */}
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 12,
              color: "#888",
              textAlign: "center",
              marginTop: 12,
            }}
          >
            No charge until your 7-day free trial ends
          </Text>
        </View>
      </LinearGradient>
    </ScreenWrapper>
  );
}
