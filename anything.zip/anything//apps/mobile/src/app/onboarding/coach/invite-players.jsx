import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Share,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import {
  ArrowLeft,
  Users,
  Share2,
  MessageSquare,
  Mail,
  Copy,
  Check,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import * as Clipboard from "expo-clipboard";
import AsyncStorage from "@react-native-async-storage/async-storage";
// ADD: use authenticated helper so Authorization header is sent
import { fetchWithAuth } from "@/utils/api";
import useInAppPurchase from "@/hooks/useInAppPurchase";

export default function CoachInvitePlayers() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const params = useLocalSearchParams();
  const { colors, isDark } = useTheme();
  const [copiedCode, setCopiedCode] = useState(false);
  const [teamCode, setTeamCode] = useState("");
  const [isCreatingTeam, setIsCreatingTeam] = useState(false);
  const [teamCreated, setTeamCreated] = useState(false);
  const { initiateInAppPurchase } = useInAppPurchase();

  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  // Create team when component loads
  useEffect(() => {
    const createTeam = async () => {
      if (teamCreated || !params.teamName) return;

      setIsCreatingTeam(true);

      try {
        // Create a real team using authenticated endpoint
        const data = await fetchWithAuth("/api/teams", {
          method: "POST",
          body: JSON.stringify({
            name: params.teamName,
            sport: params.sport || "Soccer",
            season: params.season || "2024-25",
          }),
        });

        const team = data?.team;
        if (team?.id) {
          setTeamCreated(true);
          // Use the invite code returned from the API
          setTeamCode(team.invite_code || "");

          // Store team info for later use and mark it as selected
          await AsyncStorage.setItem("current_team", JSON.stringify(team));
          await AsyncStorage.setItem("selected_team_id", String(team.id));

          // Refresh subscription status now that user is a coach
          console.log("✅ Team created, refreshing subscription status...");
          await initiateInAppPurchase();
        }
      } catch (error) {
        console.error("Error creating team:", error);
        console.error("Error details:", {
          name: error?.name || "Unknown",
          message: error?.message || "No message",
          stack: error?.stack?.substring(0, 500) || "No stack trace",
        });

        Alert.alert(
          "Error Creating Team",
          `Failed to create team: ${error.message || "Unknown error"}. Please try again or contact support.`,
          [
            {
              text: "Try Again",
              onPress: () => {
                setTeamCreated(false);
                setIsCreatingTeam(false);
              },
            },
            {
              text: "Skip for Now",
              onPress: () => router.replace("/(tabs)/dashboard"),
              style: "cancel",
            },
          ],
        );
      } finally {
        setIsCreatingTeam(false);
      }
    };

    if (params.teamName && !teamCreated) {
      createTeam();
    }
  }, [params.teamName, teamCreated, initiateInAppPurchase]);

  if (!fontsLoaded && !fontError) {
    return null;
  }

  // Show loading state while creating team
  if (isCreatingTeam || !teamCode) {
    const displayTeamName = params.teamName || "your team";
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingHorizontal: 16,
          }}
        >
          <View
            style={{
              width: 80,
              height: 80,
              backgroundColor: colors.primary + "20",
              borderRadius: 40,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 24,
            }}
          >
            <Users size={40} color={colors.primary} />
          </View>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: colors.mainText,
              marginBottom: 12,
              textAlign: "center",
            }}
          >
            Creating your team...
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
              lineHeight: 24,
            }}
          >
            {`Please wait while we set up ${displayTeamName}`}
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  const handleCopyCode = async () => {
    await Clipboard.setStringAsync(teamCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleShare = async () => {
    try {
      const teamName = params.teamName || "our team";
      await Share.share({
        message: `Join our team! Use code: ${teamCode}\n\nDownload the team management app and enter this code to join the ${teamName} team.`,
        title: "Join Our Team",
      });
    } catch (error) {
      console.error("Error sharing:", error);
    }
  };

  const handleSkip = async () => {
    try {
      await AsyncStorage.setItem("onboarding_complete", "true");
      router.replace("/(tabs)/dashboard");
    } catch (error) {
      console.error("Error saving onboarding status:", error);
      router.replace("/(tabs)/dashboard");
    }
  };

  const handleAddPlayers = () => {
    router.push("/add-player");
  };

  const InviteOption = ({ icon: Icon, title, description, onPress, color }) => (
    <TouchableOpacity
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 20,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: colors.border,
        flexDirection: "row",
        alignItems: "center",
      }}
      onPress={onPress}
    >
      <View
        style={{
          width: 48,
          height: 48,
          backgroundColor: color + "20",
          borderRadius: 24,
          alignItems: "center",
          justifyContent: "center",
          marginRight: 16,
        }}
      >
        <Icon size={24} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 16,
            color: colors.mainText,
            marginBottom: 4,
          }}
        >
          {title}
        </Text>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: colors.secondaryText,
            lineHeight: 20,
          }}
        >
          {description}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenWrapper>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 32,
          }}
        >
          <TouchableOpacity
            style={{
              width: 44,
              height: 44,
              backgroundColor: colors.surface,
              borderRadius: 22,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color={colors.mainText} />
          </TouchableOpacity>

          <View style={{ alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              Step 2 of 2
            </Text>
            <View style={{ flexDirection: "row", gap: 4, marginTop: 4 }}>
              <View
                style={{
                  width: 20,
                  height: 4,
                  backgroundColor: colors.primary,
                  borderRadius: 2,
                }}
              />
              <View
                style={{
                  width: 20,
                  height: 4,
                  backgroundColor: colors.primary,
                  borderRadius: 2,
                }}
              />
            </View>
          </View>

          <TouchableOpacity onPress={handleSkip}>
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 16,
                color: colors.secondaryText,
              }}
            >
              Skip
            </Text>
          </TouchableOpacity>
        </View>

        {/* Content */}
        <View style={{ marginBottom: 40 }}>
          <View
            style={{
              width: 80,
              height: 80,
              backgroundColor: colors.success + "20",
              borderRadius: 40,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 24,
              alignSelf: "center",
            }}
          >
            <Users size={40} color={colors.success} />
          </View>

          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 28,
              color: colors.mainText,
              marginBottom: 12,
              textAlign: "center",
            }}
          >
            Invite your players
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 16,
              color: colors.secondaryText,
              textAlign: "center",
              lineHeight: 24,
              paddingHorizontal: 20,
            }}
          >
            Share your team code with players so they can join your team
          </Text>
        </View>

        {/* Team Code */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 24,
            marginBottom: 32,
            borderWidth: 1,
            borderColor: colors.border,
            alignItems: "center",
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.secondaryText,
              marginBottom: 8,
            }}
          >
            Your Team Code
          </Text>

          <View
            style={{
              backgroundColor: colors.primary + "10",
              borderRadius: 12,
              paddingHorizontal: 20,
              paddingVertical: 12,
              marginBottom: 16,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 24,
                color: colors.primary,
                letterSpacing: 2,
              }}
            >
              {teamCode}
            </Text>
          </View>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: colors.primary,
              borderRadius: 12,
              paddingHorizontal: 16,
              paddingVertical: 10,
            }}
            onPress={handleCopyCode}
          >
            {copiedCode ? (
              <Check size={16} color="white" style={{ marginRight: 6 }} />
            ) : (
              <Copy size={16} color="white" style={{ marginRight: 6 }} />
            )}
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: "white",
              }}
            >
              {copiedCode ? "Copied!" : "Copy Code"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Invite Options */}
        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 20,
              color: colors.mainText,
              marginBottom: 16,
            }}
          >
            How to invite players
          </Text>

          <InviteOption
            icon={Share2}
            title="Share Team Code"
            description="Send the team code via text, email, or social media"
            onPress={handleShare}
            color={colors.primary}
          />

          <InviteOption
            icon={MessageSquare}
            title="Share via Messages"
            description="Send a message with the team code to your players"
            onPress={handleShare}
            color={colors.success}
          />

          <InviteOption
            icon={Mail}
            title="Email Invitation"
            description="Send an email invitation with the team code"
            onPress={handleShare}
            color={colors.purple}
          />

          <InviteOption
            icon={Users}
            title="Add Players Manually"
            description="Add players directly to your team roster"
            onPress={handleAddPlayers}
            color={colors.alert}
          />
        </View>

        {/* Instructions */}
        <View
          style={{
            backgroundColor: colors.lavender,
            borderRadius: 12,
            padding: 16,
            marginBottom: 32,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            How it works:
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
              lineHeight: 20,
            }}
          >
            1. Share your team code with players{"\n"}
            2. Players download the app and create an account{"\n"}
            3. Players enter your team code to join{"\n"}
            4. You'll receive a notification when they join
          </Text>
        </View>

        {/* Continue Button */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.primary,
            borderRadius: 16,
            padding: 18,
            alignItems: "center",
            marginBottom: 16,
          }}
          onPress={handleSkip}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: "white",
            }}
          >
            Get Started
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={{
            alignItems: "center",
            padding: 12,
          }}
          onPress={handleSkip}
        >
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.secondaryText,
            }}
          >
            I'll invite players later
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenWrapper>
  );
}
