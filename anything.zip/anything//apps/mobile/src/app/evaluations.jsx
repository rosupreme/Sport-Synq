import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Modal,
  FlatList,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  ArrowLeft,
  Filter,
  Search,
  Plus,
  User,
  Calendar,
  FileText,
  Eye,
  Edit3,
  ChevronDown,
} from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import { useTheme } from "@/components/ThemeProvider";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useDashboardData } from "@/hooks/useDashboardData";
import { useUser } from "@/utils/auth/useUser";
import { fetchWithAuth } from "@/utils/api";

export default function Evaluations() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors, isDark } = useTheme();
  const { selectedTeam } = useDashboardData();
  const { data: user } = useUser();
  const userRole = selectedTeam?.user_role; // 'Coach' | 'Player'
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [evaluations, setEvaluations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  useEffect(() => {
    fetchEvaluations();
  }, [selectedTeam?.id, user?.id, userRole]);

  const fetchEvaluations = async () => {
    try {
      setIsLoading(true);
      if (!selectedTeam?.id) {
        setEvaluations([]);
        setIsLoading(false);
        return;
      }
      let url = `/api/evaluations?teamId=${selectedTeam.id}`;
      // Players only see their own evaluations
      if (userRole === "Player" && user?.id) {
        url += `&playerId=${user.id}`;
      }
      const data = await fetchWithAuth(url);

      if (data.success) {
        const formattedEvaluations = data.evaluations.map((evaluation) => ({
          id: evaluation.id.toString(),
          playerId: evaluation.player_id.toString(),
          playerName: evaluation.player_name,
          playerPosition: evaluation.position || "Player",
          evaluationType: evaluation.evaluation_type,
          season: evaluation.season,
          status: evaluation.status,
          createdAt: evaluation.created_at,
          overallScore: calculateOverallScore(evaluation),
          technicalAverage: calculateTechnicalAverage(evaluation),
          mentalPhysicalAverage: calculateMentalPhysicalAverage(evaluation),
          coachName: evaluation.coach_name,
        }));
        setEvaluations(formattedEvaluations);
      } else {
        throw new Error(data.error || "API returned success: false");
      }
    } catch (error) {
      console.error("Error fetching evaluations:", error);
      Alert.alert("Error", `Failed to load evaluations: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateOverallScore = (evaluation) => {
    const scores = [
      evaluation.ball_control,
      evaluation.passing,
      evaluation.shooting,
      evaluation.defending,
      evaluation.fitness_level,
      evaluation.teamwork,
      evaluation.attitude,
      evaluation.leadership,
    ];
    return scores.reduce((sum, score) => sum + score, 0) / scores.length;
  };

  const calculateTechnicalAverage = (evaluation) => {
    return (
      (evaluation.ball_control +
        evaluation.passing +
        evaluation.shooting +
        evaluation.defending) /
      4
    );
  };

  const calculateMentalPhysicalAverage = (evaluation) => {
    return (
      (evaluation.fitness_level +
        evaluation.teamwork +
        evaluation.attitude +
        evaluation.leadership) /
      4
    );
  };

  if (!fontsLoaded) {
    return null;
  }

  const filterOptions = [
    { id: "all", label: "All Evaluations", count: evaluations.length },
    {
      id: "submitted",
      label: "Submitted",
      count: evaluations.filter((e) => e.status === "submitted").length,
    },
    {
      id: "draft",
      label: "Drafts",
      count: evaluations.filter((e) => e.status === "draft").length,
    },
    {
      id: "mid_season",
      label: "Mid-Season",
      count: evaluations.filter((e) => e.evaluationType === "mid_season")
        .length,
    },
    {
      id: "monthly",
      label: "Monthly",
      count: evaluations.filter((e) => e.evaluationType === "monthly").length,
    },
  ];

  const getFilteredEvaluations = () => {
    switch (selectedFilter) {
      case "submitted":
        return evaluations.filter((e) => e.status === "submitted");
      case "draft":
        return evaluations.filter((e) => e.status === "draft");
      case "mid_season":
        return evaluations.filter((e) => e.evaluationType === "mid_season");
      case "monthly":
        return evaluations.filter((e) => e.evaluationType === "monthly");
      default:
        return evaluations;
    }
  };

  const getScoreColor = (score) => {
    if (score >= 8) return colors.success;
    if (score >= 6) return colors.warning;
    return colors.error;
  };

  const getEvaluationTypeLabel = (type) => {
    switch (type) {
      case "mid_season":
        return "Mid-Season";
      case "end_season":
        return "End of Season";
      case "monthly":
        return "Monthly";
      default:
        return type;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const handleViewEvaluation = (evaluationId) => {
    router.push(`/evaluation-details?evaluationId=${evaluationId}`);
  };

  const handleEditEvaluation = (evaluation) => {
    router.push(
      `/player-evaluation?playerId=${evaluation.playerId}&evaluationId=${evaluation.id}`,
    );
  };

  const handleNewEvaluation = () => {
    router.push("/player-evaluation?playerId=2");
  };

  const EvaluationCard = ({ evaluation }) => (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 16,
        marginBottom: 16,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      {/* Header */}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: 12,
        }}
      >
        <View style={{ flex: 1, marginRight: 12 }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
              marginBottom: 4,
            }}
          >
            {evaluation.playerName}
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 14,
              color: colors.secondaryText,
              marginBottom: 8,
            }}
          >
            {evaluation.playerPosition}
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {" "}
              • {getEvaluationTypeLabel(evaluation.evaluationType)}
            </Text>
          </Text>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Calendar size={14} color={colors.secondaryText} />
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 13,
                color: colors.secondaryText,
                marginLeft: 6,
              }}
            >
              {formatDate(evaluation.createdAt)}
            </Text>
          </View>
        </View>

        <View style={{ alignItems: "flex-end" }}>
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 24,
              color: getScoreColor(evaluation.overallScore),
              marginBottom: 4,
            }}
          >
            {evaluation.overallScore.toFixed(1)}
          </Text>
          <View
            style={{
              backgroundColor:
                evaluation.status === "submitted"
                  ? colors.success + "20"
                  : colors.warning + "20",
              borderRadius: 12,
              paddingHorizontal: 8,
              paddingVertical: 4,
              marginBottom: 8,
            }}
          >
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 11,
                color:
                  evaluation.status === "submitted"
                    ? colors.success
                    : colors.warning,
                textTransform: "uppercase",
                letterSpacing: 0.5,
              }}
            >
              {evaluation.status}
            </Text>
          </View>
        </View>
      </View>

      {/* Score Breakdown */}
      <View
        style={{
          backgroundColor: colors.background,
          borderRadius: 12,
          padding: 16,
          marginBottom: 16,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            marginBottom: 12,
          }}
        >
          <View style={{ alignItems: "center", flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: getScoreColor(evaluation.technicalAverage),
                marginBottom: 4,
              }}
            >
              {evaluation.technicalAverage.toFixed(1)}
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 12,
                color: colors.secondaryText,
                textAlign: "center",
              }}
            >
              Technical Skills
            </Text>
          </View>
          <View style={{ alignItems: "center", flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: getScoreColor(evaluation.mentalPhysicalAverage),
                marginBottom: 4,
              }}
            >
              {evaluation.mentalPhysicalAverage.toFixed(1)}
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 12,
                color: colors.secondaryText,
                textAlign: "center",
              }}
            >
              Mental/Physical
            </Text>
          </View>
        </View>

        {/* Progress Bar */}
        <View
          style={{
            height: 6,
            backgroundColor: colors.border,
            borderRadius: 3,
            overflow: "hidden",
          }}
        >
          <View
            style={{
              height: "100%",
              width: `${(evaluation.overallScore / 10) * 100}%`,
              backgroundColor: getScoreColor(evaluation.overallScore),
              borderRadius: 3,
            }}
          />
        </View>
      </View>

      {/* Coach Info */}
      <View
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 16 }}
      >
        <View
          style={{
            width: 24,
            height: 24,
            backgroundColor: colors.primary + "20",
            borderRadius: 12,
            alignItems: "center",
            justifyContent: "center",
            marginRight: 8,
          }}
        >
          <Text style={{ fontSize: 12 }}>👨‍🏫</Text>
        </View>
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 13,
            color: colors.secondaryText,
          }}
        >
          Evaluated by {evaluation.coachName}
        </Text>
      </View>

      {/* Actions */}
      <View style={{ flexDirection: "row", gap: 12 }}>
        <TouchableOpacity
          style={{
            backgroundColor: colors.primary,
            borderRadius: 12,
            padding: 12,
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
          }}
          onPress={() => handleViewEvaluation(evaluation.id)}
        >
          <Eye size={16} color={colors.onPrimary} style={{ marginRight: 6 }} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 14,
              color: colors.onPrimary,
            }}
          >
            View
          </Text>
        </TouchableOpacity>

        {userRole === "Coach" && (
          <TouchableOpacity
            style={{
              backgroundColor: colors.surface,
              borderRadius: 12,
              padding: 12,
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
            onPress={() => handleEditEvaluation(evaluation)}
          >
            <Edit3
              size={16}
              color={colors.mainText}
              style={{ marginRight: 6 }}
            />
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.mainText,
              }}
            >
              Edit
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  const FilterModal = () => (
    <Modal
      visible={showFilterModal}
      transparent={true}
      animationType="slide"
      onRequestClose={() => setShowFilterModal(false)}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        <View
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingBottom: insets.bottom + 20,
            maxHeight: "80%",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: colors.border,
            }}
          >
            <TouchableOpacity onPress={() => setShowFilterModal(false)}>
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 16,
                  color: colors.secondaryText,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 17,
                color: colors.mainText,
              }}
            >
              Filter Evaluations
            </Text>
            <View style={{ width: 60 }} />
          </View>

          <ScrollView style={{ paddingHorizontal: 20, paddingTop: 20 }}>
            {filterOptions.map((option) => (
              <TouchableOpacity
                key={option.id}
                style={{
                  backgroundColor: colors.background,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor:
                    selectedFilter === option.id
                      ? colors.primary
                      : colors.border,
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
                onPress={() => {
                  setSelectedFilter(option.id);
                  setShowFilterModal(false);
                }}
              >
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 16,
                    color:
                      selectedFilter === option.id
                        ? colors.primary
                        : colors.mainText,
                  }}
                >
                  {option.label}
                </Text>
                <View
                  style={{
                    backgroundColor:
                      selectedFilter === option.id
                        ? colors.primary + "20"
                        : colors.surface,
                    borderRadius: 12,
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                  }}
                >
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 12,
                      color:
                        selectedFilter === option.id
                          ? colors.primary
                          : colors.secondaryText,
                    }}
                  >
                    {option.count}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  const filteredEvaluations = getFilteredEvaluations();
  const currentFilterLabel =
    filterOptions.find((f) => f.id === selectedFilter)?.label ||
    "All Evaluations";

  // Show loading state
  if (isLoading) {
    return (
      <ScreenWrapper>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: insets.top + 20,
          }}
        >
          <ActivityIndicator size="large" color={colors.primary} />
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.secondaryText,
              marginTop: 16,
            }}
          >
            Loading evaluations...
          </Text>
        </View>
      </ScreenWrapper>
    );
  }

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1, alignItems: "center" }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
              }}
            >
              Evaluations
            </Text>
          </View>

          <View style={{ flexDirection: "row", gap: 8 }}>
            <TouchableOpacity
              style={{
                backgroundColor: colors.surface,
                borderRadius: 20,
                paddingHorizontal: 12,
                paddingVertical: 8,
                flexDirection: "row",
                alignItems: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
              onPress={fetchEvaluations}
              disabled={isLoading}
            >
              <Text
                style={{
                  fontFamily: "Inter_500Medium",
                  fontSize: 14,
                  color: colors.mainText,
                }}
              >
                Refresh
              </Text>
            </TouchableOpacity>

            {/* Only coaches can create new evaluations */}
            {userRole === "Coach" && (
              <TouchableOpacity
                style={{
                  backgroundColor: colors.primary,
                  borderRadius: 20,
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                  flexDirection: "row",
                  alignItems: "center",
                }}
                onPress={handleNewEvaluation}
              >
                <Plus
                  size={16}
                  color={colors.onPrimary}
                  style={{ marginRight: 6 }}
                />
                <Text
                  style={{
                    fontFamily: "Inter_500Medium",
                    fontSize: 14,
                    color: colors.onPrimary,
                  }}
                >
                  New
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Filter Bar */}
        <View style={{ flexDirection: "row", gap: 12 }}>
          <TouchableOpacity
            style={{
              backgroundColor: colors.surface,
              borderRadius: 12,
              paddingHorizontal: 16,
              paddingVertical: 12,
              flexDirection: "row",
              alignItems: "center",
              borderWidth: 1,
              borderColor: colors.border,
              flex: 1,
            }}
            onPress={() => setShowFilterModal(true)}
          >
            <Filter
              size={16}
              color={colors.secondaryText}
              style={{ marginRight: 8 }}
            />
            <Text
              style={{
                fontFamily: "Inter_500Medium",
                fontSize: 14,
                color: colors.mainText,
                flex: 1,
              }}
            >
              {currentFilterLabel}
            </Text>
            <ChevronDown size={16} color={colors.secondaryText} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Content */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={fetchEvaluations}
            colors={[colors.primary]}
            tintColor={colors.primary}
          />
        }
      >
        {/* Summary */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            padding: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: 12,
            }}
          >
            Evaluation Summary
          </Text>
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ alignItems: "center", flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 24,
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                {filteredEvaluations.length}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 13,
                  color: colors.secondaryText,
                  textAlign: "center",
                }}
              >
                Total
              </Text>
            </View>
            <View style={{ alignItems: "center", flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 24,
                  color: colors.success,
                  marginBottom: 4,
                }}
              >
                {
                  filteredEvaluations.filter((e) => e.status === "submitted")
                    .length
                }
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 13,
                  color: colors.secondaryText,
                  textAlign: "center",
                }}
              >
                Submitted
              </Text>
            </View>
            <View style={{ alignItems: "center", flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 24,
                  color: colors.warning,
                  marginBottom: 4,
                }}
              >
                {filteredEvaluations.filter((e) => e.status === "draft").length}
              </Text>
              <Text
                style={{
                  fontFamily: "Inter_400Regular",
                  fontSize: 13,
                  color: colors.secondaryText,
                  textAlign: "center",
                }}
              >
                Drafts
              </Text>
            </View>
          </View>
        </View>

        {/* Evaluations List */}
        {filteredEvaluations.length > 0 ? (
          filteredEvaluations.map((evaluation) => (
            <EvaluationCard key={evaluation.id} evaluation={evaluation} />
          ))
        ) : (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 32,
              alignItems: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <FileText
              size={48}
              color={colors.secondaryText}
              style={{ marginBottom: 16 }}
            />
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 18,
                color: colors.mainText,
                marginBottom: 8,
                textAlign: "center",
              }}
            >
              No Evaluations Found
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
                textAlign: "center",
                marginBottom: 20,
              }}
            >
              {selectedFilter === "all"
                ? userRole === "Coach"
                  ? "Start by creating your first player evaluation."
                  : "No evaluations available yet."
                : `No evaluations match the current filter: ${currentFilterLabel}`}
            </Text>
            {userRole === "Coach" && (
              <TouchableOpacity
                style={{
                  backgroundColor: colors.primary,
                  borderRadius: 20,
                  paddingHorizontal: 20,
                  paddingVertical: 12,
                  flexDirection: "row",
                  alignItems: "center",
                }}
                onPress={
                  selectedFilter === "all"
                    ? handleNewEvaluation
                    : () => setSelectedFilter("all")
                }
              >
                {selectedFilter === "all" ? (
                  <>
                    <Plus
                      size={16}
                      color={colors.onPrimary}
                      style={{ marginRight: 8 }}
                    />
                    <Text
                      style={{
                        fontFamily: "Inter_500Medium",
                        fontSize: 14,
                        color: colors.onPrimary,
                      }}
                    >
                      Create Evaluation
                    </Text>
                  </>
                ) : (
                  <Text
                    style={{
                      fontFamily: "Inter_500Medium",
                      fontSize: 14,
                      color: colors.onPrimary,
                    }}
                  >
                    Show All Evaluations
                  </Text>
                )}
              </TouchableOpacity>
            )}
          </View>
        )}
      </ScrollView>

      <FilterModal />
    </ScreenWrapper>
  );
}
