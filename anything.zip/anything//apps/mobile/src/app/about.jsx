import React from "react";
import { View, Text, TouchableOpacity, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import Constants from "expo-constants";
import { ArrowLeft, Shield, ChevronRight, FileText } from "lucide-react-native";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
} from "@expo-google-fonts/inter";
import ScreenWrapper from "@/components/ScreenWrapper";
import { useTheme } from "@/components/ThemeProvider";
import { useLanguage } from "@/components/LanguageProvider";

function getAppVersionLabel(fallbackLabel) {
  const expoConfig = Constants.expoConfig;
  const version = expoConfig?.version;
  const buildNumber = expoConfig?.ios?.buildNumber;
  const androidVersionCode = expoConfig?.android?.versionCode;

  if (version && buildNumber) {
    return `v${version} (${buildNumber})`;
  }
  if (version && androidVersionCode) {
    return `v${version} (${androidVersionCode})`;
  }
  if (version) {
    return `v${version}`;
  }
  return fallbackLabel;
}

export default function About() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { colors } = useTheme();
  const { t } = useLanguage();

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const versionLabel = getAppVersionLabel(t("version"));

  const Row = ({ icon: Icon, title, subtitle, onPress, isLast }) => {
    return (
      <TouchableOpacity
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 16,
          borderBottomWidth: isLast ? 0 : 1,
          borderBottomColor: colors.border,
        }}
        onPress={onPress}
        disabled={!onPress}
      >
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            backgroundColor: colors.primary + "15",
            alignItems: "center",
            justifyContent: "center",
            marginRight: 12,
          }}
        >
          <Icon size={20} color={colors.primary} />
        </View>

        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 16,
              color: colors.mainText,
              marginBottom: subtitle ? 2 : 0,
            }}
          >
            {title}
          </Text>
          {subtitle ? (
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {subtitle}
            </Text>
          ) : null}
        </View>

        <ChevronRight size={20} color={colors.secondaryText} />
      </TouchableOpacity>
    );
  };

  return (
    <ScreenWrapper>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <TouchableOpacity
            style={{
              width: 40,
              height: 40,
              backgroundColor: colors.lavender,
              borderRadius: 20,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 16,
            }}
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 24,
                color: colors.mainText,
                marginBottom: 4,
              }}
            >
              {t("about")}
            </Text>
            <Text
              style={{
                fontFamily: "Inter_400Regular",
                fontSize: 14,
                color: colors.secondaryText,
              }}
            >
              {versionLabel}
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: 20,
          paddingBottom: insets.bottom + 40,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* App summary */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            borderWidth: 1,
            borderColor: colors.border,
            padding: 16,
            marginBottom: 20,
          }}
        >
          <Text
            style={{
              fontFamily: "Inter_600SemiBold",
              fontSize: 18,
              color: colors.mainText,
              marginBottom: 8,
            }}
          >
            Sport-Synq
          </Text>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 15,
              lineHeight: 22,
              color: colors.bodyText,
            }}
          >
            A simple way to run your team: schedule events, track attendance,
            manage players, and stay on top of fundraising.
          </Text>
        </View>

        {/* Links */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            borderWidth: 1,
            borderColor: colors.border,
            overflow: "hidden",
          }}
        >
          <Row
            icon={FileText}
            title="Terms of Service"
            subtitle="The rules for using the app"
            onPress={() => router.push("/terms")}
          />
          <Row
            icon={Shield}
            title="Privacy Policy"
            subtitle="How we handle your data"
            onPress={() => router.push("/privacy-policy")}
            isLast
          />
        </View>

        {/* Footer */}
        <View style={{ marginTop: 20 }}>
          <Text
            style={{
              fontFamily: "Inter_400Regular",
              fontSize: 12,
              lineHeight: 18,
              color: colors.secondaryText,
              textAlign: "center",
            }}
          >
            Thanks for using Sport-Synq.
          </Text>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}
