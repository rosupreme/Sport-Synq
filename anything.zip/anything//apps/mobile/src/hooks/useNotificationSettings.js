import { useCallback } from "react";
import { Alert, Platform } from "react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import * as Notifications from "expo-notifications";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { fetchWithAuth } from "@/utils/api";

async function enablePushOnDevice() {
  try {
    // Skip push notifications on web platform
    if (Platform.OS === "web") {
      console.log("Push notifications are not supported on web platform");
      return null;
    }

    if (Platform.OS === "android") {
      await Notifications.setNotificationChannelAsync("default", {
        name: "default",
        importance: Notifications.AndroidImportance.DEFAULT,
      });
    }

    let permission = await Notifications.getPermissionsAsync();
    if (permission.status !== "granted") {
      permission = await Notifications.requestPermissionsAsync();
    }

    if (permission.status !== "granted") {
      Alert.alert(
        "Permission needed",
        "Please allow notifications in your device settings to enable push notifications.",
      );
      return null;
    }

    const token = (await Notifications.getExpoPushTokenAsync()).data;
    await AsyncStorage.setItem("expo_push_token", token);
    return token;
  } catch (e) {
    console.error("Failed to enable push notifications", e);
    Alert.alert("Error", "Could not enable push notifications on this device.");
    return null;
  }
}

export default function useNotificationSettings() {
  const queryClient = useQueryClient();

  const { data, isLoading, error } = useQuery({
    queryKey: ["notification-settings"],
    queryFn: async () => {
      const res = await fetchWithAuth("/api/user/notifications-mobile");
      return res.settings;
    },
    enabled: Platform.OS !== "web", // Push notifications are not supported on web
    retry: false,
  });

  const mutation = useMutation({
    mutationFn: async (payload) => {
      return fetchWithAuth("/api/user/notifications-mobile", {
        method: "POST",
        body: JSON.stringify(payload),
      });
    },
    onMutate: async (updates) => {
      await queryClient.cancelQueries({ queryKey: ["notification-settings"] });
      const prev = queryClient.getQueryData(["notification-settings"]);

      queryClient.setQueryData(["notification-settings"], (current) => {
        const curr = current || {};
        const currSettings = curr.settings || curr; // in case shape differs
        const next = { ...currSettings };
        if (typeof updates.pushEnabled === "boolean")
          next.pushEnabled = updates.pushEnabled;
        if (typeof updates.emailEnabled === "boolean")
          next.emailEnabled = updates.emailEnabled;
        if (typeof updates.gameRemindersEnabled === "boolean")
          next.gameRemindersEnabled = updates.gameRemindersEnabled;
        if (Object.prototype.hasOwnProperty.call(updates, "expoPushToken"))
          next.expoPushToken = updates.expoPushToken ?? null;
        return next;
      });

      return { prev };
    },
    onError: (err, _updates, context) => {
      console.error("Failed to update notification settings", err);
      if (context?.prev) {
        queryClient.setQueryData(["notification-settings"], context.prev);
      }
      Alert.alert("Error", "Failed to update notification settings.");
    },
    onSuccess: (res) => {
      queryClient.setQueryData(["notification-settings"], res.settings);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["notification-settings"] });
    },
  });

  const togglePush = useCallback(
    async (value) => {
      if (value) {
        const token = await enablePushOnDevice();
        if (!token) return; // do not flip if no token
        mutation.mutate({ pushEnabled: true, expoPushToken: token });
      } else {
        try {
          await AsyncStorage.removeItem("expo_push_token");
        } catch (e) {}
        mutation.mutate({ pushEnabled: false, expoPushToken: null });
      }
    },
    [mutation],
  );

  const toggleEmail = useCallback(
    (value) => {
      mutation.mutate({ emailEnabled: value });
    },
    [mutation],
  );

  const toggleGame = useCallback(
    (value) => {
      mutation.mutate({ gameRemindersEnabled: value });
    },
    [mutation],
  );

  return {
    settings: data || {
      pushEnabled: false,
      emailEnabled: false,
      gameRemindersEnabled: false,
      expoPushToken: null,
    },
    isLoading,
    error,
    togglePush,
    toggleEmail,
    toggleGame,
    updating: mutation.isLoading,
  };
}
