import { useState, useEffect } from "react";
import { Alert } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  formatDate,
  formatTime,
  convertDateToDbFormat,
  convertTimeToDbFormat,
} from "@/utils/datetime";
import { DeviceEventEmitter } from "react-native";
import { fetchWithAuth } from "@/utils/api";

export function useAddEvent() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const isEditMode = params.edit === "true" && params.id;
  const eventId = params.id;

  const [isLoading, setIsLoading] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [loadingTeam, setLoadingTeam] = useState(true);

  const [eventData, setEventData] = useState({
    title: "",
    date: "",
    time: "",
    location: "",
    description: "",
    type: "practice",
    team_id: null,
    rawDate: "",
  });

  // Recurring event state
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurrenceType, setRecurrenceType] = useState("weekly");
  const [occurrences, setOccurrences] = useState(10);

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState({
    hour: 9,
    minute: 0,
    period: "AM",
  });

  useEffect(() => {
    loadSelectedTeam();
  }, []);

  useEffect(() => {
    if (isEditMode && eventId) {
      loadExistingEvent();
    }
  }, [isEditMode, eventId]);

  const loadExistingEvent = async () => {
    try {
      setIsLoading(true);

      // Fetch all events and find the one we're editing
      const response = await fetchWithAuth("/api/events");
      const events = response.events || [];
      const event = events.find((e) => e.id.toString() === eventId.toString());

      if (!event) {
        Alert.alert("Error", "Event not found");
        router.back();
        return;
      }

      // Helper to format time from DB (HH:MM:SS) to display format
      const formatTimeFromDb = (timeString) => {
        if (!timeString) return "";
        const [hours, minutes] = timeString.split(":");
        const hour24 = parseInt(hours);
        const period = hour24 >= 12 ? "PM" : "AM";
        const hour12 = hour24 === 0 ? 12 : hour24 > 12 ? hour24 - 12 : hour24;
        return `${hour12}:${minutes.padStart(2, "0")} ${period}`;
      };

      // Helper to convert DB time to selectedTime format
      const parseDbTime = (timeString) => {
        if (!timeString) return { hour: 9, minute: 0, period: "AM" };
        const [hours, minutes] = timeString.split(":");
        const hour24 = parseInt(hours);
        const period = hour24 >= 12 ? "PM" : "AM";
        const hour12 = hour24 === 0 ? 12 : hour24 > 12 ? hour24 - 12 : hour24;
        return { hour: hour12, minute: parseInt(minutes), period };
      };

      // Pre-populate form with existing event data
      setEventData({
        title: event.title || "",
        date: formatDate(event.event_date),
        time: formatTimeFromDb(event.event_time),
        location: event.location || "",
        description: event.description || "",
        type: event.event_type || "practice",
        team_id: event.team_id,
        rawDate: event.event_date.split("T")[0], // Extract YYYY-MM-DD
      });

      setSelectedDate(event.event_date.split("T")[0]);
      setSelectedTime(parseDbTime(event.event_time));
    } catch (error) {
      console.error("Error loading event:", error);
      Alert.alert("Error", "Failed to load event details");
      router.back();
    } finally {
      setIsLoading(false);
    }
  };

  const loadSelectedTeam = async () => {
    try {
      setLoadingTeam(true);

      // Get the selected team from AsyncStorage (same as dashboard)
      const savedTeamId = await AsyncStorage.getItem("selected_team_id");

      // Always fetch teams with auth
      const data = await fetchWithAuth(`/api/teams`);
      const teams = data.teams || [];

      if (savedTeamId) {
        // Find the selected team
        const team = teams.find((t) => t.id.toString() === savedTeamId);

        if (team) {
          setSelectedTeam(team);
          // Only update team_id if not in edit mode (event already has a team)
          if (!isEditMode) {
            updateEventData("team_id", team.id);
          }
        } else {
          // Fallback to first team if saved team not found
          if (teams.length > 0) {
            setSelectedTeam(teams[0]);
            if (!isEditMode) {
              updateEventData("team_id", teams[0].id);
            }
          } else {
            Alert.alert(
              "Error",
              "No teams available. Please create a team first.",
            );
            router.back();
          }
        }
      } else {
        // No saved team, use first one if available
        if (teams.length > 0) {
          setSelectedTeam(teams[0]);
          if (!isEditMode) {
            updateEventData("team_id", teams[0].id);
          }
          // Save this as the selected team for future
          await AsyncStorage.setItem(
            "selected_team_id",
            teams[0].id.toString(),
          );
        } else {
          Alert.alert(
            "Error",
            "No teams available. Please create a team first.",
          );
          router.back();
        }
      }
    } catch (error) {
      console.error("Error loading selected team:", error);
      Alert.alert(
        "Error",
        "Failed to load team information. Please try again.",
      );
      router.back();
    } finally {
      setLoadingTeam(false);
    }
  };

  const updateEventData = (field, value) => {
    setEventData((prev) => ({ ...prev, [field]: value }));
  };

  const handleDateSelect = (day) => {
    setSelectedDate(day.dateString);
    updateEventData("date", formatDate(day.dateString));
    updateEventData("rawDate", day.dateString);
    setShowDatePicker(false);
  };

  const handleTimeSelect = () => {
    const timeString = formatTime(selectedTime);
    updateEventData("time", timeString);
    setShowTimePicker(false);
  };

  const handleSaveEvent = async () => {
    console.log("🚀 Starting event save process...");
    console.log("Edit mode:", isEditMode);
    console.log("Event data:", eventData);

    if (!eventData.title.trim()) {
      Alert.alert("Error", "Please enter an event title");
      return;
    }
    if (!eventData.date.trim()) {
      Alert.alert("Error", "Please select an event date");
      return;
    }
    if (!eventData.time.trim()) {
      Alert.alert("Error", "Please select an event time");
      return;
    }
    if (!eventData.team_id) {
      Alert.alert("Error", "Please select a team");
      return;
    }

    setIsLoading(true);

    try {
      if (isEditMode) {
        // UPDATE existing event
        const requestBody = {
          title: eventData.title.trim(),
          description: eventData.description.trim() || null,
          event_type: eventData.type,
          event_date:
            eventData.rawDate || convertDateToDbFormat(eventData.date),
          event_time: convertTimeToDbFormat(eventData.time),
          location: eventData.location.trim() || null,
        };

        console.log("📤 Updating event with body:", requestBody);

        const responseData = await fetchWithAuth(`/api/events/${eventId}`, {
          method: "PUT",
          body: JSON.stringify(requestBody),
        });

        console.log("✅ Event updated successfully!", responseData);

        DeviceEventEmitter.emit("eventUpdated", {
          event: responseData.event,
          teamId: eventData.team_id,
        });

        Alert.alert("Success", "Event updated successfully!", [
          { text: "OK", onPress: () => router.back() },
        ]);
      } else {
        // CREATE new event
        const requestBody = {
          title: eventData.title.trim(),
          description: eventData.description.trim() || null,
          event_type: eventData.type,
          event_date:
            eventData.rawDate || convertDateToDbFormat(eventData.date),
          event_time: convertTimeToDbFormat(eventData.time),
          location: eventData.location.trim() || null,
          team_id: eventData.team_id,
          is_recurring: isRecurring,
          recurrence_type: isRecurring ? recurrenceType : null,
          occurrences: isRecurring ? occurrences : null,
        };

        console.log("📤 Creating event with body:", requestBody);

        const responseData = await fetchWithAuth(`/api/events`, {
          method: "POST",
          body: JSON.stringify(requestBody),
        });

        console.log("✅ Event(s) created successfully!", responseData);

        DeviceEventEmitter.emit("eventCreated", {
          event: responseData.event || responseData.events,
          teamId: eventData.team_id,
        });

        const successMessage = isRecurring
          ? `${occurrences} recurring events created successfully!`
          : "Event created successfully!";

        Alert.alert("Success", successMessage, [
          { text: "OK", onPress: () => router.back() },
        ]);
      }
    } catch (error) {
      console.error("❌ Error saving event:", error);
      Alert.alert(
        "Error",
        `Failed to ${isEditMode ? "update" : "create"} event: ${error.message}`,
      );
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    selectedTeam,
    loadingTeam,
    eventData,
    updateEventData,
    showDatePicker,
    setShowDatePicker,
    showTimePicker,
    setShowTimePicker,
    selectedDate,
    selectedTime,
    setSelectedTime,
    handleDateSelect,
    handleTimeSelect,
    handleSaveEvent,
    isRecurring,
    setIsRecurring,
    recurrenceType,
    setRecurrenceType,
    occurrences,
    setOccurrences,
    isEditMode, // Export this so header can use it
  };
}
