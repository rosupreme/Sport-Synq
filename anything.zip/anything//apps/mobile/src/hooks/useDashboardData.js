import { useState, useEffect, useCallback, useRef } from "react";
import { DeviceEventEmitter } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { fetchWithAuth } from "@/utils/api";
import { useAuth } from "@/utils/auth/useAuth";

export function useDashboardData() {
  const { isReady: authReady, isAuthenticated } = useAuth();
  const [nextEvent, setNextEvent] = useState(null);
  const [fundraisers, setFundraisers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [teams, setTeams] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [loadingTeams, setLoadingTeams] = useState(true);

  // Use refs to store stable function references
  const fetchFundraisersRef = useRef();
  const fetchNextEventRef = useRef();

  const fetchFundraisers = useCallback(async () => {
    try {
      console.log("DEBUG: Dashboard fetching fundraisers...");

      // Build URL with teamId if a team is selected
      let url = `/api/fundraisers`;
      if (selectedTeam?.id) {
        url += `?teamId=${selectedTeam.id}`;
        console.log("DEBUG: Fetching fundraisers for team:", selectedTeam.id);
      }

      const data = await fetchWithAuth(url);
      console.log("DEBUG: Dashboard response data:", data);
      console.log("DEBUG: Dashboard fundraisers array:", data.fundraisers);
      setFundraisers(data.fundraisers || []);
      console.log(
        "DEBUG: Dashboard set fundraisers state to:",
        data.fundraisers || [],
      );
    } catch (error) {
      console.error("Dashboard error fetching fundraisers:", error);
    }
  }, [selectedTeam?.id]);

  const fetchNextEvent = useCallback(async () => {
    try {
      console.log("DEBUG: Fetching events from API...");

      // Build URL with teamId if a team is selected
      let url = `/api/events`;
      if (selectedTeam?.id) {
        url += `?teamId=${selectedTeam.id}`;
        console.log("DEBUG: Fetching events for team:", selectedTeam.id);
      }

      const data = await fetchWithAuth(url);
      console.log("DEBUG: Response data:", JSON.stringify(data, null, 2));

      // The API returns { events: [...] }
      const events = data.events || [];
      console.log("DEBUG: Found", events.length, "events");

      // Find the next upcoming event
      const now = new Date();
      console.log("DEBUG: Current time:", now.toISOString());

      const upcomingEvents = events
        .filter((event) => {
          // Use the same parsing logic as the schedule page
          const eventDate = event.event_date.split("T")[0]; // Convert from ISO to YYYY-MM-DD
          const eventTime = event.event_time;
          const eventDateTime = new Date(`${eventDate}T${eventTime}`);
          const isFuture = eventDateTime > now;

          console.log(
            `DEBUG: Event "${event.title}" - Date: ${eventDate}, Time: ${eventTime}, DateTime: ${eventDateTime.toISOString()}, Is future: ${isFuture}`,
          );

          return isFuture;
        })
        .sort((a, b) => {
          const aDate = a.event_date.split("T")[0];
          const bDate = b.event_date.split("T")[0];
          const aDateTime = new Date(`${aDate}T${a.event_time}`);
          const bDateTime = new Date(`${bDate}T${b.event_time}`);
          return aDateTime - bDateTime;
        });

      console.log("DEBUG: Found", upcomingEvents.length, "upcoming events");
      if (upcomingEvents.length > 0) {
        console.log(
          "DEBUG: Next event:",
          JSON.stringify(upcomingEvents[0], null, 2),
        );
        setNextEvent(upcomingEvents[0]);
      } else {
        console.log("DEBUG: No upcoming events found");
        setNextEvent(null);
      }
    } catch (error) {
      console.error("DEBUG: Error fetching events:", error);
      setNextEvent(null);
    } finally {
      setLoading(false);
    }
  }, [selectedTeam?.id]);

  // Update refs when functions change
  useEffect(() => {
    fetchFundraisersRef.current = fetchFundraisers;
    fetchNextEventRef.current = fetchNextEvent;
  }, [fetchFundraisers, fetchNextEvent]);

  const fetchTeams = useCallback(async () => {
    // Don't fetch if auth isn't ready or user isn't authenticated
    if (!authReady || !isAuthenticated) {
      console.log(
        "[useDashboardData] Skipping fetchTeams - auth not ready or not authenticated",
      );
      return;
    }

    try {
      // Use authenticated fetch
      const data = await fetchWithAuth(`/api/teams`);
      setTeams(data.teams || []);

      // Try to load previously selected team from storage
      const savedTeamId = await AsyncStorage.getItem("selected_team_id");
      if (savedTeamId && data.teams) {
        const savedTeam = data.teams.find(
          (t) => t.id.toString() === savedTeamId,
        );
        if (savedTeam) {
          setSelectedTeam(savedTeam);
        } else if (data.teams.length > 0) {
          // Fallback to first team if saved team not found
          setSelectedTeam(data.teams[0]);
          await AsyncStorage.setItem(
            "selected_team_id",
            data.teams[0].id.toString(),
          );
        }
      } else if (data.teams.length > 0) {
        // Select first team if no saved selection
        setSelectedTeam(data.teams[0]);
        await AsyncStorage.setItem(
          "selected_team_id",
          data.teams[0].id.toString(),
        );
      }
    } catch (error) {
      console.error("Error fetching teams:", error);
    } finally {
      setLoadingTeams(false);
    }
  }, [authReady, isAuthenticated]);

  const handleTeamSelect = useCallback(
    async (team) => {
      setSelectedTeam(team);
      await AsyncStorage.setItem("selected_team_id", team.id.toString());

      // Broadcast selection so other tabs update immediately
      DeviceEventEmitter.emit("teamSelected", { team });

      // Refresh data for the new team using refs
      await Promise.all([
        fetchNextEventRef.current?.(),
        fetchFundraisersRef.current?.(),
      ]);
    },
    [], // Remove the function dependencies to prevent infinite loops
  );

  // Fetch teams when auth becomes ready
  useEffect(() => {
    let isMounted = true;

    const fetchData = async () => {
      if (!isMounted) return;

      // Wait for auth to be ready and authenticated
      if (!authReady || !isAuthenticated) {
        return;
      }

      try {
        await fetchTeams();
      } catch (error) {
        console.error("Dashboard fetch error:", error);
        if (isMounted) {
          setLoading(false);
          setLoadingTeams(false);
        }
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [authReady, isAuthenticated, fetchTeams]); // Trigger when auth becomes ready

  // NEW: Refresh teams and select the newly created team when emitted
  useEffect(() => {
    const sub = DeviceEventEmitter.addListener(
      "teamCreated",
      async ({ team }) => {
        try {
          if (team?.id) {
            await AsyncStorage.setItem("selected_team_id", String(team.id));
          }
          await fetchTeams();
          if (team?.id) {
            setSelectedTeam(team);
          }
        } catch (e) {
          console.error("Failed handling teamCreated event:", e);
        }
      },
    );
    return () => sub.remove();
  }, []); // Remove fetchTeams dependency

  // NEW: Listen for team selection changes across tabs so all screens stay in sync
  useEffect(() => {
    const sub = DeviceEventEmitter.addListener(
      "teamSelected",
      async ({ team }) => {
        try {
          if (team?.id) {
            await AsyncStorage.setItem("selected_team_id", String(team.id));
            setSelectedTeam(team);
            // Refresh data relevant to dashboard context using refs
            await Promise.all([
              fetchNextEventRef.current?.(),
              fetchFundraisersRef.current?.(),
            ]);
          }
        } catch (e) {
          console.error("Failed handling teamSelected event:", e);
        }
      },
    );
    return () => sub.remove();
  }, []); // Remove function dependencies

  // Fetch events and fundraisers when selectedTeam changes
  useEffect(() => {
    if (selectedTeam) {
      console.log(
        "DEBUG: Selected team changed, fetching data for team:",
        selectedTeam.id,
      );
      Promise.all([
        fetchNextEventRef.current?.(),
        fetchFundraisersRef.current?.(),
      ]);
    }
  }, [selectedTeam]); // Only depend on selectedTeam

  // Listen for new events being created
  useEffect(() => {
    const subscription = DeviceEventEmitter.addListener(
      "eventCreated",
      (data) => {
        console.log("🔄 Event created, refreshing dashboard data...");
        // Only refresh events and fundraisers, not teams using refs
        Promise.all([
          fetchNextEventRef.current?.(),
          fetchFundraisersRef.current?.(),
        ]);
      },
    );

    return () => subscription.remove();
  }, []); // Remove function dependencies

  return {
    nextEvent,
    fundraisers,
    loading,
    teams,
    selectedTeam,
    loadingTeams,
    handleTeamSelect,
  };
}
