import { useState, useEffect } from "react";

export function useFeedback() {
  const [feedbackList, setFeedbackList] = useState([]);
  const [loadingFeedback, setLoadingFeedback] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState("all");

  const fetchFeedback = async () => {
    try {
      setLoadingFeedback(true);
      const response = await fetch("/api/feedback");
      if (!response.ok) throw new Error("Failed to fetch feedback");
      const data = await response.json();
      setFeedbackList(data.feedback || []);
    } catch (error) {
      console.error("Error fetching feedback:", error);
    } finally {
      setLoadingFeedback(false);
    }
  };

  const handleVote = async (feedbackId) => {
    try {
      const response = await fetch(`/api/feedback/${feedbackId}/vote`, {
        method: "POST",
      });

      if (!response.ok) throw new Error("Failed to vote");

      await fetchFeedback();
    } catch (error) {
      console.error("Error voting:", error);
      throw error;
    }
  };

  const filteredFeedback =
    selectedFilter === "all"
      ? feedbackList
      : feedbackList.filter((item) => item.feedback_type === selectedFilter);

  useEffect(() => {
    fetchFeedback();
  }, []);

  return {
    feedbackList,
    loadingFeedback,
    selectedFilter,
    setSelectedFilter,
    filteredFeedback,
    handleVote,
    fetchFeedback,
  };
}
