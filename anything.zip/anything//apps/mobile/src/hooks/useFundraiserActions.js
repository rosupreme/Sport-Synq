import { Alert } from "react-native";
import { useRouter } from "expo-router";
import { useAuth } from "@/utils/auth/useAuth";
import { fetchWithAuth } from "@/utils/api";

export default function useFundraiserActions(auth, fetchFundraisers) {
  const router = useRouter();
  const { signIn } = useAuth();

  const parseJsonSafely = async (response) => {
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      try {
        return await response.json();
      } catch (_) {
        return null;
      }
    }
    return null;
  };

  const handleUpdateProgress = async (
    fundraiserId,
    updateAmount,
    updateNote,
  ) => {
    // Sanitize input to accept values like "$200", "200.00", "200"
    const cleaned = String(updateAmount).replace(/[^0-9.-]/g, "");
    const amountNumber = Math.round(parseFloat(cleaned));
    if (!amountNumber || amountNumber <= 0 || Number.isNaN(amountNumber)) {
      return { success: false, error: "Please enter a valid amount" };
    }

    console.log("DEBUG: Auth state check:", {
      auth: auth,
      authJwt: auth?.jwt,
      authKeys: auth ? Object.keys(auth) : "auth is null/undefined",
    });

    console.log(
      "DEBUG: Starting update progress with auth token:",
      auth.jwt ? "Present" : "Missing",
    );
    console.log("DEBUG: Update amount (cleaned):", amountNumber);
    console.log("DEBUG: Selected fundraiser ID:", fundraiserId);
    console.log("DEBUG: Full API URL:", `/api/fundraisers/${fundraiserId}`);

    try {
      const requestBody = {
        amount: amountNumber,
        note: updateNote,
        contributor_name: updateNote || "Manual Update",
      };

      const result = await fetchWithAuth(`/api/fundraisers/${fundraiserId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      });

      console.log("DEBUG: Update success:", result);
      await fetchFundraisers();
      return { success: true };
    } catch (error) {
      console.error("Error updating fundraiser:", error);
      if (error?.status === 401) {
        Alert.alert("Session expired", "Please sign in again.", [
          { text: "Cancel", style: "cancel" },
          { text: "Sign In", onPress: () => signIn() },
        ]);
        return { success: false, error: "Unauthorized" };
      }
      const message = error?.data?.error || error?.message || "Unknown error";
      return { success: false, error: message };
    }
  };

  const handleDeleteFundraiser = async (fundraiser) => {
    return new Promise((resolve) => {
      Alert.alert(
        "Delete Fundraiser",
        `Are you sure you want to delete "${fundraiser.title}"? This action cannot be undone and will remove all associated contributions.`,
        [
          {
            text: "Cancel",
            style: "cancel",
            onPress: () => resolve({ success: false }),
          },
          {
            text: "Delete",
            style: "destructive",
            onPress: async () => {
              try {
                console.log(
                  "DEBUG: API URL:",
                  `/api/fundraisers/${fundraiser.id}`,
                );
                await fetchWithAuth(`/api/fundraisers/${fundraiser.id}`, {
                  method: "DELETE",
                  headers: { "Content-Type": "application/json" },
                });

                await fetchFundraisers();
                Alert.alert("Success", "Fundraiser deleted successfully");
                resolve({ success: true });
              } catch (error) {
                console.error("DEBUG: Error deleting fundraiser:", error);
                if (error?.status === 401) {
                  Alert.alert("Session expired", "Please sign in again.", [
                    { text: "Cancel", style: "cancel" },
                    { text: "Sign In", onPress: () => signIn() },
                  ]);
                  resolve({ success: false });
                  return;
                }
                const message =
                  error?.data?.error ||
                  error?.message ||
                  "Failed to delete fundraiser";
                Alert.alert("Error", message);
                resolve({ success: false });
              }
            },
          },
        ],
      );
    });
  };

  return { handleUpdateProgress, handleDeleteFundraiser };
}
