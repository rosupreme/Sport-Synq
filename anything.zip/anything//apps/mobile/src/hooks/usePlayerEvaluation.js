import { useState, useEffect } from "react";
import { Alert } from "react-native";
import { fetchWithAuth } from "@/utils/api";

export function usePlayerEvaluation(playerId, evaluationId, router) {
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingPlayer, setIsLoadingPlayer] = useState(true);
  const [player, setPlayer] = useState(null);
  const [strengths, setStrengths] = useState("");
  const [areasForImprovement, setAreasForImprovement] = useState("");
  const [goalsNextPeriod, setGoalsNextPeriod] = useState("");
  const [coachNotes, setCoachNotes] = useState("");
  const [evaluation, setEvaluation] = useState({
    evaluationType: "mid_season",
    season: "2024-25", // Will be updated when player data is loaded
    ballControl: 5,
    passing: 5,
    shooting: 5,
    defending: 5,
    fitnessLevel: 5,
    teamwork: 5,
    attitude: 5,
    leadership: 5,
    status: "draft",
  });

  useEffect(() => {
    if (playerId) {
      fetchPlayerDetails();
    }
    if (evaluationId) {
      fetchExistingEvaluation();
    }
  }, [playerId, evaluationId]);

  const fetchPlayerDetails = async () => {
    try {
      setIsLoadingPlayer(true);
      const data = await fetchWithAuth(`/api/players/${playerId}`);
      setPlayer(data.player);

      // Update the season from the team data
      if (data.player?.teamSeason) {
        setEvaluation((prev) => ({
          ...prev,
          season: data.player.teamSeason,
        }));
      }
    } catch (error) {
      console.error("Error fetching player details:", error);
      Alert.alert("Error", "Failed to load player details. Please try again.");
    } finally {
      setIsLoadingPlayer(false);
    }
  };

  const fetchExistingEvaluation = async () => {
    try {
      const data = await fetchWithAuth(
        `/api/evaluations?evaluationId=${evaluationId}`,
      );

      if (data.success && data.evaluations && data.evaluations.length > 0) {
        const evalData = data.evaluations[0];

        setEvaluation({
          evaluationType: evalData.evaluation_type,
          season: evalData.season,
          ballControl: evalData.ball_control,
          passing: evalData.passing,
          shooting: evalData.shooting,
          defending: evalData.defending,
          fitnessLevel: evalData.fitness_level,
          teamwork: evalData.teamwork,
          attitude: evalData.attitude,
          leadership: evalData.leadership,
          status: evalData.status,
        });

        setStrengths(evalData.strengths || "");
        setAreasForImprovement(evalData.areas_for_improvement || "");
        setGoalsNextPeriod(evalData.goals_next_period || "");
        setCoachNotes(evalData.coach_notes || "");
      }
    } catch (error) {
      console.error("Error fetching existing evaluation:", error);
      Alert.alert(
        "Error",
        "Failed to load evaluation details. Please try again.",
      );
    }
  };

  const handleDeleteEvaluation = async () => {
    Alert.alert(
      "Delete Evaluation",
      "Are you sure you want to delete this evaluation? This action cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            setIsLoading(true);
            try {
              const data = await fetchWithAuth(
                `/api/evaluations?evaluationId=${evaluationId}`,
                { method: "DELETE" },
              );

              if (!data.success) {
                throw new Error(data.error || "Failed to delete evaluation");
              }

              Alert.alert("Success", "Evaluation deleted successfully!", [
                {
                  text: "OK",
                  onPress: () => {
                    if (playerId) {
                      router.push(`/player-details?playerId=${playerId}`);
                    } else {
                      router.push("/evaluations");
                    }
                  },
                },
              ]);
            } catch (error) {
              console.error("Error deleting evaluation:", error);
              Alert.alert(
                "Error",
                `Failed to delete evaluation: ${error.message}`,
              );
            } finally {
              setIsLoading(false);
            }
          },
        },
      ],
    );
  };

  const updateEvaluation = (field, value) => {
    setEvaluation((prev) => ({ ...prev, [field]: value }));
  };

  const handleSaveEvaluation = async (submitStatus = "draft") => {
    const updatedEvaluation = {
      playerId: player.id,
      teamId: player.teamId,
      evaluationType: evaluation.evaluationType,
      season: evaluation.season,
      ballControl: evaluation.ballControl,
      passing: evaluation.passing,
      shooting: evaluation.shooting,
      defending: evaluation.defending,
      fitnessLevel: evaluation.fitnessLevel,
      teamwork: evaluation.teamwork,
      attitude: evaluation.attitude,
      leadership: evaluation.leadership,
      strengths,
      areasForImprovement,
      goalsNextPeriod,
      coachNotes,
      status: submitStatus,
    };

    setIsLoading(true);

    try {
      const data = await fetchWithAuth("/api/evaluations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedEvaluation),
      });

      if (!data.success) {
        throw new Error(data.error || "Failed to save evaluation");
      }

      const message =
        submitStatus === "submitted"
          ? "Evaluation submitted successfully!"
          : "Evaluation saved as draft!";

      Alert.alert("Success", message, [
        { text: "OK", onPress: () => router.back() },
      ]);
    } catch (error) {
      console.error("Error saving evaluation:", error);
      // Show better auth guidance if unauthorized
      if (error.status === 401) {
        Alert.alert(
          "Sign in required",
          "Your session has expired. Please sign in and try again.",
        );
      } else {
        Alert.alert("Error", "Failed to save evaluation. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    isLoadingPlayer,
    player,
    strengths,
    setStrengths,
    areasForImprovement,
    setAreasForImprovement,
    goalsNextPeriod,
    setGoalsNextPeriod,
    coachNotes,
    setCoachNotes,
    evaluation,
    updateEvaluation,
    handleSaveEvaluation,
    handleDeleteEvaluation,
  };
}
