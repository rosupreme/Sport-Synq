import Purchases, { LOG_LEVEL, PRODUCT_CATEGORY } from "react-native-purchases";
import { useAuth } from "@/utils/auth/useAuth";
import { Platform } from "react-native";
import { create } from "zustand";
import { useCallback, useState, useEffect } from "react";
import { fetchWithAuth } from "@/utils/api";

const useInAppPurchaseStore = create((set) => ({
  isReady: false,
  offerings: null,
  isSubscribed: false,
  subscriptionTier: null,
  teamLimit: 0,
  tierName: null,
  isCoach: false, // Track if user is a coach
  setSubscriptionInfo: (info) =>
    set({
      isSubscribed: info.hasAccess,
      subscriptionTier: info.tier,
      teamLimit: info.teamLimit,
      tierName: info.tierName,
    }),
  setIsCoach: (isCoach) => set({ isCoach }),
  setOfferings: (offerings) => set({ offerings }),
  setIsReady: (isReady) => set({ isReady }),
}));

function useInAppPurchase() {
  const { auth } = useAuth();
  const {
    isReady,
    offerings,
    setOfferings,
    isSubscribed,
    subscriptionTier,
    teamLimit,
    tierName,
    setSubscriptionInfo,
    setIsReady,
    isCoach,
    setIsCoach,
  } = useInAppPurchaseStore();
  const [isPurchasing, setIsPurchasing] = useState(false);

  // Check if user is a coach on any team
  const checkIfUserIsCoach = useCallback(async () => {
    // Don't check if user isn't authenticated
    if (!auth?.user?.id) {
      console.log("[useInAppPurchase] Skipping coach check - no auth user");
      return false;
    }

    try {
      // fetchWithAuth returns parsed JSON directly
      const data = await fetchWithAuth("/api/teams");
      const teams = data.teams || [];

      // Check if user is a coach/owner on ANY team
      const isCoachOnAnyTeam = teams.some((team) => {
        const roleValue =
          team.user_role ||
          team.role ||
          team.current_user_role ||
          (team.is_owner ? "owner" : null);
        const roleStr =
          typeof roleValue === "string" ? roleValue.toLowerCase() : "";

        if (roleStr === "coach" || roleStr === "owner") return true;
        if (team.is_owner === true) return true;

        return false;
      });

      setIsCoach(isCoachOnAnyTeam);
      return isCoachOnAnyTeam;
    } catch (error) {
      console.error("Error checking if user is coach:", error);
      return false;
    }
  }, [auth?.user?.id, setIsCoach]);

  const fetchSubscriptionStatus = useCallback(async () => {
    try {
      // First, check if user has a subscription in the database (from RevenueCat sync)
      // This is important during onboarding when teams haven't been created yet
      try {
        const dbSubData = await fetchWithAuth(
          "/api/revenue-cat/get-subscription-status",
          { method: "POST" },
        );

        // If they have an active subscription in the database, they're a coach
        if (
          dbSubData.hasAccess &&
          dbSubData.tier &&
          dbSubData.tier !== "player"
        ) {
          console.log(
            "User has active subscription in database:",
            dbSubData.tier,
          );
          setSubscriptionInfo(dbSubData);
          setIsCoach(true); // They're a coach if they have a paid subscription
          return;
        }
      } catch (subError) {
        // If subscription check fails, continue to check teams
        console.log(
          "Subscription check failed, checking teams:",
          subError.message,
        );
      }

      // If no database subscription, check if user is a coach via teams
      const userIsCoach = await checkIfUserIsCoach();

      // If user is not a coach (only a player), they don't need a subscription
      if (!userIsCoach) {
        console.log("User is a player only - no subscription required");
        setSubscriptionInfo({
          hasAccess: true, // Players have access without subscription
          tier: "player",
          teamLimit: 0,
          tierName: "Player",
        });
        return;
      }

      // User is a coach but no subscription found - they need to subscribe
      console.log("User is a coach but no active subscription");
      setSubscriptionInfo({
        hasAccess: false,
        tier: null,
        teamLimit: 0,
        tierName: null,
      });
    } catch (error) {
      console.error("Error refetching subscription:", error);
      setSubscriptionInfo({
        hasAccess: false,
        tier: null,
        teamLimit: 0,
        tierName: null,
      });
    }
  }, [setSubscriptionInfo, checkIfUserIsCoach, setIsCoach]);

  const initiateInAppPurchase = useCallback(async () => {
    try {
      Purchases.setLogLevel(LOG_LEVEL.INFO);

      const apiKey =
        process.env.EXPO_PUBLIC_CREATE_ENV === "DEVELOPMENT"
          ? process.env.EXPO_PUBLIC_REVENUE_CAT_TEST_STORE_API_KEY
          : Platform.select({
              ios: process.env.EXPO_PUBLIC_REVENUE_CAT_APP_STORE_API_KEY,
              android: process.env.EXPO_PUBLIC_REVENUE_CAT_PLAY_STORE_API_KEY,
              web: process.env.EXPO_PUBLIC_REVENUE_CAT_TEST_STORE_API_KEY,
            });

      if (apiKey) {
        Purchases.configure({
          apiKey: apiKey,
        });

        // Wait for both offerings and subscription status to load
        const results = await Promise.allSettled([
          Purchases.getOfferings(),
          fetchSubscriptionStatus(),
        ]);

        // Set offerings if successfully fetched
        if (results[0].status === "fulfilled") {
          setOfferings(results[0].value);
        } else {
          console.error("Failed to fetch offerings:", results[0].reason);
        }

        // Log any errors from subscription status check
        if (results[1].status === "rejected") {
          console.error(
            "Failed to fetch subscription status:",
            results[1].reason,
          );
        }
      }
    } catch (error) {
      console.warn("Failed to initialize RevenueCat:", error);
    } finally {
      setIsReady(true);
    }
  }, [setIsReady, setOfferings, fetchSubscriptionStatus]);

  const getAvailableSubscriptions = useCallback(() => {
    console.log("🔍 Getting available subscriptions");
    console.log("📦 Offerings:", offerings);

    const offering = offerings?.current;

    if (!offering) {
      console.warn("⚠️ No offering found in offerings.current");
      console.log(
        "📦 Full offerings object:",
        JSON.stringify(offerings, null, 2),
      );
      return [];
    }

    console.log("📦 Current offering:", offering);
    console.log(
      "📦 Available packages count:",
      offering.availablePackages?.length || 0,
    );

    if (offering.availablePackages) {
      console.log(
        "📦 All package identifiers:",
        offering.availablePackages.map((p) => p.identifier),
      );
    }

    // Filter to only show Standard, Plus, and Pro packages
    const filtered = offering.availablePackages.filter((pkg) => {
      const lookupKey = pkg.identifier;
      return (
        lookupKey === "$rc_custom_standard" ||
        lookupKey === "$rc_custom_plus" ||
        lookupKey === "$rc_custom_pro"
      );
    });

    console.log("✅ Filtered packages count:", filtered.length);
    console.log(
      "✅ Filtered package identifiers:",
      filtered.map((p) => p.identifier),
    );

    return filtered;
  }, [offerings]);

  const startSubscription = useCallback(
    async ({ subscription }) => {
      try {
        setIsPurchasing(true);
        if (!auth?.user?.id) {
          throw new Error("User not authenticated");
        }
        // Log in the user first
        await Purchases.logIn(String(auth.user.id));

        // Set attributes with proper string values
        await Purchases.setAttributes({
          userId: String(auth.user.id),
        });

        // Purchase the package
        await Purchases.purchasePackage(subscription);

        // Get customer info to determine which plan was purchased
        const info = await Purchases.getCustomerInfo();
        const active = info?.entitlements?.active || {};

        // Determine the plan tier from entitlements
        let plan = null;
        if (active.plus) plan = "plus";
        else if (active.standard) plan = "standard";
        else if (active.pro) plan = "pro";

        // Sync to backend database
        if (plan) {
          console.log("🔄 Syncing subscription to backend:", plan);
          try {
            // Use fetchWithAuth to include auth headers
            await fetchWithAuth("/api/subscriptions/revenuecat-sync", {
              method: "POST",
              body: JSON.stringify({ planType: plan }),
            });
            console.log("✅ Subscription synced to backend successfully");
          } catch (syncError) {
            console.error("❌ Sync error:", syncError);
            // Re-throw with more context
            throw new Error(
              `Failed to sync subscription to backend: ${syncError.message}`,
            );
          }
        }

        // Refresh subscription status
        await fetchSubscriptionStatus();
        return true;
      } catch (error) {
        console.error("Failed to start subscription:", error);
        // Re-throw so the caller can handle it
        throw error;
      } finally {
        setIsPurchasing(false);
      }
    },
    [auth, setIsPurchasing, fetchSubscriptionStatus],
  );

  // Initialize RevenueCat and fetch subscription status when auth is ready
  useEffect(() => {
    if (auth?.user?.id) {
      initiateInAppPurchase();
    }
  }, [auth?.user?.id, initiateInAppPurchase]);

  return {
    isReady,
    initiateInAppPurchase,
    getAvailableSubscriptions,
    startSubscription,
    isSubscribed,
    subscriptionTier,
    teamLimit,
    tierName,
    isPurchasing,
    isCoach, // Expose isCoach so components can check
  };
}

export default useInAppPurchase;
