import { useState, useEffect } from "react";
import { DeviceEventEmitter } from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback } from "react";
import { fetchWithAuth, buildApiUrl } from "@/utils/api"; // import buildApiUrl to log the full URL

export function useUpcomingEvents(selectedTeam) {
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchUpcomingEvents = async () => {
    try {
      setLoading(true);

      // Do not fetch until a team is selected to avoid cross-team or unauthorized data
      if (!selectedTeam?.id) {
        setUpcomingEvents([]);
        setLoading(false);
        return;
      }

      // Build URL with teamId
      let url = "/api/events?teamId=" + selectedTeam.id;
      const fullUrl = buildApiUrl(url);
      console.log(
        "DEBUG: useUpcomingEvents fetching events for team:",
        selectedTeam.id,
      );
      console.log("DEBUG: Full URL:", fullUrl);

      const data = await fetchWithAuth(url);
      console.log("DEBUG: Events data received:", data);
      const events = data.events || [];

      // Get upcoming events and limit to 4 for dashboard
      const now = new Date();
      const upcoming = events
        .filter((event) => {
          const eventDate = (event.event_date || "").split("T")[0];
          if (!eventDate || !event.event_time) return false;
          const eventDateTime = new Date(`${eventDate}T${event.event_time}`);
          return eventDateTime > now;
        })
        .sort((a, b) => {
          const aDate = (a.event_date || "").split("T")[0];
          const bDate = (b.event_date || "").split("T")[0];
          const aDateTime = new Date(`${aDate}T${a.event_time}`);
          const bDateTime = new Date(`${bDate}T${b.event_time}`);
          return aDateTime - bDateTime;
        })
        .slice(0, 4); // Limit to 4 events for dashboard

      setUpcomingEvents(upcoming);
    } catch (error) {
      console.error("Error fetching upcoming events:", error);
      console.error("Error name:", error.name);
      console.error("Error message:", error.message);
      console.error("Error status:", error.status);
      console.error("Error stack:", error.stack);
      setUpcomingEvents([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUpcomingEvents();
  }, [selectedTeam?.id]); // depend on stable id only

  // Listen for new events being created
  useEffect(() => {
    const subscription = DeviceEventEmitter.addListener(
      "eventCreated",
      (data) => {
        console.log("🔄 Event created, refreshing upcoming events...");
        fetchUpcomingEvents();
      },
    );

    return () => subscription.remove();
  }, []);

  // Refresh when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      fetchUpcomingEvents();
    }, [selectedTeam?.id]),
  );

  const refresh = () => {
    fetchUpcomingEvents();
  };

  return {
    upcomingEvents,
    loading,
    refresh,
  };
}
