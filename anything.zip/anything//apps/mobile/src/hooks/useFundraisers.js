import { useState, useEffect } from "react";
import { fetchWithAuth } from "@/utils/api";

export function useFundraisers(selectedTeam) {
  const [fundraisers, setFundraisers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const fetchFundraisers = async () => {
    try {
      // If no team is selected, avoid fetching unfiltered data (prevents cross-team overlap)
      if (!selectedTeam?.id) {
        setFundraisers([]);
        setError(null);
        setLoading(false);
        return;
      }

      // Build relative path with team filter so auth + base URL helpers are applied
      const path = `/api/fundraisers?teamId=${selectedTeam.id}`;

      const data = await fetchWithAuth(path, { method: "GET" });
      setFundraisers(data?.fundraisers || []);
      setError(null);
    } catch (error) {
      console.error("DEBUG: Error fetching fundraisers:", error);
      setError(error?.message || "Failed to load fundraisers");
      setFundraisers([]);
    } finally {
      setLoading(false);
    }
  };

  const refresh = async () => {
    setRefreshing(true);
    await fetchFundraisers();
    setRefreshing(false);
  };

  useEffect(() => {
    if (selectedTeam?.id) {
      fetchFundraisers();
    } else {
      // If team is cleared/changed to null, make sure UI doesn't show stale data or spinner
      setFundraisers([]);
      setLoading(false);
    }
  }, [selectedTeam?.id]); // depend on stable id only to avoid re-running on object identity changes

  return {
    fundraisers,
    loading,
    refreshing,
    fetchFundraisers,
    refresh,
    error,
  };
}
