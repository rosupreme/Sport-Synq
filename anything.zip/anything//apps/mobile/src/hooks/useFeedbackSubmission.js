import { useState } from "react";

export function useFeedbackSubmission(onSuccess) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newFeedback, setNewFeedback] = useState({
    title: "",
    description: "",
    feedback_type: "feature",
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmitFeedback = async () => {
    if (!newFeedback.title.trim()) {
      throw new Error("Please enter a title for your feedback");
    }

    try {
      setSubmitting(true);
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newFeedback),
      });

      if (!response.ok) throw new Error("Failed to submit feedback");

      setShowAddModal(false);
      setNewFeedback({ title: "", description: "", feedback_type: "feature" });

      if (onSuccess) {
        await onSuccess();
      }
    } catch (error) {
      console.error("Error submitting feedback:", error);
      throw error;
    } finally {
      setSubmitting(false);
    }
  };

  return {
    showAddModal,
    setShowAddModal,
    newFeedback,
    setNewFeedback,
    submitting,
    handleSubmitFeedback,
  };
}
