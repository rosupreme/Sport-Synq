import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useCallback } from "react";
import useUser from "@/utils/auth/useUser";
import { fetchWithAuth } from "@/utils/api";

export function useEventAttendance(eventId) {
  const queryClient = useQueryClient();
  const { data: user } = useUser();

  const fetchAttendance = useCallback(async () => {
    if (!eventId) return null;
    // fetchWithAuth returns parsed JSON directly and includes auth headers
    return fetchWithAuth(`/api/events/${eventId}/attendance`, {
      method: "GET",
    });
  }, [eventId]);

  const { data, isLoading, error } = useQuery({
    queryKey: ["eventAttendance", eventId],
    queryFn: fetchAttendance,
    enabled: !!eventId,
  });

  const rsvp = useMutation({
    mutationFn: async (status) => {
      if (!eventId) {
        throw new Error("Missing eventId");
      }
      if (!user?.id) {
        throw new Error("Not authenticated");
      }

      // POST with auth headers; backend uses authenticated user id
      return fetchWithAuth(`/api/events/${eventId}/attendance`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
    },
    onMutate: async (status) => {
      await queryClient.cancelQueries({
        queryKey: ["eventAttendance", eventId],
      });
      const previous = queryClient.getQueryData(["eventAttendance", eventId]);

      // optimistic update
      if (previous && user?.id) {
        const next = JSON.parse(JSON.stringify(previous));
        if (!next.attendees)
          next.attendees = { going: [], not_going: [], maybe: [] };
        if (!next.counts) next.counts = { going: 0, not_going: 0, maybe: 0 };

        // Remove from all groups
        ["going", "not_going", "maybe"].forEach((k) => {
          next.attendees[k] = (next.attendees[k] || []).filter(
            (u) => String(u.id) !== String(user.id),
          );
        });

        // Add to selected group
        if (!next.attendees[status]) next.attendees[status] = [];
        next.attendees[status].push({
          id: user.id,
          name: user.name || user.email,
        });

        next.counts.going = next.attendees.going?.length || 0;
        next.counts.not_going = next.attendees.not_going?.length || 0;
        next.counts.maybe = next.attendees.maybe?.length || 0;
        queryClient.setQueryData(["eventAttendance", eventId], next);
      }
      return { previous };
    },
    onError: (err, _status, context) => {
      if (context?.previous) {
        queryClient.setQueryData(
          ["eventAttendance", eventId],
          context.previous,
        );
      }
      console.error(err);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["eventAttendance", eventId] });
    },
  });

  return { data, isLoading, error, rsvp };
}

export default useEventAttendance;
