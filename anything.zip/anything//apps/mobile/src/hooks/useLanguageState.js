import { useState, useEffect } from "react";
import { loadLanguage, saveLanguage } from "@/utils/language/languageStorage";
import { isValidLanguage } from "@/utils/language/languageHelpers";

export const useLanguageState = () => {
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    initializeLanguage();
  }, []);

  const initializeLanguage = async () => {
    try {
      const savedLanguage = await loadLanguage();
      if (savedLanguage && isValidLanguage(savedLanguage)) {
        setCurrentLanguage(savedLanguage);
      }
    } catch (error) {
      console.error("Error initializing language:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const changeLanguage = async (languageCode) => {
    try {
      await saveLanguage(languageCode);
      setCurrentLanguage(languageCode);
    } catch (error) {
      console.error("Error changing language:", error);
    }
  };

  return {
    currentLanguage,
    changeLanguage,
    isLoading,
  };
};
