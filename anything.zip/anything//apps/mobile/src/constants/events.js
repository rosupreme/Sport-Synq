import { Users, Calendar, FileText, Clock } from "lucide-react-native";

export const getEventTypes = (colors) => [
  { id: "practice", label: "Practice", icon: Users, color: colors.primary },
  { id: "game", label: "Game", icon: Calendar, color: "#DC2626" }, // Changed to red
  { id: "meeting", label: "Meeting", icon: FileText, color: "#16A34A" }, // Changed to green
  { id: "other", label: "Other", icon: Clock, color: "#F97316" }, // Changed to orange
];
