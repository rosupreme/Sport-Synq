export const navigationTranslations = {
  en: {
    dashboard: "Dashboard",
    schedule: "Schedule",
    team: "Team",
    payments: "Payments",
    profile: "Profile",
    settings: "Settings",
  },
  fr: {
    dashboard: "Tableau de Bord",
    schedule: "Calendrier",
    team: "Équipe",
    payments: "Paiements",
    profile: "Profil",
    settings: "Paramètres",
  },
  es: {
    dashboard: "Panel",
    schedule: "Calendario",
    team: "Equipo",
    payments: "Pagos",
    profile: "Perfil",
    settings: "Configuración",
  },
};
