import { commonTranslations } from "./common";
import { navigationTranslations } from "./navigation";
import { dashboardTranslations } from "./dashboard";
import { eventsTranslations } from "./events";
import { teamTranslations } from "./team";
import { fundraisersTranslations } from "./fundraisers";
import { evaluationsTranslations } from "./evaluations";
import { profileTranslations } from "./profile";
import { settingsTranslations } from "./settings";
import { languageTranslations } from "./language";
import { privacyTranslations } from "./privacy";
import { authTranslations } from "./auth";
import { subscriptionsTranslations } from "./subscriptions";
import { onboardingTranslations } from "./onboarding";
import { emptyStatesTranslations } from "./emptyStates";

function mergeTranslations(...translationObjects) {
  const result = { en: {}, fr: {}, es: {} };

  for (const translationObj of translationObjects) {
    for (const lang of ["en", "fr", "es"]) {
      Object.assign(result[lang], translationObj[lang]);
    }
  }

  return result;
}

export const translations = mergeTranslations(
  commonTranslations,
  navigationTranslations,
  dashboardTranslations,
  eventsTranslations,
  teamTranslations,
  fundraisersTranslations,
  evaluationsTranslations,
  profileTranslations,
  settingsTranslations,
  languageTranslations,
  privacyTranslations,
  authTranslations,
  subscriptionsTranslations,
  onboardingTranslations,
  emptyStatesTranslations,
);
