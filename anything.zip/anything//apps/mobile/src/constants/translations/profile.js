export const profileTranslations = {
  en: {
    manageProfile: "Manage your profile",
    fullName: "Full Name",
    emailAddress: "Email Address",
    phoneNumber: "Phone Number",
    saveChanges: "Save Changes",
    profileUpdated: "Profile updated successfully!",
  },
  fr: {
    manageProfile: "Gérer votre profil",
    fullName: "Nom Complet",
    emailAddress: "Adresse Email",
    phoneNumber: "Numéro de Téléphone",
    saveChanges: "Enregistrer les Modifications",
    profileUpdated: "Profil mis à jour avec succès !",
  },
  es: {
    manageProfile: "Administrar tu perfil",
    fullName: "Nombre Completo",
    emailAddress: "Dirección de Email",
    phoneNumber: "Número de Teléfono",
    saveChanges: "Guardar Cambios",
    profileUpdated: "¡Perfil actualizado exitosamente!",
  },
};
