export const languageTranslations = {
  en: {
    selectLanguage: "Select Language",
    choosePreferredLanguage: "Choose your preferred language",
    english: "English",
    french: "French",
    spanish: "Spanish",
    languageChanged: "Language Changed",
    languageChangedMessage: "The app language has been changed successfully.",
    currentLanguage: "Current Language",
  },
  fr: {
    selectLanguage: "Sélectionner la Langue",
    choosePreferredLanguage: "Choisissez votre langue préférée",
    english: "Anglais",
    french: "Français",
    spanish: "Espagnol",
    languageChanged: "Langue Modifiée",
    languageChangedMessage:
      "La langue de l'application a été modifiée avec succès.",
    currentLanguage: "Langue Actuelle",
  },
  es: {
    selectLanguage: "Seleccionar Idioma",
    choosePreferredLanguage: "Elige tu idioma preferido",
    english: "Inglés",
    french: "Francés",
    spanish: "Español",
    languageChanged: "Idioma Cambiado",
    languageChangedMessage:
      "El idioma de la aplicación se ha cambiado exitosamente.",
    currentLanguage: "Idioma Actual",
  },
};
