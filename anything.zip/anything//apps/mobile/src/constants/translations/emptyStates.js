export const emptyStatesTranslations = {
  en: {
    noData: "No data available",
    noResults: "No results found",
    tryAgain: "Try Again",
    saving: "Saving...",
  },
  fr: {
    noData: "Aucune donnée disponible",
    noResults: "Aucun résultat trouvé",
    tryAgain: "Réessayer",
    saving: "Enregistrement...",
  },
  es: {
    noData: "No hay datos disponibles",
    noResults: "No se encontraron resultados",
    tryAgain: "Intentar de Nuevo",
    saving: "Guardando...",
  },
};
