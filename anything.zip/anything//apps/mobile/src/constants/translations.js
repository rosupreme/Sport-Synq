export { translations } from "./translations/index";
