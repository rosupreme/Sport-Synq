"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

function setSessionCookie(sessionToken) {
  // 30 days
  const maxAge = 30 * 24 * 60 * 60;
  document.cookie = `sessionToken=${sessionToken}; path=/; max-age=${maxAge}`;
}

function clearSessionCookie() {
  document.cookie =
    "sessionToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
}

export function useAuth() {
  const [sessionToken, setSessionToken] = useState(null);
  const [user, setUser] = useState(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Browser-only
    try {
      const token = window.localStorage.getItem("sessionToken");
      if (token) {
        setSessionToken(token);
      }
    } catch (e) {
      // ignore
    } finally {
      setIsReady(true);
    }
  }, []);

  const isAuthenticated = useMemo(() => {
    return Boolean(sessionToken);
  }, [sessionToken]);

  const signInWithCredentials = useCallback(
    async ({ email, password, callbackUrl = "/", redirect = true }) => {
      const response = await fetch("/api/auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Sign in failed");
      }

      if (data.sessionToken) {
        window.localStorage.setItem("sessionToken", data.sessionToken);
        setSessionCookie(data.sessionToken);
        setSessionToken(data.sessionToken);
      }

      if (data.user) {
        setUser(data.user);
      }

      if (redirect) {
        window.location.href = callbackUrl;
      }

      return data;
    },
    [],
  );

  const signUpWithCredentials = useCallback(
    async ({ email, password, name, callbackUrl = "/", redirect = true }) => {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, name }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Sign up failed");
      }

      if (data.sessionToken) {
        window.localStorage.setItem("sessionToken", data.sessionToken);
        setSessionCookie(data.sessionToken);
        setSessionToken(data.sessionToken);
      }

      if (data.user) {
        setUser(data.user);
      }

      if (redirect) {
        window.location.href = callbackUrl;
      }

      return data;
    },
    [],
  );

  const signOut = useCallback(
    async ({ callbackUrl = "/", redirect = true } = {}) => {
      try {
        await fetch("/api/auth/logout", { method: "POST" });
      } catch (e) {
        // ignore
      }

      try {
        window.localStorage.removeItem("sessionToken");
      } catch (e) {
        // ignore
      }

      clearSessionCookie();
      setSessionToken(null);
      setUser(null);

      if (redirect) {
        window.location.href = callbackUrl;
      }
    },
    [],
  );

  return {
    isReady,
    isAuthenticated,
    sessionToken,
    user,
    signInWithCredentials,
    signUpWithCredentials,
    signOut,
    // For mobile parity (web should still use /account/* pages)
    signIn: () => {
      window.location.href = "/account/signin";
    },
    signUp: () => {
      window.location.href = "/account/signup";
    },
  };
}

export default useAuth;
