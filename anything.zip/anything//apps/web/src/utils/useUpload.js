import * as React from "react";

// Web upload helper. Uses Anything's upload endpoint.
// Supported inputs:
// - { file: File }
// - { url: string }
// - { base64: string }
// - { buffer: ArrayBuffer | Uint8Array }
function useUpload() {
  const [loading, setLoading] = React.useState(false);

  const upload = React.useCallback(async (input) => {
    try {
      setLoading(true);

      let response;

      if (input && input.file) {
        const formData = new FormData();
        formData.append("file", input.file);
        response = await fetch("/_create/api/upload/", {
          method: "POST",
          body: formData,
        });
      } else if (input && typeof input.url === "string") {
        response = await fetch("/_create/api/upload/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: input.url }),
        });
      } else if (input && typeof input.base64 === "string") {
        response = await fetch("/_create/api/upload/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ base64: input.base64 }),
        });
      } else if (input && input.buffer) {
        response = await fetch("/_create/api/upload/", {
          method: "POST",
          headers: { "Content-Type": "application/octet-stream" },
          body: input.buffer,
        });
      } else {
        return { error: "No upload input provided" };
      }

      if (!response.ok) {
        if (response.status === 413) {
          return { error: "Upload failed: File too large." };
        }
        return {
          error: `Upload failed (${response.status} ${response.statusText})`,
        };
      }

      const data = await response.json();
      return { url: data.url, mimeType: data.mimeType || null };
    } catch (err) {
      console.error("Upload error:", err);
      if (err instanceof Error) return { error: err.message };
      return { error: "Upload failed" };
    } finally {
      setLoading(false);
    }
  }, []);

  return [upload, { loading }];
}

export { useUpload };
export default useUpload;
