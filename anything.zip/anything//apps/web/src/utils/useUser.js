"use client";

import { useCallback, useEffect, useState } from "react";

function getSessionTokenFromLocalStorage() {
  try {
    return window.localStorage.getItem("sessionToken");
  } catch (e) {
    return null;
  }
}

export default function useUser() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchUser = useCallback(async () => {
    const token = getSessionTokenFromLocalStorage();

    if (!token) {
      setData(null);
      setLoading(false);
      return null;
    }

    try {
      setLoading(true);
      const response = await fetch("/api/user/profile", {
        method: "GET",
        headers: {
          // Cookie should work too, but this makes it explicit
          Authorization: `Bearer ${token}`,
        },
      });

      const json = await response.json();
      if (!response.ok) {
        throw new Error(
          json.message ||
            `When fetching /api/user/profile, the response was [${response.status}] ${response.statusText}`,
        );
      }

      const user = json.user || null;
      setData(user);
      return user;
    } catch (err) {
      console.error("useUser fetch error:", err);
      setData(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // Browser-only
    fetchUser();
  }, [fetchUser]);

  return { data, loading, refetch: fetchUser };
}
