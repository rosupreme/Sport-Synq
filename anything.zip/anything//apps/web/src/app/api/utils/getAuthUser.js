import sql from "@/app/api/utils/sql";

/**
 * Validates session token from request headers and returns the authenticated user.
 * Supports both Authorization: Bearer <token> and X-Session-Token: <token> headers.
 *
 * @param {Request} request - The incoming request object
 * @returns {Promise<{id: number, name: string, email: string} | null>} - User object or null if not authenticated
 */
export async function getAuthUser(request) {
  try {
    // Check Authorization header first (preferred)
    const authHeader = request.headers.get("Authorization");
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.substring(7);
      const user = await getUserFromToken(token);
      if (user) return user;
    }

    // Fallback: check X-Session-Token header
    const xSessionToken = request.headers.get("X-Session-Token");
    if (xSessionToken) {
      const user = await getUserFromToken(xSessionToken);
      if (user) return user;
    }

    return null;
  } catch (error) {
    console.error("[getAuthUser] Error validating session:", error);
    return null;
  }
}

/**
 * Looks up user from session token in database
 */
async function getUserFromToken(token) {
  const sessions = await sql`
    SELECT u.id, u.name, u.email
    FROM auth_sessions s
    JOIN auth_users u ON s."userId" = u.id
    WHERE s."sessionToken" = ${token}
      AND s.expires > NOW()
    LIMIT 1
  `;

  if (sessions.length > 0) {
    return sessions[0];
  }

  return null;
}

/**
 * Convenience function that returns a 401 response if user is not authenticated.
 * Use this for cleaner route handlers.
 *
 * @param {Request} request - The incoming request object
 * @returns {Promise<{user: object} | {response: Response}>}
 *
 * @example
 * const auth = await requireAuth(request);
 * if (auth.response) return auth.response;
 * const user = auth.user;
 */
export async function requireAuth(request) {
  const user = await getAuthUser(request);

  if (!user) {
    return {
      response: Response.json(
        { error: "Authentication required" },
        { status: 401 },
      ),
    };
  }

  return { user };
}

export default getAuthUser;
