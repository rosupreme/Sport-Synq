import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Get all fundraisers for the user's teams
export async function GET(request) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;

    // Get teamId from query parameters if provided
    const url = new URL(request.url);
    const teamIdRaw = url.searchParams.get("teamId");
    const teamId = teamIdRaw ? parseInt(teamIdRaw, 10) : null;

    let fundraisers;

    if (teamId) {
      // First, verify the user has access to this team
      const access = await sql`
        SELECT 1 FROM team_members WHERE user_id = ${userId} AND team_id = ${teamId}
        UNION
        SELECT 1 FROM team_ownership WHERE user_id = ${userId} AND team_id = ${teamId}
        LIMIT 1
      `;

      if (access.length === 0) {
        return Response.json({ error: "Forbidden" }, { status: 403 });
      }

      // Fetch all fundraisers for this team (any organizer), newest first
      fundraisers = await sql`
        SELECT 
          f.*,
          t.name as team_name,
          u.name as organizer_name,
          (
            SELECT COUNT(DISTINCT contributor_name)
            FROM fundraiser_contributions fc 
            WHERE fc.fundraiser_id = f.id
          ) as contributors,
          (
            SELECT json_agg(
              json_build_object(
                'amount', amount, 
                'note', note, 
                'date', date_added
              ) ORDER BY date_added DESC
            ) 
            FROM fundraiser_contributions fc 
            WHERE fc.fundraiser_id = f.id 
            LIMIT 5
          ) as recent_contributions
        FROM fundraisers f
        LEFT JOIN teams t ON f.team_id = t.id
        JOIN auth_users u ON f.organizer_id = u.id
        WHERE f.team_id = ${teamId}
        ORDER BY f.created_at DESC
      `;
    } else {
      // Get fundraisers for all teams the user belongs to (legacy behavior)
      fundraisers = await sql`
        SELECT 
          f.*,
          t.name as team_name,
          u.name as organizer_name,
          (
            SELECT COUNT(DISTINCT contributor_name)
            FROM fundraiser_contributions fc 
            WHERE fc.fundraiser_id = f.id
          ) as contributors,
          (
            SELECT json_agg(
              json_build_object(
                'amount', amount, 
                'note', note, 
                'date', date_added
              ) ORDER BY date_added DESC
            ) 
            FROM fundraiser_contributions fc 
            WHERE fc.fundraiser_id = f.id 
            LIMIT 5
          ) as recent_contributions
        FROM fundraisers f
        LEFT JOIN teams t ON f.team_id = t.id
        JOIN auth_users u ON f.organizer_id = u.id
        WHERE f.organizer_id = ${userId} OR f.team_id IN (
          SELECT team_id 
          FROM team_members 
          WHERE user_id = ${userId}
          UNION
          SELECT team_id 
          FROM team_ownership 
          WHERE user_id = ${userId}
        )
        ORDER BY f.created_at DESC
      `;
    }

    return Response.json({ fundraisers });
  } catch (error) {
    return Response.json(
      { error: "Failed to fetch fundraisers" },
      { status: 500 },
    );
  }
}

// Create a new fundraiser
export async function POST(request) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { title, description, goal_amount, team_id, start_date, end_date } =
      body;

    // Validate required fields (team_id is now optional)
    if (!title || !goal_amount || !start_date || !end_date) {
      return Response.json(
        {
          error:
            "Missing required fields: title, goal_amount, start_date, and end_date are required",
        },
        { status: 400 },
      );
    }

    const userId = user.id;

    // Check if user has permission to create fundraisers for this team (only if team_id is provided)
    // Permission checks can be re-enabled when needed
    // if (team_id) {
    //   const teamAccess = await sql`
    //     SELECT 1 FROM team_members
    //     WHERE user_id = ${userId} AND team_id = ${team_id} AND role = 'Coach'
    //     UNION
    //     SELECT 1 FROM team_ownership
    //     WHERE user_id = ${userId} AND team_id = ${team_id}
    //   `;
    //   if (teamAccess.length === 0) {
    //     return Response.json(
    //       { error: "You don't have permission to create fundraisers for this team" },
    //       { status: 403 },
    //     );
    //   }
    // }

    // Create the fundraiser (team_id can be null)
    const result = await sql`
      INSERT INTO fundraisers (
        title, description, goal_amount, team_id, organizer_id, start_date, end_date
      ) VALUES (
        ${title}, ${description || null}, ${goal_amount}, 
        ${team_id || null}, ${userId}, ${start_date}, ${end_date}
      ) RETURNING *
    `;

    return Response.json(
      {
        message: "Fundraiser created successfully",
        fundraiser: result[0],
      },
      { status: 201 },
    );
  } catch (error) {
    return Response.json(
      { error: "Failed to create fundraiser" },
      { status: 500 },
    );
  }
}

// Bulk delete fundraisers
export async function DELETE(request) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const userId = user.id;

    const url = new URL(request.url);
    const teamIdRaw = url.searchParams.get("teamId");
    const teamId = teamIdRaw ? parseInt(teamIdRaw, 10) : null;

    let isTeamOwner = false;

    if (teamId) {
      // Verify access and ownership for this team
      const access = await sql`
        SELECT 1 FROM team_members WHERE user_id = ${userId} AND team_id = ${teamId}
        UNION
        SELECT 1 FROM team_ownership WHERE user_id = ${userId} AND team_id = ${teamId}
        LIMIT 1
      `;
      if (access.length === 0) {
        return Response.json({ error: "Forbidden" }, { status: 403 });
      }

      const owner = await sql`
        SELECT 1 FROM team_ownership WHERE user_id = ${userId} AND team_id = ${teamId} LIMIT 1
      `;
      isTeamOwner = owner.length > 0;
    }

    // Determine which fundraiser IDs to delete
    let idsToDelete = [];
    if (teamId) {
      if (isTeamOwner) {
        const rows = await sql`
          SELECT id FROM fundraisers WHERE team_id = ${teamId}
        `;
        idsToDelete = rows.map((r) => r.id);
      } else {
        const rows = await sql`
          SELECT id FROM fundraisers WHERE team_id = ${teamId} AND organizer_id = ${userId}
        `;
        idsToDelete = rows.map((r) => r.id);
      }
    } else {
      const rows = await sql`
        SELECT id FROM fundraisers WHERE organizer_id = ${userId}
      `;
      idsToDelete = rows.map((r) => r.id);
    }

    if (!idsToDelete.length) {
      return Response.json({ deleted: 0, ids: [] }, { status: 200 });
    }

    // Delete contributions then fundraisers in a transaction
    await sql.transaction([
      sql`DELETE FROM fundraiser_contributions WHERE fundraiser_id = ANY(${idsToDelete})`,
      sql`DELETE FROM fundraisers WHERE id = ANY(${idsToDelete})`,
    ]);

    return Response.json({ deleted: idsToDelete.length, ids: idsToDelete });
  } catch (error) {
    return Response.json(
      { error: "Failed to delete fundraisers" },
      { status: 500 },
    );
  }
}
