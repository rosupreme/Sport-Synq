import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const authHeader = request.headers.get("Authorization");

    if (authHeader && authHeader.startsWith("Bearer ")) {
      const sessionToken = authHeader.replace("Bearer ", "");

      // Delete the session from the database
      await sql`
        DELETE FROM auth_sessions 
        WHERE "sessionToken" = ${sessionToken}
      `;
    }

    return Response.json(
      { success: true, message: "Logged out successfully" },
      { status: 200 },
    );
  } catch (error) {
    console.error("Logout error:", error);
    return Response.json(
      { success: true, message: "Logged out" }, // Still return success to avoid issues
      { status: 200 },
    );
  }
}

// Clean up expired sessions (can be called periodically)
export async function DELETE() {
  try {
    const result = await sql`
      DELETE FROM auth_sessions 
      WHERE expires < NOW()
    `;

    return Response.json({
      success: true,
      message: `Cleaned up ${result.length} expired sessions`,
    });
  } catch (error) {
    console.error("Session cleanup error:", error);
    return Response.json(
      { error: "Failed to clean up sessions" },
      { status: 500 },
    );
  }
}
