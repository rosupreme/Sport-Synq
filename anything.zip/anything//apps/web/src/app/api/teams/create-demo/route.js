import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Create a demo team for the authenticated user (kept for compatibility)
export async function POST(request) {
  try {
    // Use authenticated user instead of hardcoded IDs
    const user = await getAuthUser(request);
    if (!user) {
      return Response.json(
        { message: "Authentication required" },
        { status: 401 },
      );
    }
    const userId = parseInt(user.id);

    const { name, sport = "Soccer", season = "2024-25" } = await request.json();

    if (!name) {
      return Response.json(
        { message: "Team name is required" },
        { status: 400 },
      );
    }

    // Ensure the user has a basic subscription row (demo-friendly)
    const subscriptions = await sql`
      SELECT id FROM user_subscriptions 
      WHERE user_id = ${userId}
    `;

    if (subscriptions.length === 0) {
      await sql`
        INSERT INTO user_subscriptions (user_id, plan_type, status, team_limit, current_period_start, current_period_end)
        VALUES (${userId}, 'standard', 'active', 3, NOW(), NOW() + INTERVAL '1 year')
      `;
    }

    // Create the team
    const teams = await sql`
      INSERT INTO teams (name, sport, season, owner_id)
      VALUES (${name}, ${sport}, ${season}, ${userId})
      RETURNING id, name, sport, season, created_at
    `;

    const team = teams[0];

    // Create team ownership record
    await sql`
      INSERT INTO team_ownership (user_id, team_id, role)
      VALUES (${userId}, ${team.id}, 'owner')
    `;

    // Add user as coach member
    await sql`
      INSERT INTO team_members (user_id, team_id, role)
      VALUES (${userId}, ${team.id}, 'Coach')
    `;

    return Response.json(
      {
        team,
        message: "Team created successfully",
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Create demo team error:", error);
    console.error("Error details:", {
      name: error?.name || "Unknown",
      message: error?.message || "No message",
      stack: error?.stack?.substring(0, 500) || "No stack trace",
      fullError: JSON.stringify(error, Object.getOwnPropertyNames(error)),
    });

    // Return the actual error message for debugging
    return Response.json(
      {
        message: error?.message || "Unknown error occurred",
        error: error?.name || "Error",
        details: error?.stack?.substring(0, 200) || "No details available",
      },
      { status: 500 },
    );
  }
}
