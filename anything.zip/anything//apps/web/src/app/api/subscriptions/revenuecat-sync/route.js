import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

const PLAN_LIMITS = { standard: 1, plus: 3, pro: null };

export async function POST(request) {
  try {
    const user = await getAuthUser(request);
    const userId = user?.id;

    if (!userId) {
      console.error("[RevenueCat Sync] No valid session found");
      console.error("[RevenueCat Sync] Headers:", {
        hasAuth: !!request.headers.get("Authorization"),
        hasSessionToken: !!request.headers.get("X-Session-Token"),
      });
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json().catch(() => ({}));
    const { planType } = body || {};

    console.log(
      "[RevenueCat Sync] Syncing plan for user:",
      userId,
      "plan:",
      planType,
    );

    if (!planType || !["standard", "plus", "pro"].includes(planType)) {
      console.error("[RevenueCat Sync] Invalid planType:", planType);
      return Response.json({ error: "Invalid planType" }, { status: 400 });
    }

    const existing =
      await sql`SELECT id FROM user_subscriptions WHERE user_id = ${userId} LIMIT 1`;
    const teamLimit = PLAN_LIMITS[planType];

    if (existing.length) {
      await sql`
        UPDATE user_subscriptions
        SET plan_type = ${planType}, status = 'active', updated_at = NOW(), team_limit = ${teamLimit}
        WHERE id = ${existing[0].id}
      `;
      console.log(
        "[RevenueCat Sync] Updated existing subscription:",
        existing[0].id,
      );
    } else {
      await sql`
        INSERT INTO user_subscriptions (user_id, plan_type, status, team_limit, created_at, updated_at)
        VALUES (${userId}, ${planType}, 'active', ${teamLimit}, NOW(), NOW())
      `;
      console.log(
        "[RevenueCat Sync] Created new subscription for user:",
        userId,
      );
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error("[RevenueCat Sync] Failed to sync subscription:", error);
    console.error("[RevenueCat Sync] Error stack:", error.stack);
    return Response.json(
      { error: "Failed to sync subscription", details: error.message },
      { status: 500 },
    );
  }
}
