import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

export async function POST(request) {
  try {
    const body = await request.json();

    // Check if this is an authenticated user updating their own profile
    const user = await getAuthUser(request);

    if (user && body.teamId && !body.firstName) {
      // This is a player updating their own profile during onboarding
      const { teamId, parentEmail } = body;

      // Update parent email in user profile if provided
      if (parentEmail) {
        // Store parent email in the user's location field temporarily
        // (You may want to add a dedicated parent_email field to auth_users table)
        await sql`
          UPDATE auth_users
          SET location = ${parentEmail}
          WHERE id = ${parseInt(user.id)}
        `;
      }

      return Response.json({
        success: true,
        message: "Profile updated successfully",
      });
    }

    // Original functionality: Coach adding a new player
    const {
      firstName,
      lastName,
      email,
      phone,
      address,
      emergencyContact,
      emergencyPhone,
      notes,
      teamId,
    } = body;

    // Validate required fields
    if (!firstName || !lastName) {
      return Response.json(
        { error: "First name and last name are required" },
        { status: 400 },
      );
    }

    // Create user account for the player
    const userResult = await sql`
      INSERT INTO auth_users (name, email, phone, bio)
      VALUES (${firstName + " " + lastName}, ${email || null}, ${phone || null}, ${notes || null})
      RETURNING id
    `;

    const playerId = userResult[0].id;

    // Add the player to the team
    if (teamId) {
      await sql`
        INSERT INTO team_members (team_id, user_id, role)
        VALUES (${teamId}, ${playerId}, 'Player')
      `;
    }

    return Response.json({
      success: true,
      playerId,
      message: "Player added successfully",
    });
  } catch (error) {
    console.error("Error adding player:", error);
    return Response.json({ error: "Failed to add player" }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const teamId = url.searchParams.get("teamId");

    if (!teamId) {
      return Response.json({ error: "Team ID is required" }, { status: 400 });
    }

    // Get all team members with user details
    const players = await sql`
      SELECT 
        tm.id as membership_id,
        tm.role,
        tm.position,
        tm.jersey_number,
        tm.joined_at,
        u.id as user_id,
        u.name,
        u.email,
        u.phone,
        u.image,
        u.bio as notes
      FROM team_members tm
      JOIN auth_users u ON tm.user_id = u.id
      WHERE tm.team_id = ${teamId}
      ORDER BY tm.role, u.name
    `;

    const formattedPlayers = players.map((player) => ({
      id: player.user_id,
      membershipId: player.membership_id,
      name: player.name,
      email: player.email || "",
      phone: player.phone || "",
      role: player.role,
      position: player.position,
      jerseyNumber: player.jersey_number,
      notes: player.notes || "",
      image: player.image || null,
      isActive: true,
      joinedAt: player.joined_at,
    }));

    return Response.json({ players: formattedPlayers });
  } catch (error) {
    console.error("Error fetching players:", error);
    return Response.json({ error: "Failed to fetch players" }, { status: 500 });
  }
}
