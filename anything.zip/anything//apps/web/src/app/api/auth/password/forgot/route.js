import sql from "@/app/api/utils/sql";
import crypto from "crypto";

export async function POST(request) {
  try {
    const { email } = await request.json();

    if (!email || typeof email !== "string") {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    // Find user by email
    const users =
      await sql`SELECT id, email FROM auth_users WHERE LOWER(email) = LOWER(${email}) LIMIT 1`;

    // Generate a token regardless of whether the user exists to avoid user enumeration
    const token = crypto.randomBytes(32).toString("hex");
    const expires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    if (users && users.length > 0) {
      // Save token
      await sql`INSERT INTO auth_verification_token (identifier, expires, token) VALUES (${users[0].email}, ${expires}, ${token})`;
    }

    const appUrl = process.env.APP_URL || process.env.AUTH_URL || "";
    const resetUrl = `${appUrl}/account/reset-password?token=${encodeURIComponent(token)}`;

    // Try sending an email via the selected integration (e.g., Resend)
    // NOTE: You need to enable the Resend integration in the editor for this to send.
    // We still return success either way to prevent user enumeration and for good UX.
    try {
      // Example placeholder call – replace with actual integration call once selected
      // await fetch("/integrations/resend", {
      //   method: "POST",
      //   headers: { "Content-Type": "application/json" },
      //   body: JSON.stringify({
      //     to: email,
      //     subject: "Reset your password",
      //     html: `<p>Click the link below to reset your password:</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>This link expires in 1 hour.</p>`,
      //   }),
      // });
    } catch (e) {
      console.warn(
        "Email integration not configured or failed to send. Reset URL:",
        resetUrl,
      );
    }

    const payload = { ok: true };
    if ((process.env.ENV || process.env.NODE_ENV) !== "production") {
      payload.debugResetUrl = resetUrl;
    }

    return Response.json(payload);
  } catch (err) {
    console.error("Forgot password error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
