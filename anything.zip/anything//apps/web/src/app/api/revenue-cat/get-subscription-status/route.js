import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Map entitlements to team limits
const SUBSCRIPTION_TIERS = {
  standard: { teamLimit: 1, name: "Standard" },
  plus: { teamLimit: 3, name: "Plus" },
  pro: { teamLimit: 10, name: "Pro" },
};

export async function POST(request) {
  try {
    const user = await getAuthUser(request);
    if (!user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const userId = user.id;
    const projectId = "projee26e916";

    // First check user_subscriptions table (this is where revenuecat-sync writes to)
    const subResults = await sql`
      SELECT plan_type, status, team_limit
      FROM user_subscriptions
      WHERE user_id = ${userId} AND status = 'active'
      LIMIT 1
    `;

    if (subResults.length > 0) {
      const subscription = subResults[0];
      const tierConfig = SUBSCRIPTION_TIERS[subscription.plan_type];

      if (tierConfig) {
        return Response.json({
          hasAccess: true,
          tier: subscription.plan_type,
          teamLimit: subscription.team_limit || tierConfig.teamLimit,
          tierName: tierConfig.name,
        });
      }
    }

    // Fallback to auth_users.subscription_status and RevenueCat API check
    const results = await sql`
      SELECT subscription_status, last_check_subscription_status_at
      FROM auth_users
      WHERE id = ${userId}
    `;

    if (!results.length) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const { subscription_status, last_check_subscription_status_at } =
      results[0];
    const oneDayAgo = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000);
    const isStatusStale =
      !last_check_subscription_status_at ||
      new Date(last_check_subscription_status_at) < oneDayAgo;

    if (!subscription_status || isStatusStale) {
      try {
        const response = await fetch(
          `https://api.revenuecat.com/v2/projects/${projectId}/customers/${encodeURIComponent(userId)}`,
          {
            headers: {
              Authorization: `Bearer ${process.env.REVENUE_CAT_API_KEY}`,
              "Content-Type": "application/json",
            },
          },
        );

        if (response.ok) {
          const data = await response.json();
          const activeEntitlements = data.active_entitlements?.items || [];
          const hasAccess = activeEntitlements.length > 0;

          // Determine tier based on active entitlements (highest tier wins)
          let tier = null;
          let teamLimit = 0;

          for (const entitlement of activeEntitlements) {
            const entitlementKey = entitlement.entitlement?.lookup_key;
            if (SUBSCRIPTION_TIERS[entitlementKey]) {
              const currentTier = SUBSCRIPTION_TIERS[entitlementKey];
              if (currentTier.teamLimit > teamLimit) {
                tier = entitlementKey;
                teamLimit = currentTier.teamLimit;
              }
            }
          }

          await sql`
            UPDATE auth_users
            SET subscription_status = ${hasAccess && tier ? tier : "inactive"},
                last_check_subscription_status_at = NOW()
            WHERE id = ${userId}
          `;

          if (!hasAccess || !tier) {
            return Response.json({
              hasAccess: false,
              tier: null,
              teamLimit: 0,
              tierName: null,
            });
          }

          return Response.json({
            hasAccess: true,
            tier,
            teamLimit,
            tierName: SUBSCRIPTION_TIERS[tier].name,
          });
        } else if (response.status === 404) {
          await sql`
            UPDATE auth_users
            SET subscription_status = 'inactive',
                last_check_subscription_status_at = NOW()
            WHERE id = ${userId}
          `;

          return Response.json({
            hasAccess: false,
            tier: null,
            teamLimit: 0,
            tierName: null,
          });
        }
      } catch (error) {
        console.error("Error fetching from RevenueCat:", error);
      }
    }

    if (subscription_status && subscription_status !== "inactive") {
      const tierConfig = SUBSCRIPTION_TIERS[subscription_status];

      if (tierConfig) {
        return Response.json({
          hasAccess: true,
          tier: subscription_status,
          teamLimit: tierConfig.teamLimit,
          tierName: tierConfig.name,
        });
      }
    }

    return Response.json({
      hasAccess: false,
      tier: null,
      teamLimit: 0,
      tierName: null,
    });
  } catch (error) {
    console.error("Error in subscription info:", error);
    return Response.json(
      { error: error.message || "Failed to load subscription info" },
      { status: 500 },
    );
  }
}
