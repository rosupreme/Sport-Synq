import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

const SUBSCRIPTION_TIERS = {
  standard: { teamLimit: 1 },
  plus: { teamLimit: 3 },
  pro: { teamLimit: 10 },
};

export async function POST(request) {
  try {
    const user = await getAuthUser(request);
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;

    // Get user's subscription from user_subscriptions table
    const subscriptionResults = await sql`
      SELECT plan_type, status, team_limit
      FROM user_subscriptions
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
      LIMIT 1
    `;

    let subscriptionStatus = null;
    let teamLimit = 0;

    if (subscriptionResults.length > 0) {
      const subscription = subscriptionResults[0];
      // Only use active subscriptions
      if (subscription.status === "active") {
        subscriptionStatus = subscription.plan_type;
        // Use the team_limit from the subscription table if available
        teamLimit =
          subscription.team_limit ||
          SUBSCRIPTION_TIERS[subscriptionStatus]?.teamLimit ||
          0;
      }
    }

    // No subscription or inactive = no teams allowed
    if (!subscriptionStatus) {
      return Response.json({
        canCreateTeam: false,
        currentTeamCount: 0,
        teamLimit: 0,
        tier: null,
        requiresSubscription: true,
      });
    }

    // Count user's current teams
    const teamCountResults = await sql`
      SELECT COUNT(*) as team_count
      FROM team_ownership
      WHERE user_id = ${userId}
    `;

    const currentTeamCount = parseInt(teamCountResults[0].team_count);
    const canCreateTeam = currentTeamCount < teamLimit;

    return Response.json({
      canCreateTeam,
      currentTeamCount,
      teamLimit,
      tier: subscriptionStatus,
      requiresSubscription: false,
    });
  } catch (error) {
    console.error("Error checking team limit:", error);
    return Response.json(
      { error: error.message || "Failed to check team limit" },
      { status: 500 },
    );
  }
}
