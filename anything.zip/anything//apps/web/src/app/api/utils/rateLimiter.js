// Simple in-memory rate limiter for auth endpoints
const attempts = new Map();

// Clean up old entries every 5 minutes
setInterval(
  () => {
    const now = Date.now();
    for (const [key, data] of attempts.entries()) {
      if (now - data.resetTime > 5 * 60 * 1000) {
        // 5 minutes
        attempts.delete(key);
      }
    }
  },
  5 * 60 * 1000,
);

export function checkRateLimit(
  identifier,
  maxAttempts = 5,
  windowMs = 15 * 60 * 1000,
) {
  const now = Date.now();
  const key = identifier;

  if (!attempts.has(key)) {
    attempts.set(key, {
      count: 1,
      resetTime: now,
      blocked: false,
    });
    return { allowed: true, remaining: maxAttempts - 1 };
  }

  const attempt = attempts.get(key);

  // Reset if window has passed
  if (now - attempt.resetTime > windowMs) {
    attempt.count = 1;
    attempt.resetTime = now;
    attempt.blocked = false;
    return { allowed: true, remaining: maxAttempts - 1 };
  }

  // Increment attempt count
  attempt.count++;

  if (attempt.count > maxAttempts) {
    attempt.blocked = true;
    return {
      allowed: false,
      remaining: 0,
      retryAfter: Math.ceil((attempt.resetTime + windowMs - now) / 1000),
    };
  }

  return {
    allowed: true,
    remaining: maxAttempts - attempt.count,
  };
}

export function getClientIP(request) {
  // Try to get real IP from various headers
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }

  const realIP = request.headers.get("x-real-ip");
  if (realIP) {
    return realIP;
  }

  const connectingIP = request.headers.get("x-connecting-ip");
  if (connectingIP) {
    return connectingIP;
  }

  // Fallback - this won't work in production but useful for development
  return "unknown";
}
