import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// POST - Toggle vote on feedback
export async function POST(request, { params }) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;
    const feedbackId = params.id;

    // Check if feedback exists
    const feedback = await sql`
      SELECT id FROM feedback WHERE id = ${feedbackId}
    `;

    if (feedback.length === 0) {
      return Response.json({ error: "Feedback not found" }, { status: 404 });
    }

    // Check if user already voted
    const existingVote = await sql`
      SELECT id FROM feedback_votes 
      WHERE feedback_id = ${feedbackId} AND user_id = ${userId}
    `;

    if (existingVote.length > 0) {
      // User already voted - remove vote
      await sql.transaction([
        sql`DELETE FROM feedback_votes WHERE feedback_id = ${feedbackId} AND user_id = ${userId}`,
        sql`UPDATE feedback SET votes = votes - 1 WHERE id = ${feedbackId}`,
      ]);

      return Response.json({ voted: false, message: "Vote removed" });
    } else {
      // User hasn't voted - add vote
      await sql.transaction([
        sql`INSERT INTO feedback_votes (feedback_id, user_id) VALUES (${feedbackId}, ${userId})`,
        sql`UPDATE feedback SET votes = votes + 1 WHERE id = ${feedbackId}`,
      ]);

      return Response.json({ voted: true, message: "Vote added" });
    }
  } catch (error) {
    console.error("Error voting on feedback:", error);
    return Response.json(
      { error: "Failed to vote on feedback" },
      { status: 500 },
    );
  }
}
