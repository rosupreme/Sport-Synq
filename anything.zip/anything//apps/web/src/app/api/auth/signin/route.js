import sql from "@/app/api/utils/sql";
import argon2 from "argon2";
import { checkRateLimit, getClientIP } from "@/app/api/utils/rateLimiter";

// Test endpoint to verify route is working
export async function GET() {
  return Response.json({
    message: "Sign in endpoint is working",
    timestamp: new Date().toISOString(),
  });
}

export async function POST(request) {
  try {
    const { email, password } = await request.json();

    // Validate input
    if (!email || !password) {
      return Response.json(
        { message: "Email and password are required" },
        { status: 400 },
      );
    }

    // Rate limiting - 5 attempts per 15 minutes per IP
    const clientIP = getClientIP(request);
    const rateLimitResult = checkRateLimit(
      `signin:${clientIP}`,
      5,
      15 * 60 * 1000,
    );

    if (!rateLimitResult.allowed) {
      return Response.json(
        {
          message: `Too many sign in attempts. Please try again in ${rateLimitResult.retryAfter} seconds.`,
          retryAfter: rateLimitResult.retryAfter,
        },
        { status: 429 },
      );
    }

    // Find user by email
    const users = await sql`
      SELECT id, name, email 
      FROM auth_users 
      WHERE email = ${email}
    `;

    if (users.length === 0) {
      return Response.json(
        { message: "Invalid email or password" },
        { status: 401 },
      );
    }

    const user = users[0];

    // Check password
    const accounts = await sql`
      SELECT password 
      FROM auth_accounts 
      WHERE "userId" = ${user.id} AND type = 'credentials'
    `;

    if (accounts.length === 0) {
      return Response.json(
        { message: "Invalid email or password" },
        { status: 401 },
      );
    }

    const account = accounts[0];

    // Verify password with argon2
    try {
      const isValidPassword = await argon2.verify(account.password, password);
      if (!isValidPassword) {
        return Response.json(
          { message: "Invalid email or password" },
          { status: 401 },
        );
      }
    } catch (error) {
      console.error("Password verification error:", error);
      return Response.json(
        { message: "Invalid email or password" },
        { status: 401 },
      );
    }

    // Create secure session token
    const sessionToken = `session_${user.id}_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;

    // Create session in database (30 days expiry)
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await sql`
      INSERT INTO auth_sessions ("userId", expires, "sessionToken")
      VALUES (${user.id}, ${expiresAt}, ${sessionToken})
    `;

    return Response.json(
      {
        success: true,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
        },
        sessionToken,
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Sign in error:", error);
    return Response.json({ message: "Internal server error" }, { status: 500 });
  }
}
