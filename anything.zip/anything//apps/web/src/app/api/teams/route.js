import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Create a new team
export async function POST(request) {
  try {
    // Get authenticated user
    const user = await getAuthUser(request);
    if (!user) {
      return Response.json(
        { message: "Authentication required" },
        { status: 401 },
      );
    }

    const userId = parseInt(user.id);

    // Read request body
    const bodyText = await request.text();

    let formData;
    try {
      formData = JSON.parse(bodyText);
    } catch (parseError) {
      return Response.json(
        { message: "Invalid JSON in request body" },
        { status: 400 },
      );
    }

    const { name, sport = "Soccer", season = "2024-25" } = formData;

    if (!name) {
      return Response.json(
        { message: "Team name is required" },
        { status: 400 },
      );
    }

    // Generate a unique invite code (6 characters)
    const generateInviteCode = () => {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // Removed confusing chars like I, O, 0, 1
      let code = "";
      for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return code;
    };

    let inviteCode = generateInviteCode();
    let attempts = 0;
    const maxAttempts = 10;

    // Ensure unique invite code
    while (attempts < maxAttempts) {
      const existing = await sql`
        SELECT id FROM teams WHERE invite_code = ${inviteCode} LIMIT 1
      `;
      if (existing.length === 0) {
        break;
      }
      inviteCode = generateInviteCode();
      attempts++;
    }

    // Create the team with invite code
    const teams = await sql`
      INSERT INTO teams (name, sport, season, owner_id, invite_code)
      VALUES (${name}, ${sport}, ${season}, ${userId}, ${inviteCode})
      RETURNING id, name, sport, season, created_at, invite_code
    `;

    const team = teams[0];

    // Create team ownership record
    await sql`
      INSERT INTO team_ownership (user_id, team_id, role)
      VALUES (${userId}, ${team.id}, 'owner')
    `;

    // Add user as coach member
    await sql`
      INSERT INTO team_members (user_id, team_id, role)
      VALUES (${userId}, ${team.id}, 'Coach')
    `;

    const response = Response.json(
      {
        team,
        message: "Team created successfully",
      },
      { status: 201 },
    );
    return response;
  } catch (error) {
    return Response.json(
      {
        message: "Internal server error",
        error: error.message,
        stack: error.stack,
      },
      { status: 500 },
    );
  }
}

// Get user's teams
export async function GET(request) {
  try {
    // Get authenticated user
    const user = await getAuthUser(request);
    if (!user) {
      return Response.json(
        { message: "Authentication required" },
        { status: 401 },
      );
    }

    const userId = parseInt(user.id);

    // Check if requesting a specific team by ID
    const url = new URL(request.url);
    const teamId = url.searchParams.get("teamId");

    if (teamId) {
      // Fetch single team by ID
      const teams = await sql`
        SELECT 
          t.id,
          t.name,
          t.sport,
          t.season,
          t.created_at,
          t.invite_code,
          COALESCE(to_.role, tm.role) as user_role,
          CASE WHEN t.owner_id = ${userId} THEN true ELSE false END as is_owner,
          COUNT(tm_all.id) as member_count
        FROM teams t
        LEFT JOIN team_ownership to_ ON t.id = to_.team_id AND to_.user_id = ${userId}
        LEFT JOIN team_members tm ON t.id = tm.team_id AND tm.user_id = ${userId}
        LEFT JOIN team_members tm_all ON t.id = tm_all.team_id
        WHERE t.id = ${parseInt(teamId)}
          AND (to_.user_id = ${userId} OR tm.user_id = ${userId})
        GROUP BY t.id, t.name, t.sport, t.season, t.created_at, t.invite_code, to_.role, tm.role, t.owner_id
      `;

      if (teams.length === 0) {
        return Response.json(
          { message: "Team not found or access denied" },
          { status: 404 },
        );
      }

      return Response.json({ team: teams[0] });
    }

    // Get all teams where user is owner, manager, or coach
    const teams = await sql`
      SELECT 
        t.id,
        t.name,
        t.sport,
        t.season,
        t.created_at,
        t.invite_code,  -- expose invite code so coaches can share it
        COALESCE(to_.role, tm.role) as user_role,
        CASE WHEN t.owner_id = ${userId} THEN true ELSE false END as is_owner,
        COUNT(tm_all.id) as member_count
      FROM teams t
      LEFT JOIN team_ownership to_ ON t.id = to_.team_id AND to_.user_id = ${userId}
      LEFT JOIN team_members tm ON t.id = tm.team_id AND tm.user_id = ${userId}
      LEFT JOIN team_members tm_all ON t.id = tm_all.team_id
      WHERE (to_.user_id = ${userId} OR tm.user_id = ${userId})
      GROUP BY t.id, t.name, t.sport, t.season, t.created_at, t.invite_code, to_.role, tm.role, t.owner_id
      ORDER BY t.created_at DESC
    `;

    return Response.json({ teams });
  } catch (error) {
    return Response.json({ message: "Internal server error" }, { status: 500 });
  }
}
