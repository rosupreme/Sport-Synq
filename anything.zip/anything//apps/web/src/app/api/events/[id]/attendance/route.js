import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

const ok = (data, init = {}) => Response.json(data, { status: 200, ...init });
const bad = (message, status = 400) =>
  Response.json({ error: message }, { status });

export async function GET(request, { params: { id } }) {
  try {
    // Require authentication
    const user = await getAuthUser(request);
    if (!user?.id) {
      return bad("Unauthorized", 401);
    }

    const eventId = parseInt(id, 10);
    if (!eventId || Number.isNaN(eventId)) {
      return bad("Invalid event id", 400);
    }

    const eventRows = await sql(
      "SELECT id, team_id FROM events WHERE id = $1",
      [eventId],
    );
    if (eventRows.length === 0) {
      return bad("Event not found", 404);
    }
    const teamId = eventRows[0].team_id;

    // Verify user has access to this event's team
    const accessCheck = await sql`
      SELECT 1 FROM team_members WHERE team_id = ${teamId} AND user_id = ${user.id}
      UNION
      SELECT 1 FROM team_ownership WHERE team_id = ${teamId} AND user_id = ${user.id}
      LIMIT 1
    `;

    if (accessCheck.length === 0) {
      return bad("Access denied", 403);
    }

    const rows = await sql(
      `SELECT a.event_id, a.user_id, a.status, u.name, u.email
       FROM event_attendance a
       JOIN auth_users u ON u.id = a.user_id
       WHERE a.event_id = $1
       ORDER BY u.name ASC NULLS LAST`,
      [eventId],
    );

    const invitedRows = await sql(
      `SELECT COUNT(*)::int AS count
       FROM team_members
       WHERE team_id = $1 AND role = 'Player'`,
      [teamId],
    );
    const totalInvited = invitedRows?.[0]?.count ?? 0;

    const grouped = { going: [], not_going: [], maybe: [] };
    for (const r of rows) {
      if (!grouped[r.status]) continue;
      grouped[r.status].push({ id: r.user_id, name: r.name || r.email });
    }

    const counts = {
      going: grouped.going.length,
      not_going: grouped.not_going.length,
      maybe: grouped.maybe.length,
    };

    return ok({ eventId, totalInvited, counts, attendees: grouped });
  } catch (error) {
    console.error("[GET /api/events/:id/attendance]", error);
    return bad("Failed to load attendance", 500);
  }
}

export async function POST(request, { params: { id } }) {
  try {
    // Require authentication - use authenticated user's ID, not body param
    const user = await getAuthUser(request);
    if (!user?.id) {
      return bad("Unauthorized", 401);
    }

    const eventId = parseInt(id, 10);
    if (!eventId || Number.isNaN(eventId)) {
      return bad("Invalid event id", 400);
    }

    const body = await request.json();
    const status = String(body?.status || "").toLowerCase();

    const allowed = new Set(["going", "not_going", "maybe"]);
    if (!allowed.has(status)) {
      return bad("Invalid status", 400);
    }

    // Verify user is a member of the event's team
    const eventRows = await sql(
      "SELECT id, team_id FROM events WHERE id = $1",
      [eventId],
    );
    if (eventRows.length === 0) {
      return bad("Event not found", 404);
    }
    const teamId = eventRows[0].team_id;

    const accessCheck = await sql`
      SELECT 1 FROM team_members WHERE team_id = ${teamId} AND user_id = ${user.id}
      UNION
      SELECT 1 FROM team_ownership WHERE team_id = ${teamId} AND user_id = ${user.id}
      LIMIT 1
    `;

    if (accessCheck.length === 0) {
      return bad("Access denied", 403);
    }

    // Use authenticated user's ID for the RSVP
    await sql(
      `INSERT INTO event_attendance (event_id, user_id, status)
       VALUES ($1, $2, $3)
       ON CONFLICT (event_id, user_id)
       DO UPDATE SET status = EXCLUDED.status, updated_at = now()`,
      [eventId, user.id, status],
    );

    const rows = await sql(
      `SELECT status, COUNT(*)::int as count
       FROM event_attendance
       WHERE event_id = $1
       GROUP BY status`,
      [eventId],
    );
    const counts = { going: 0, not_going: 0, maybe: 0 };
    for (const r of rows) counts[r.status] = r.count;

    return ok({ success: true, eventId, status, counts });
  } catch (error) {
    console.error("[POST /api/events/:id/attendance]", error);
    return bad("Failed to save RSVP", 500);
  }
}
