import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Helper to send Expo push notifications
async function sendExpoPush(messages) {
  try {
    if (!messages || messages.length === 0) return;
    const res = await fetch("https://exp.host/--/api/v2/push/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(messages),
    });

    const data = await res.json().catch(() => ({}));
    return data;
  } catch (err) {}
}

// Update an existing event
export async function PUT(request, { params }) {
  try {
    const { id } = params;

    // Authenticate user
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;
    const body = await request.json();

    const { title, description, event_type, event_date, event_time, location } =
      body;

    // Validate required fields
    if (!title || !event_date || !event_time) {
      return Response.json(
        {
          error:
            "Missing required fields: title, event_date, and event_time are required",
        },
        { status: 400 },
      );
    }

    // Check if event exists and user has permission to edit it
    const existingEvent = await sql`
      SELECT e.*, t.name as team_name
      FROM events e
      JOIN teams t ON e.team_id = t.id
      WHERE e.id = ${id}
      LIMIT 1
    `;

    if (existingEvent.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    const event = existingEvent[0];

    // Check if user is coach/owner of the team
    const teamMembership = await sql`
      SELECT role 
      FROM team_members 
      WHERE team_id = ${event.team_id} AND user_id = ${userId}
      UNION
      SELECT 'owner' as role
      FROM team_ownership
      WHERE team_id = ${event.team_id} AND user_id = ${userId}
    `;

    const isCoach =
      teamMembership.length > 0 &&
      (teamMembership[0].role === "Coach" ||
        teamMembership[0].role === "owner");

    if (!isCoach) {
      return Response.json(
        { error: "Only coaches can edit events" },
        { status: 403 },
      );
    }

    // Update the event
    const result = await sql`
      UPDATE events
      SET 
        title = ${title},
        description = ${description || null},
        event_type = ${event_type || "practice"},
        event_date = ${event_date},
        event_time = ${event_time},
        location = ${location || null},
        updated_at = NOW()
      WHERE id = ${id}
      RETURNING *
    `;

    const updatedEvent = result[0];

    // Send push notifications to players about the event update
    const rows = await sql`
      SELECT u.id as user_id, u.name, s.expo_push_token
      FROM team_members m
      JOIN auth_users u ON u.id = m.user_id
      LEFT JOIN user_notification_settings s ON s.user_id = u.id
      WHERE m.team_id = ${event.team_id}
        AND m.role = 'Player'
        AND s.push_enabled = true
        AND s.expo_push_token IS NOT NULL
    `;

    const tokens = rows.map((r) => r.expo_push_token).filter(Boolean);

    if (tokens.length) {
      const niceType = (updatedEvent.event_type || "event")
        .replace(/_/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase());
      const titleMsg = `${niceType} Updated`;
      const when = `${updatedEvent.event_date} ${updatedEvent.event_time}`;
      const bodyMsg = `${updatedEvent.title} has been updated - ${when}${updatedEvent.location ? " at " + updatedEvent.location : ""}`;

      const messages = tokens.map((to) => ({
        to,
        sound: "default",
        title: titleMsg,
        body: bodyMsg,
        data: {
          type: "event_updated",
          eventId: updatedEvent.id,
          teamId: updatedEvent.team_id,
        },
      }));

      await sendExpoPush(messages);
    }

    return Response.json(
      {
        message: "Event updated successfully",
        event: updatedEvent,
      },
      { status: 200 },
    );
  } catch (error) {
    return Response.json({ error: "Failed to update event" }, { status: 500 });
  }
}

// Delete an event
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    // Authenticate user
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;

    // Check if event exists and user has permission to delete it
    const existingEvent = await sql`
      SELECT e.*, t.name as team_name
      FROM events e
      JOIN teams t ON e.team_id = t.id
      WHERE e.id = ${id}
      LIMIT 1
    `;

    if (existingEvent.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    const event = existingEvent[0];

    // Check if user is coach/owner of the team
    const teamMembership = await sql`
      SELECT role 
      FROM team_members 
      WHERE team_id = ${event.team_id} AND user_id = ${userId}
      UNION
      SELECT 'owner' as role
      FROM team_ownership
      WHERE team_id = ${event.team_id} AND user_id = ${userId}
    `;

    const isCoach =
      teamMembership.length > 0 &&
      (teamMembership[0].role === "Coach" ||
        teamMembership[0].role === "owner");

    if (!isCoach) {
      return Response.json(
        { error: "Only coaches can delete events" },
        { status: 403 },
      );
    }

    // Delete the event (this will also cascade delete attendance records)
    await sql`
      DELETE FROM events
      WHERE id = ${id}
    `;

    return Response.json(
      {
        message: "Event deleted successfully",
      },
      { status: 200 },
    );
  } catch (error) {
    return Response.json({ error: "Failed to delete event" }, { status: 500 });
  }
}
