import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Helper to send Expo push notifications
async function sendExpoPush(messages) {
  try {
    if (!messages || messages.length === 0) return;
    const res = await fetch("https://exp.host/--/api/v2/push/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(messages),
    });

    const data = await res.json().catch(() => ({}));
    return data;
  } catch (err) {}
}

// Get all events for the user's teams
export async function GET(request) {
  try {
    // Authenticate user
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const userId = user.id;

    // Get teamId from query parameters if provided
    const url = new URL(request.url);
    const teamId = url.searchParams.get("teamId");

    let events;

    if (teamId) {
      // Filter by specific team if teamId is provided
      events = await sql`
        SELECT 
          e.*, 
          t.name as team_name, 
          u.name as organizer_name,
          COUNT(DISTINCT CASE WHEN ea.status = 'going' THEN ea.user_id END)::int as going_count,
          COUNT(DISTINCT CASE WHEN ea.status = 'not_going' THEN ea.user_id END)::int as not_going_count,
          COUNT(DISTINCT CASE WHEN ea.status = 'maybe' THEN ea.user_id END)::int as maybe_count,
          COUNT(DISTINCT tm.user_id)::int as total_invited
        FROM events e
        JOIN teams t ON e.team_id = t.id
        JOIN auth_users u ON e.organizer_id = u.id
        LEFT JOIN event_attendance ea ON ea.event_id = e.id
        LEFT JOIN team_members tm ON tm.team_id = e.team_id AND tm.role = 'Player'
        WHERE e.team_id = ${teamId}
        AND e.team_id IN (
          SELECT team_id 
          FROM team_members 
          WHERE user_id = ${userId}
          UNION
          SELECT team_id 
          FROM team_ownership 
          WHERE user_id = ${userId}
        )
        GROUP BY e.id, t.name, u.name
        ORDER BY e.event_date ASC, e.event_time ASC
      `;
    } else {
      // Get events for all teams the user belongs to
      events = await sql`
        SELECT 
          e.*, 
          t.name as team_name, 
          u.name as organizer_name,
          COUNT(DISTINCT CASE WHEN ea.status = 'going' THEN ea.user_id END)::int as going_count,
          COUNT(DISTINCT CASE WHEN ea.status = 'not_going' THEN ea.user_id END)::int as not_going_count,
          COUNT(DISTINCT CASE WHEN ea.status = 'maybe' THEN ea.user_id END)::int as maybe_count,
          COUNT(DISTINCT tm.user_id)::int as total_invited
        FROM events e
        JOIN teams t ON e.team_id = t.id
        JOIN auth_users u ON e.organizer_id = u.id
        LEFT JOIN event_attendance ea ON ea.event_id = e.id
        LEFT JOIN team_members tm ON tm.team_id = e.team_id AND tm.role = 'Player'
        WHERE e.team_id IN (
          SELECT team_id 
          FROM team_members 
          WHERE user_id = ${userId}
          UNION
          SELECT team_id 
          FROM team_ownership 
          WHERE user_id = ${userId}
        )
        GROUP BY e.id, t.name, u.name
        ORDER BY e.event_date ASC, e.event_time ASC
      `;
    }

    return Response.json({ events });
  } catch (error) {
    return Response.json({ error: "Failed to fetch events" }, { status: 500 });
  }
}

// Create a new event
export async function POST(request) {
  try {
    const user = await getAuthUser(request);

    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();

    const {
      title,
      description,
      event_type,
      event_date,
      event_time,
      location,
      team_id,
      is_recurring,
      recurrence_type,
      occurrences,
    } = body;

    // Validate required fields
    if (!title || !event_date || !event_time || !team_id) {
      return Response.json(
        {
          error:
            "Missing required fields: title, event_date, event_time, and team_id are required",
        },
        { status: 400 },
      );
    }

    const userId = user.id;

    // Helper function to generate recurring dates
    const generateRecurringDates = (startDate, recurrenceType, count) => {
      const dates = [];
      const start = new Date(startDate);

      for (let i = 0; i < count; i++) {
        const currentDate = new Date(start);

        if (recurrenceType === "daily") {
          currentDate.setDate(start.getDate() + i);
        } else if (recurrenceType === "weekly") {
          currentDate.setDate(start.getDate() + i * 7);
        } else if (recurrenceType === "monthly") {
          currentDate.setMonth(start.getMonth() + i);
        }

        // Format as YYYY-MM-DD for database
        const year = currentDate.getFullYear();
        const month = String(currentDate.getMonth() + 1).padStart(2, "0");
        const day = String(currentDate.getDate()).padStart(2, "0");
        dates.push(`${year}-${month}-${day}`);
      }

      return dates;
    };

    if (is_recurring && recurrence_type && occurrences) {
      // Create multiple recurring events

      const recurringDates = generateRecurringDates(
        event_date,
        recurrence_type,
        occurrences,
      );

      const createdEvents = [];

      for (const dateStr of recurringDates) {
        const result = await sql`
          INSERT INTO events (
            title, description, event_type, event_date, event_time, 
            location, team_id, organizer_id
          ) VALUES (
            ${title}, ${description || null}, ${event_type || "practice"}, 
            ${dateStr}, ${event_time}, ${location || null}, 
            ${team_id}, ${userId}
          ) RETURNING *
        `;
        createdEvents.push(result[0]);
      }

      // Send notifications for the first upcoming event only (to avoid spam)
      const firstEvent = createdEvents[0];
      if (firstEvent) {
        // Fetch all player tokens for the team who enabled push
        const rows = await sql`
          SELECT u.id as user_id, u.name, s.expo_push_token
          FROM team_members m
          JOIN auth_users u ON u.id = m.user_id
          LEFT JOIN user_notification_settings s ON s.user_id = u.id
          WHERE m.team_id = ${team_id}
            AND m.role = 'Player'
            AND s.push_enabled = true
            AND s.expo_push_token IS NOT NULL
        `;

        const tokens = rows.map((r) => r.expo_push_token).filter(Boolean);

        if (tokens.length) {
          const niceType = (firstEvent.event_type || "event")
            .replace(/_/g, " ")
            .replace(/\b\w/g, (c) => c.toUpperCase());
          const titleMsg = `New Recurring ${niceType}`;
          const when = `${firstEvent.event_date} ${firstEvent.event_time}`;
          const bodyMsg = `${firstEvent.title} starting ${when}${firstEvent.location ? " at " + firstEvent.location : ""} (${occurrences} events total)`;

          const messages = tokens.map((to) => ({
            to,
            sound: "default",
            title: titleMsg,
            body: bodyMsg,
            data: {
              type: "recurring_event_created",
              eventId: firstEvent.id,
              teamId: firstEvent.team_id,
              totalEvents: occurrences,
            },
          }));

          // Fire and await (best effort)
          await sendExpoPush(messages);
        }
      }

      return Response.json(
        {
          message: `${occurrences} recurring events created successfully`,
          events: createdEvents,
          count: createdEvents.length,
        },
        { status: 201 },
      );
    } else {
      // Create a single event
      const result = await sql`
        INSERT INTO events (
          title, description, event_type, event_date, event_time, 
          location, team_id, organizer_id
        ) VALUES (
          ${title}, ${description || null}, ${event_type || "practice"}, 
          ${event_date}, ${event_time}, ${location || null}, 
          ${team_id}, ${userId}
        ) RETURNING *
      `;

      const event = result[0];

      // Fetch all player tokens for the team who enabled push
      const rows = await sql`
        SELECT u.id as user_id, u.name, s.expo_push_token
        FROM team_members m
        JOIN auth_users u ON u.id = m.user_id
        LEFT JOIN user_notification_settings s ON s.user_id = u.id
        WHERE m.team_id = ${team_id}
          AND m.role = 'Player'
          AND s.push_enabled = true
          AND s.expo_push_token IS NOT NULL
      `;

      const tokens = rows.map((r) => r.expo_push_token).filter(Boolean);

      if (tokens.length) {
        const niceType = (event.event_type || "event")
          .replace(/_/g, " ")
          .replace(/\b\w/g, (c) => c.toUpperCase());
        const titleMsg = `New ${niceType}`;
        const when = `${event.event_date} ${event.event_time}`;
        const bodyMsg = `${event.title} on ${when}${event.location ? " at " + event.location : ""}`;

        const messages = tokens.map((to) => ({
          to,
          sound: "default",
          title: titleMsg,
          body: bodyMsg,
          data: {
            type: "event_created",
            eventId: event.id,
            teamId: event.team_id,
          },
        }));

        // Fire and await (best effort)
        await sendExpoPush(messages);
      }

      return Response.json(
        {
          message: "Event created successfully",
          event,
        },
        { status: 201 },
      );
    }
  } catch (error) {
    return Response.json({ error: "Failed to create event" }, { status: 500 });
  }
}
