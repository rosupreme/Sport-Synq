import sql from "@/app/api/utils/sql";
import argon2 from "argon2";
import { checkRateLimit, getClientIP } from "@/app/api/utils/rateLimiter";

// Password validation
function validatePassword(password) {
  if (password.length < 8) {
    return "Password must be at least 8 characters long";
  }
  if (!/[A-Z]/.test(password)) {
    return "Password must contain at least one uppercase letter";
  }
  if (!/[a-z]/.test(password)) {
    return "Password must contain at least one lowercase letter";
  }
  if (!/\d/.test(password)) {
    return "Password must contain at least one number";
  }
  return null;
}

export async function POST(request) {
  try {
    const { name, email, phone, password } = await request.json();

    // Validate input
    if (!name || !email || !password) {
      return Response.json(
        { message: "Name, email, and password are required" },
        { status: 400 },
      );
    }

    // Stronger password validation
    const passwordError = validatePassword(password);
    if (passwordError) {
      return Response.json({ message: passwordError }, { status: 400 });
    }

    // Rate limiting - 3 signup attempts per 10 minutes per IP
    const clientIP = getClientIP(request);
    const rateLimitResult = checkRateLimit(
      `mobile-signup:${clientIP}`,
      3,
      10 * 60 * 1000,
    );

    if (!rateLimitResult.allowed) {
      return Response.json(
        {
          message: `Too many signup attempts. Please try again in ${rateLimitResult.retryAfter} seconds.`,
          retryAfter: rateLimitResult.retryAfter,
        },
        { status: 429 },
      );
    }

    // Check if user already exists
    const existingUsers = await sql`
      SELECT id FROM auth_users WHERE email = ${email}
    `;

    if (existingUsers.length > 0) {
      return Response.json(
        { message: "An account with this email already exists" },
        { status: 409 },
      );
    }

    // Create user
    const users = await sql`
      INSERT INTO auth_users (name, email, phone, "emailVerified")
      VALUES (${name}, ${email}, ${phone || null}, NOW())
      RETURNING id, name, email, phone
    `;

    const user = users[0];

    // Hash password with argon2
    const hashedPassword = await argon2.hash(password);

    // Create credentials account with hashed password
    await sql`
      INSERT INTO auth_accounts ("userId", type, provider, "providerAccountId", password)
      VALUES (${user.id}, 'credentials', 'credentials', ${email}, ${hashedPassword})
    `;

    // Create secure session token
    const sessionToken = `session_${user.id}_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;

    // Create session in database (30 days expiry)
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await sql`
      INSERT INTO auth_sessions ("userId", expires, "sessionToken")
      VALUES (${user.id}, ${expiresAt}, ${sessionToken})
    `;

    return Response.json(
      {
        success: true,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
        },
        sessionToken,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Mobile sign up error:", error);
    return Response.json({ message: "Internal server error" }, { status: 500 });
  }
}

export async function GET() {
  return Response.json({ ok: true, route: "/api/mobile-auth/signup" });
}
