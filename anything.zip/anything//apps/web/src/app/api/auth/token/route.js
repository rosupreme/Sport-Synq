export async function GET(request) {
  try {
    // Extract sessionToken from cookies
    const cookieHeader = request.headers.get("Cookie");
    let sessionToken = null;

    if (cookieHeader) {
      const cookies = cookieHeader.split(";").reduce((acc, cookie) => {
        const [key, value] = cookie.trim().split("=");
        acc[key] = value;
        return acc;
      }, {});
      sessionToken = cookies.sessionToken;
    }

    if (!sessionToken) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: {
          "Content-Type": "application/json",
        },
      });
    }

    // Validate session and get user info
    const sql = (await import("@/app/api/utils/sql")).default;
    const sessions = await sql`
      SELECT s."userId", u.id, u.name, u.email
      FROM auth_sessions s
      JOIN auth_users u ON s."userId" = u.id
      WHERE s."sessionToken" = ${sessionToken} 
      AND s.expires > NOW()
      LIMIT 1
    `;

    if (sessions.length === 0) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: {
          "Content-Type": "application/json",
        },
      });
    }

    const user = sessions[0];

    return new Response(
      JSON.stringify({
        sessionToken: sessionToken,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
        },
      }),
      {
        headers: {
          "Content-Type": "application/json",
        },
      },
    );
  } catch (error) {
    console.error("Token endpoint error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }
}
