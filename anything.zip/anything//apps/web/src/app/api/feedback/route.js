import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// GET - List all feedback sorted by votes
export async function GET(request) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;

    // Get all feedback with user info and check if current user voted
    const feedback = await sql`
      SELECT 
        f.id,
        f.title,
        f.description,
        f.feedback_type,
        f.votes,
        f.status,
        f.created_at,
        u.name as author_name,
        u.id as author_id,
        EXISTS(
          SELECT 1 FROM feedback_votes 
          WHERE feedback_id = f.id AND user_id = ${userId}
        ) as user_has_voted
      FROM feedback f
      JOIN auth_users u ON f.user_id = u.id
      ORDER BY f.votes DESC, f.created_at DESC
    `;

    return Response.json({ feedback });
  } catch (error) {
    console.error("Error fetching feedback:", error);
    return Response.json(
      { error: "Failed to fetch feedback" },
      { status: 500 },
    );
  }
}

// POST - Create new feedback
export async function POST(request) {
  try {
    const session = await getAuthUser(request);
    if (!session?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.id;
    const body = await request.json();
    const { title, description, feedback_type = "feature" } = body;

    if (!title || title.trim().length === 0) {
      return Response.json({ error: "Title is required" }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO feedback (user_id, title, description, feedback_type, votes)
      VALUES (${userId}, ${title.trim()}, ${description?.trim() || ""}, ${feedback_type}, 0)
      RETURNING *
    `;

    return Response.json({ feedback: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating feedback:", error);
    return Response.json(
      { error: "Failed to create feedback" },
      { status: 500 },
    );
  }
}
