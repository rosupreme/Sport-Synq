import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// POST: Move user's teamless fundraisers to a team
// Body: { team_id: number, fundraiser_ids?: number[] }
export async function POST(request) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    let payload;
    try {
      payload = await request.json();
    } catch (_) {
      return Response.json({ error: "Invalid JSON" }, { status: 400 });
    }

    const teamIdRaw = payload?.team_id;
    const fundraiserIds = Array.isArray(payload?.fundraiser_ids)
      ? payload.fundraiser_ids
      : null;

    const teamId = Number(teamIdRaw);
    if (!teamId || Number.isNaN(teamId)) {
      return Response.json({ error: "team_id is required" }, { status: 400 });
    }

    // Ensure user has access to this team
    const access = await sql`
      SELECT 1 FROM team_members WHERE user_id = ${user.id} AND team_id = ${teamId}
      UNION
      SELECT 1 FROM team_ownership WHERE user_id = ${user.id} AND team_id = ${teamId}
      LIMIT 1
    `;
    if (access.length === 0) {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    // Build update query: only move fundraisers created by this user
    // If fundraiser_ids provided, restrict to that set; otherwise move all teamless
    if (fundraiserIds && fundraiserIds.length === 0) {
      return Response.json({ moved: 0 });
    }

    if (fundraiserIds) {
      // Defensive: coerce ids to numbers
      const ids = fundraiserIds
        .map((x) => Number(x))
        .filter((x) => !Number.isNaN(x));
      if (!ids.length) {
        return Response.json({ moved: 0 });
      }

      const result = await sql`
        UPDATE fundraisers
        SET team_id = ${teamId}, updated_at = NOW()
        WHERE organizer_id = ${user.id}
        AND id = ANY(${ids})
        RETURNING id
      `;
      return Response.json({
        moved: result.length,
        ids: result.map((r) => r.id),
      });
    }

    // Move all user's fundraisers that are currently teamless
    const result = await sql`
      UPDATE fundraisers
      SET team_id = ${teamId}, updated_at = NOW()
      WHERE organizer_id = ${user.id} AND team_id IS NULL
      RETURNING id
    `;

    return Response.json({
      moved: result.length,
      ids: result.map((r) => r.id),
    });
  } catch (error) {
    console.error("Fundraisers migrate error:", error);
    return Response.json(
      { error: "Failed to migrate fundraisers" },
      { status: 500 },
    );
  }
}
