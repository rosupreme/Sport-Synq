import sql from "@/app/api/utils/sql";
import argon2 from "argon2";

export async function POST(request) {
  try {
    const { token, newPassword } = await request.json();

    if (!token || typeof token !== "string") {
      return Response.json({ error: "Token is required" }, { status: 400 });
    }
    if (
      !newPassword ||
      typeof newPassword !== "string" ||
      newPassword.length < 8
    ) {
      return Response.json(
        { error: "New password must be at least 8 characters" },
        { status: 400 },
      );
    }

    // Validate token
    const tokens =
      await sql`SELECT identifier, expires FROM auth_verification_token WHERE token = ${token} LIMIT 1`;
    if (!tokens || tokens.length === 0) {
      return Response.json(
        { error: "Invalid or expired token" },
        { status: 400 },
      );
    }

    const { identifier, expires } = tokens[0];
    if (new Date(expires).getTime() < Date.now()) {
      return Response.json(
        { error: "Invalid or expired token" },
        { status: 400 },
      );
    }

    // Lookup user by identifier (email)
    const users =
      await sql`SELECT id FROM auth_users WHERE LOWER(email) = LOWER(${identifier}) LIMIT 1`;
    if (!users || users.length === 0) {
      return Response.json({ error: "User not found" }, { status: 400 });
    }
    const userId = users[0].id;

    // Find credentials account
    const accounts =
      await sql`SELECT id FROM auth_accounts WHERE "userId" = ${userId} AND type = 'credentials' LIMIT 1`;
    if (!accounts || accounts.length === 0) {
      return Response.json(
        { error: "Password reset is not available for this account" },
        { status: 400 },
      );
    }

    const accountId = accounts[0].id;

    // Update password (argon2 hash)
    const hashed = await argon2.hash(newPassword);
    await sql`UPDATE auth_accounts SET password = ${hashed} WHERE id = ${accountId}`;

    // Delete token and (optionally) invalidate sessions
    await sql`DELETE FROM auth_verification_token WHERE token = ${token}`;
    // await sql`DELETE FROM auth_sessions WHERE "userId" = ${userId}`;

    return Response.json({ success: true });
  } catch (err) {
    console.error("Password reset error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
