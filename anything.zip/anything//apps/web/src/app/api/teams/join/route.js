import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

export async function POST(request) {
  try {
    const user = await getAuthUser(request);
    if (!user) {
      return Response.json(
        { message: "Authentication required" },
        { status: 401 },
      );
    }

    let body = {};
    try {
      body = await request.json();
    } catch (e) {
      return Response.json({ message: "Invalid JSON" }, { status: 400 });
    }

    const code = (body.code || "").toUpperCase().trim();
    if (!code) {
      return Response.json({ message: "Code is required" }, { status: 400 });
    }

    // Find team by code
    const teams = await sql`
      SELECT id, name, sport, season, invite_code
      FROM teams
      WHERE UPPER(invite_code) = ${code}
      LIMIT 1
    `;

    if (teams.length === 0) {
      return Response.json(
        { message: "Team not found for this code" },
        { status: 404 },
      );
    }

    const team = teams[0];

    // Check if user is already a member
    const existing = await sql`
      SELECT id FROM team_members WHERE team_id = ${team.id} AND user_id = ${user.id} LIMIT 1
    `;

    if (existing.length > 0) {
      return Response.json({
        success: true,
        message: "Already a member",
        team: { id: team.id, name: team.name },
      });
    }

    // Add as Player by default
    await sql`
      INSERT INTO team_members (team_id, user_id, role)
      VALUES (${team.id}, ${user.id}, 'Player')
    `;

    return Response.json({
      success: true,
      team: {
        id: team.id,
        name: team.name,
        sport: team.sport,
        season: team.season,
      },
    });
  } catch (error) {
    console.error("Join team error:", error);
    return Response.json({ message: "Internal server error" }, { status: 500 });
  }
}
