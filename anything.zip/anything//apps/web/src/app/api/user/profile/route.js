import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

export async function POST(request) {
  try {
    const user = await getAuthUser(request);

    if (!user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { name, phone, location, bio, image } = body;

    // Update user profile in the database
    const updatedUser = await sql`
      UPDATE auth_users 
      SET 
        name = ${name || null},
        image = ${image || null},
        phone = ${phone || null},
        location = ${location || null},
        bio = ${bio || null}
      WHERE id = ${user.id}
      RETURNING id, name, email, image, phone, location, bio
    `;

    if (updatedUser.length === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    return Response.json({
      success: true,
      user: updatedUser[0],
    });
  } catch (error) {
    console.error("Error updating user profile:", error);
    return Response.json(
      { error: "Failed to update profile" },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const user = await getAuthUser(request);

    if (!user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Get user profile data
    const userData = await sql`
      SELECT id, name, email, image, phone, location, bio
      FROM auth_users 
      WHERE id = ${user.id}
    `;

    if (userData.length === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    return Response.json({
      user: userData[0],
    });
  } catch (error) {
    console.error("Error fetching user profile:", error);
    return Response.json({ error: "Failed to fetch profile" }, { status: 500 });
  }
}
