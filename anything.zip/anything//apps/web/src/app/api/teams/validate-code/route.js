import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

export async function GET(request) {
  try {
    // We allow unauthenticated validation too (players may be early in onboarding),
    // but if the token is present we validate it (no effect on result otherwise).
    await getAuthUser(request);

    const { searchParams } = new URL(request.url);
    const code = (searchParams.get("code") || "").toUpperCase().trim();

    if (!code || code.length < 4) {
      return Response.json(
        { valid: false, error: "Invalid code" },
        { status: 400 },
      );
    }

    const rows = await sql`
      SELECT id, name, sport, season, invite_code
      FROM teams
      WHERE UPPER(invite_code) = ${code}
      LIMIT 1
    `;

    if (rows.length === 0) {
      return Response.json({ valid: false });
    }

    const team = rows[0];
    return Response.json({
      valid: true,
      team: {
        id: team.id,
        name: team.name,
        sport: team.sport,
        season: team.season,
      },
    });
  } catch (error) {
    console.error("Validate code error:", error);
    return Response.json(
      { valid: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}
