import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

export async function GET(request) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const userId = user.id;

    const rows = await sql`
      SELECT user_id, push_enabled, email_enabled, game_reminders_enabled, expo_push_token
      FROM user_notification_settings
      WHERE user_id = ${userId}
    `;

    if (rows.length === 0) {
      return Response.json({
        settings: {
          pushEnabled: false,
          emailEnabled: false,
          gameRemindersEnabled: false,
          expoPushToken: null,
        },
      });
    }

    const r = rows[0];
    return Response.json({
      settings: {
        pushEnabled: !!r.push_enabled,
        emailEnabled: !!r.email_enabled,
        gameRemindersEnabled: !!r.game_reminders_enabled,
        expoPushToken: r.expo_push_token,
      },
    });
  } catch (error) {
    console.error("Error fetching notification settings:", error);
    return Response.json(
      { error: "Failed to fetch settings" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const session = await getAuthUser(request);
    if (!session?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const userId = session.id;
    const body = await request.json();

    const { pushEnabled, emailEnabled, gameRemindersEnabled } = body;
    const expoPushToken = Object.prototype.hasOwnProperty.call(
      body,
      "expoPushToken",
    )
      ? body.expoPushToken
      : undefined;

    // Ensure a row exists for this user (upsert pattern)
    await sql`
      INSERT INTO user_notification_settings (user_id)
      VALUES (${userId})
      ON CONFLICT (user_id) DO NOTHING
    `;

    // Build dynamic update query only for provided fields
    const setParts = [];
    const values = [userId];
    let idx = 2;

    if (typeof pushEnabled === "boolean") {
      setParts.push(`push_enabled = $${idx++}`);
      values.push(pushEnabled);
    }
    if (typeof emailEnabled === "boolean") {
      setParts.push(`email_enabled = $${idx++}`);
      values.push(emailEnabled);
    }
    if (typeof gameRemindersEnabled === "boolean") {
      setParts.push(`game_reminders_enabled = $${idx++}`);
      values.push(gameRemindersEnabled);
    }
    if (expoPushToken !== undefined) {
      setParts.push(`expo_push_token = $${idx++}`);
      values.push(expoPushToken ?? null);
    }

    if (setParts.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    const query = `
      UPDATE user_notification_settings
      SET ${setParts.join(", ")}, updated_at = now()
      WHERE user_id = $1
      RETURNING user_id, push_enabled, email_enabled, game_reminders_enabled, expo_push_token
    `;

    const updated = await sql(query, values);
    const r = updated[0];

    return Response.json({
      settings: {
        pushEnabled: !!r.push_enabled,
        emailEnabled: !!r.email_enabled,
        gameRemindersEnabled: !!r.game_reminders_enabled,
        expoPushToken: r.expo_push_token,
      },
    });
  } catch (error) {
    console.error("Error updating notification settings:", error);
    return Response.json(
      { error: "Failed to update settings" },
      { status: 500 },
    );
  }
}
