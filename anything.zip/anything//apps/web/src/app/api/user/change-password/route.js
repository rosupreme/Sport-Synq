import sql from "@/app/api/utils/sql";
import argon2 from "argon2";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Password validation
function validatePassword(password) {
  if (password.length < 8) {
    return "Password must be at least 8 characters long";
  }
  if (!/[A-Z]/.test(password)) {
    return "Password must contain at least one uppercase letter";
  }
  if (!/[a-z]/.test(password)) {
    return "Password must contain at least one lowercase letter";
  }
  if (!/\d/.test(password)) {
    return "Password must contain at least one number";
  }
  return null;
}

export async function POST(request) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;
    const { currentPassword, newPassword } = await request.json();

    if (!currentPassword || !newPassword) {
      return Response.json(
        { error: "currentPassword and newPassword are required" },
        { status: 400 },
      );
    }

    // Validate new password strength
    const passwordError = validatePassword(newPassword);
    if (passwordError) {
      return Response.json({ error: passwordError }, { status: 400 });
    }

    // Locate credentials account for this user
    const accounts = await sql`
      SELECT id, password 
      FROM auth_accounts 
      WHERE "userId" = ${userId} AND type = 'credentials' 
      LIMIT 1
    `;

    if (!accounts || accounts.length === 0) {
      return Response.json(
        { error: "Password change is not available for this account" },
        { status: 400 },
      );
    }

    const account = accounts[0];

    // Verify current password - supports both argon2 and legacy plain-text
    let currentMatches = false;
    try {
      currentMatches = await argon2.verify(account.password, currentPassword);
    } catch (_) {
      // Legacy plain-text password comparison
      currentMatches = account.password === currentPassword;
    }

    if (!currentMatches) {
      return Response.json(
        { error: "Current password is incorrect" },
        { status: 400 },
      );
    }

    // Hash and update the new password with argon2
    const hashedPassword = await argon2.hash(newPassword);
    await sql`
      UPDATE auth_accounts 
      SET password = ${hashedPassword} 
      WHERE id = ${account.id}
    `;

    return Response.json({ success: true });
  } catch (err) {
    console.error("Error changing password:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
