import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

// Add contribution to fundraiser
export async function POST(request, { params }) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const { amount, note, contributor_name } = body;

    // Validate required fields
    if (!amount || amount <= 0) {
      return Response.json(
        { error: "Amount is required and must be greater than 0" },
        { status: 400 },
      );
    }

    const userId = user.id;

    // First, check if fundraiser exists at all (allow fundraisers without a team)
    const allFundraisers = await sql`
      SELECT f.*, t.name as team_name
      FROM fundraisers f
      LEFT JOIN teams t ON f.team_id = t.id
      WHERE f.id = ${id}
    `;

    if (allFundraisers.length === 0) {
      return Response.json({ error: "Fundraiser not found" }, { status: 404 });
    }

    const fundraiserData = allFundraisers[0];

    // Check if user has permission
    // - Always allow the organizer
    // - If fundraiser has a team, allow team members or owners
    const permission = await sql`
      SELECT 1 FROM fundraisers f
      WHERE f.id = ${id}
      AND (
        f.organizer_id = ${userId}
        OR (
          f.team_id IS NOT NULL
          AND f.team_id IN (
            SELECT team_id FROM team_members WHERE user_id = ${userId}
            UNION
            SELECT team_id FROM team_ownership WHERE user_id = ${userId}
          )
        )
      )
      LIMIT 1
    `;

    if (permission.length === 0) {
      const teamMsg = fundraiserData.team_name
        ? `the "${fundraiserData.team_name}" team`
        : "this fundraiser";
      return Response.json(
        {
          error: `Permission denied. You must be the organizer or a member/owner of ${teamMsg} to update this fundraiser.`,
        },
        { status: 403 },
      );
    }

    // Add contribution and update fundraiser total
    const result = await sql.transaction([
      sql`
        INSERT INTO fundraiser_contributions (
          fundraiser_id, amount, note, contributor_name
        ) VALUES (
          ${id}, ${amount}, ${note || null}, ${contributor_name || "Anonymous"}
        ) RETURNING *
      `,
      sql`
        UPDATE fundraisers 
        SET raised_amount = raised_amount + ${amount},
            updated_at = NOW()
        WHERE id = ${id}
        RETURNING *
      `,
    ]);

    return Response.json(
      {
        message: "Contribution added successfully",
        contribution: result[0][0],
        fundraiser: result[1][0],
      },
      { status: 201 },
    );
  } catch (error) {
    return Response.json(
      { error: `Failed to add contribution: ${error.message}` },
      { status: 500 },
    );
  }
}

// Delete fundraiser (only by organizer or team owner)
export async function DELETE(request, { params }) {
  try {
    const session = await getAuthUser(request);
    if (!session?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;
    const userId = session.id;

    // First, check if fundraiser exists at all
    const allFundraisers = await sql`
      SELECT f.*, u.name as organizer_name
      FROM fundraisers f
      LEFT JOIN auth_users u ON f.organizer_id = u.id
      WHERE f.id = ${id}
    `;

    if (allFundraisers.length === 0) {
      return Response.json({ error: "Fundraiser not found" }, { status: 404 });
    }

    const fundraiserData = allFundraisers[0];

    // Check if user can delete: organizer or owner of the team (if any)
    const canDelete = await sql`
      SELECT 1 FROM fundraisers f
      WHERE f.id = ${id}
      AND (
        f.organizer_id = ${userId}
        OR (
          f.team_id IS NOT NULL
          AND f.team_id IN (
            SELECT team_id FROM team_ownership WHERE user_id = ${userId}
          )
        )
      )
      LIMIT 1
    `;

    if (canDelete.length === 0) {
      return Response.json(
        {
          error:
            "Permission denied. You can only delete fundraisers you created or for teams you own.",
        },
        { status: 403 },
      );
    }

    // Delete fundraiser and all related contributions
    await sql.transaction([
      sql`DELETE FROM fundraiser_contributions WHERE fundraiser_id = ${id}`,
      sql`DELETE FROM fundraisers WHERE id = ${id}`,
    ]);

    return Response.json(
      { message: "Fundraiser deleted successfully" },
      { status: 200 },
    );
  } catch (error) {
    return Response.json(
      { error: `Failed to delete fundraiser: ${error.message}` },
      { status: 500 },
    );
  }
}
