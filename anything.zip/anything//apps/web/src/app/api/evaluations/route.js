import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

export async function POST(request) {
  try {
    // Require authentication and use the real coach/user id
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      playerId,
      teamId,
      evaluationType,
      season,
      ballControl,
      passing,
      shooting,
      defending,
      fitnessLevel,
      teamwork,
      attitude,
      leadership,
      strengths,
      areasForImprovement,
      goalsNextPeriod,
      coachNotes,
      status,
    } = body;

    // Validate required fields
    if (!playerId || !teamId) {
      return Response.json(
        { error: "Player ID and Team ID are required" },
        { status: 400 },
      );
    }

    // Use the authenticated user as coach
    const coachId = user.id;

    // If no season provided, get it from the team
    let actualSeason = season;
    if (!actualSeason && teamId) {
      const teamResult = await sql`
        SELECT season FROM teams WHERE id = ${teamId} LIMIT 1
      `;
      actualSeason = teamResult.length > 0 ? teamResult[0].season : "2024-25";
    }

    // Use UPSERT to handle existing evaluations
    const evaluation = await sql`
      INSERT INTO player_evaluations (
        player_id,
        coach_id,
        team_id,
        evaluation_type,
        season,
        ball_control,
        passing,
        shooting,
        defending,
        fitness_level,
        teamwork,
        attitude,
        leadership,
        strengths,
        areas_for_improvement,
        goals_next_period,
        coach_notes,
        status,
        created_at,
        updated_at
      ) VALUES (
        ${playerId},
        ${coachId},
        ${teamId},
        ${evaluationType || "mid_season"},
        ${actualSeason || "2024-25"},
        ${ballControl || 5},
        ${passing || 5},
        ${shooting || 5},
        ${defending || 5},
        ${fitnessLevel || 5},
        ${teamwork || 5},
        ${attitude || 5},
        ${leadership || 5},
        ${strengths || ""},
        ${areasForImprovement || ""},
        ${goalsNextPeriod || ""},
        ${coachNotes || ""},
        ${status || "draft"},
        NOW(),
        NOW()
      )
      ON CONFLICT (player_id, evaluation_type, season, team_id) 
      DO UPDATE SET
        ball_control = EXCLUDED.ball_control,
        passing = EXCLUDED.passing,
        shooting = EXCLUDED.shooting,
        defending = EXCLUDED.defending,
        fitness_level = EXCLUDED.fitness_level,
        teamwork = EXCLUDED.teamwork,
        attitude = EXCLUDED.attitude,
        leadership = EXCLUDED.leadership,
        strengths = EXCLUDED.strengths,
        areas_for_improvement = EXCLUDED.areas_for_improvement,
        goals_next_period = EXCLUDED.goals_next_period,
        coach_notes = EXCLUDED.coach_notes,
        status = EXCLUDED.status,
        updated_at = NOW()
      RETURNING id, created_at, updated_at
    `;

    return Response.json({
      success: true,
      evaluation: evaluation[0],
    });
  } catch (error) {
    return Response.json(
      { error: "Failed to create evaluation" },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    // Require authentication
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const teamId = url.searchParams.get("teamId");
    const playerId = url.searchParams.get("playerId");
    const evaluationId = url.searchParams.get("evaluationId");

    // Verify user has access to the requested data
    if (teamId) {
      const teamAccess = await sql`
        SELECT 1 FROM team_members WHERE team_id = ${teamId} AND user_id = ${user.id}
        UNION
        SELECT 1 FROM team_ownership WHERE team_id = ${teamId} AND user_id = ${user.id}
        LIMIT 1
      `;
      if (teamAccess.length === 0) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }
    }

    // Use LEFT JOINs to handle cases where team_members or coach data might be missing
    let query = `
      SELECT 
        pe.*,
        p.name as player_name,
        p.email as player_email,
        COALESCE(tm.position, 'Player') as position,
        tm.jersey_number,
        COALESCE(c.name, 'Unknown Coach') as coach_name
      FROM player_evaluations pe
      JOIN auth_users p ON pe.player_id = p.id
      LEFT JOIN team_members tm ON pe.player_id = tm.user_id AND pe.team_id = tm.team_id
      LEFT JOIN auth_users c ON pe.coach_id = c.id
      WHERE 1=1
    `;

    const params = [];
    let paramIndex = 1;

    if (evaluationId) {
      query += ` AND pe.id = $${paramIndex}`;
      params.push(evaluationId);
      paramIndex++;
    } else {
      if (teamId) {
        query += ` AND pe.team_id = $${paramIndex}`;
        params.push(teamId);
        paramIndex++;
      }

      if (playerId) {
        query += ` AND pe.player_id = $${paramIndex}`;
        params.push(playerId);
        paramIndex++;
      }
    }

    query += ` ORDER BY pe.created_at DESC`;

    const evaluations = await sql(query, params);

    return Response.json({
      success: true,
      evaluations,
    });
  } catch (error) {
    return Response.json(
      { error: "Failed to fetch evaluations" },
      { status: 500 },
    );
  }
}

export async function DELETE(request) {
  try {
    // Require authentication
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const evaluationId = url.searchParams.get("evaluationId");

    // Validate required fields
    if (!evaluationId) {
      return Response.json(
        { error: "Evaluation ID is required" },
        { status: 400 },
      );
    }

    // Verify user has access to the evaluation
    const evaluation = await sql`
      SELECT pe.*, tm.team_id
      FROM player_evaluations pe
      LEFT JOIN team_members tm ON pe.player_id = tm.user_id
      WHERE pe.id = ${evaluationId}
    `;
    if (evaluation.length === 0) {
      return Response.json({ error: "Evaluation not found" }, { status: 404 });
    }
    const teamId = evaluation[0].team_id;
    if (teamId) {
      const teamAccess = await sql`
        SELECT 1 FROM team_members WHERE team_id = ${teamId} AND user_id = ${user.id}
        UNION
        SELECT 1 FROM team_ownership WHERE team_id = ${teamId} AND user_id = ${user.id}
        LIMIT 1
      `;
      if (teamAccess.length === 0) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }
    }

    // First, check if the evaluation exists
    const existingEvaluation = await sql`
      SELECT id, player_id, coach_id 
      FROM player_evaluations 
      WHERE id = ${evaluationId}
    `;

    if (existingEvaluation.length === 0) {
      return Response.json({ error: "Evaluation not found" }, { status: 404 });
    }

    // Delete the evaluation
    const deletedRows = await sql`
      DELETE FROM player_evaluations 
      WHERE id = ${evaluationId}
      RETURNING id
    `;

    if (deletedRows.length === 0) {
      return Response.json(
        { error: "Failed to delete evaluation" },
        { status: 500 },
      );
    }

    return Response.json({
      success: true,
      message: "Evaluation deleted successfully",
      deletedId: deletedRows[0].id,
    });
  } catch (error) {
    return Response.json(
      { error: "Failed to delete evaluation" },
      { status: 500 },
    );
  }
}
