import sql from "@/app/api/utils/sql";
import { getAuthUser } from "@/app/api/utils/getAuthUser";

export async function GET(request, { params }) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;

    if (!id) {
      return Response.json({ error: "Player ID is required" }, { status: 400 });
    }

    // Verify the requesting user has access to view this player
    // (they must share a team with the player)
    const accessCheck = await sql`
      SELECT 1 FROM team_members tm1
      JOIN team_members tm2 ON tm1.team_id = tm2.team_id
      WHERE tm1.user_id = ${user.id} AND tm2.user_id = ${id}
      UNION
      SELECT 1 FROM team_ownership to1
      JOIN team_members tm ON to1.team_id = tm.team_id
      WHERE to1.user_id = ${user.id} AND tm.user_id = ${id}
      LIMIT 1
    `;

    // Allow users to view their own profile
    const isSelf = parseInt(id) === parseInt(user.id);

    if (accessCheck.length === 0 && !isSelf) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    // Get player details with team membership info
    const playerResult = await sql`
      SELECT 
        u.id,
        u.name,
        u.email,
        u.phone,
        u.image,
        u.bio as notes,
        tm.role,
        tm.position,
        tm.jersey_number,
        tm.joined_at,
        tm.team_id,
        t.name as team_name,
        t.season as team_season
      FROM auth_users u
      LEFT JOIN team_members tm ON u.id = tm.user_id
      LEFT JOIN teams t ON tm.team_id = t.id
      WHERE u.id = ${id}
      LIMIT 1
    `;

    if (playerResult.length === 0) {
      return Response.json({ error: "Player not found" }, { status: 404 });
    }

    const player = playerResult[0];

    // Format the response to match the expected structure
    const formattedPlayer = {
      id: player.id,
      name: player.name,
      email: player.email || "",
      phone: player.phone || "",
      image: player.image || null,
      role: player.role || "Player",
      position: player.position || "",
      jerseyNumber: player.jersey_number,
      notes: player.notes || "",
      teamId: player.team_id,
      teamName: player.team_name || "",
      teamSeason: player.team_season || "2024-25",
      joinedAt: player.joined_at,
    };

    return Response.json({ player: formattedPlayer });
  } catch (error) {
    console.error("Error fetching player details:", error);
    return Response.json(
      { error: "Failed to fetch player details" },
      { status: 500 },
    );
  }
}

export async function PUT(request, { params }) {
  try {
    const user = await getAuthUser(request);
    if (!user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const { phone } = body;

    if (!id) {
      return Response.json({ error: "Player ID is required" }, { status: 400 });
    }

    // Users can only update their own profile, or coaches can update their team players
    const isSelf = parseInt(id) === parseInt(user.id);

    if (!isSelf) {
      // Check if current user is a coach of the player's team
      const coachAccess = await sql`
        SELECT 1 FROM team_members tm_coach
        JOIN team_members tm_player ON tm_coach.team_id = tm_player.team_id
        WHERE tm_coach.user_id = ${user.id} 
          AND tm_coach.role = 'Coach'
          AND tm_player.user_id = ${id}
        UNION
        SELECT 1 FROM team_ownership to1
        JOIN team_members tm ON to1.team_id = tm.team_id
        WHERE to1.user_id = ${user.id} AND tm.user_id = ${id}
        LIMIT 1
      `;

      if (coachAccess.length === 0) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }
    }

    // Update the user's phone number
    await sql`
      UPDATE auth_users
      SET phone = ${phone}
      WHERE id = ${id}
    `;

    // Get the updated player details
    const playerResult = await sql`
      SELECT 
        u.id,
        u.name,
        u.email,
        u.phone,
        u.image,
        u.bio as notes,
        tm.role,
        tm.position,
        tm.jersey_number,
        tm.joined_at,
        tm.team_id,
        t.name as team_name,
        t.season as team_season
      FROM auth_users u
      LEFT JOIN team_members tm ON u.id = tm.user_id
      LEFT JOIN teams t ON tm.team_id = t.id
      WHERE u.id = ${id}
      LIMIT 1
    `;

    if (playerResult.length === 0) {
      return Response.json({ error: "Player not found" }, { status: 404 });
    }

    const player = playerResult[0];

    const formattedPlayer = {
      id: player.id,
      name: player.name,
      email: player.email || "",
      phone: player.phone || "",
      image: player.image || null,
      role: player.role || "Player",
      position: player.position || "",
      jerseyNumber: player.jersey_number,
      notes: player.notes || "",
      teamId: player.team_id,
      teamName: player.team_name || "",
      teamSeason: player.team_season || "2024-25",
      joinedAt: player.joined_at,
    };

    return Response.json({ success: true, player: formattedPlayer });
  } catch (error) {
    console.error("Error updating player details:", error);
    return Response.json(
      { error: "Failed to update player details" },
      { status: 500 },
    );
  }
}
